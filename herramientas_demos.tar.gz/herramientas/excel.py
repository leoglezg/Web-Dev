import json, os, sys, urllib.parse, csv
sys.path.insert(0, os.path.dirname(__file__))
from prospectos import P
import xlsxwriter

BASE = os.path.dirname(__file__)
HOY = "2026-11-05"
MSG = {m["slug"]: m for m in json.load(open(os.path.join(BASE, "mensajes.json")))}
ENV = json.load(open(os.path.join(BASE, "envios.json"))) if os.path.exists(os.path.join(BASE, "envios.json")) else {}
URL = "https://leoglezg.github.io/Web-Dev/demos/{}/"
BAJA = "Si no le interesa, responda BAJA y no le vuelvo a escribir."
GIRO_PL = {"barberia": "barberías", "estetica": "estéticas", "taller": "talleres mecánicos", "dentista": "dentistas", "dental": "dentistas"}

# ---- 17 prospectos de la corrida anterior (2026-11-05 mañana), copiados de la hoja de corrida ----
OLD = [
 ("Chakon Barbería","barberia","Prados Vallarta","3326497273","",8,"WhatsApp","A","chakon-barberia","Listo para enviar","","Dirección consistente en dos listados de Fresha. Citas por teléfono.","Fresha","Pixabay (2)","oscuro sobrio v2 (prueba)"),
 ("Aguirre Automotriz","taller","Agua Fría","3336335314","aguirre.automotriz@hotmail.com",8,"Correo + llamada","B","aguirre-automotriz","Enviado","2026-11-05 13:12","Correo enviado 2026-11-05 (variante B). Horario 8 a 18 h en Sección Amarilla. Número fijo.","Sección Amarilla","ninguna","alto contraste"),
 ("JMV Mecánica Automotriz","taller","Las Bóvedas","3315617608","",8,"WhatsApp","A","jmv-mecanica-automotriz","Listo para enviar","","Servicios específicos en el listado; segundo tel (33) 3948 2742.","Sección Amarilla","ninguna","alto contraste"),
 ("Shelter Barber","barberia","La Granja","3314692831","",7,"WhatsApp","B","shelter-barber","Listo para enviar","","Hay otro listado con Bugambilias 2299 y tel 33 3686 6563; confirmar sucursal.","Fresha","ninguna","oscuro sobrio"),
 ("Barbaroja","barberia","Tesistán","3331893319","",7,"WhatsApp","A","barbaroja-tesistan","Listo para enviar","","Solo Fresha; especialidad de barba según el listado.","Fresha","ninguna","oscuro sobrio"),
 ("True Barber Shop","barberia","Poniente","3316571779","",7,"WhatsApp","B","true-barber-shop","Listo para enviar","","Otro listado en Av. Inglaterra 6765, Villas de Asís; puede tener dos sucursales.","Fresha","ninguna","oscuro sobrio"),
 ("Maty Guillen Estética - Salón","estetica","Arcos de Guadalupe","3331900336","",7,"WhatsApp","A","maty-guillen-estetica","Listo para enviar","","Listado de Fresha como maquillaje de novia.","Fresha","ninguna","cálido claro"),
 ("Violette Salón","estetica","Arcos de Guadalupe","3314402719","",7,"WhatsApp","B","violette-salon","Listo para enviar","","Fresha: maquillaje, depilación facial y corporal.","Fresha","ninguna","cálido claro"),
 ("Mecánica Automotriz Peña","taller","Miramar","3311977182","",7,"WhatsApp","A","mecanica-automotriz-pena","Listo para enviar","","Listado como taller electromecánico.","Sección Amarilla","ninguna","alto contraste"),
 ("Clínica Dental Perfect Smile","dental","La Calma","3336318611","",7,"Llamada (fijo)","B","clinica-dental-perfect-smile","Listo para enviar","","Número fijo; llamar.","Sección Amarilla / Huli","ninguna","sereno claro"),
 ("Jam's Barber Shop","barberia","Santa Margarita","3316504982","",6,"WhatsApp","A","jams-barber-shop","Listo para enviar","","Hay otro listado en Paseo del Alba 44, Solares (tel 33 1371 4026) y uno en Av. de la Mancha 2437 (33 3364 0650); confirmar sucursales.","Fresha","ninguna","oscuro sobrio"),
 ("Barbería Loyalty Cut's","barberia","Los Tréboles","3321128367","",6,"WhatsApp","B","barberia-loyalty-cuts","Listo para enviar","","Un listado viejo daba 5 de Marzo 108A, Ejido Copalita y tel 33 3552 9380.","Fresha","ninguna","oscuro sobrio"),
 ("Estética Color y Estilo","estetica","Parques de Tesistán","3318861750","",6,"WhatsApp","A","estetica-color-y-estilo","Listo para enviar","","Otro listado da tel 33 2722 1658; confirmar número.","Fresha","ninguna","cálido claro"),
 ("Musas Salón","estetica","Loma Bonita Ejidal","3334904399","",6,"WhatsApp","B","musas-salon","Listo para enviar","","Salón de belleza con maquillaje según Fresha.","Fresha","ninguna","cálido claro"),
 ("Taller Mecánico Industrial Macías","taller","Jardines Universidad","3336502990","",6,"Llamada (fijo)","A","taller-industrial-macias","Listo para enviar","","Número fijo; probablemente sin WhatsApp: llamar.","Sección Amarilla","ninguna","alto contraste"),
 ("Dra. Elia Díaz, Dentista Especialista","dental","Parques del Auditorio","3338617939","",6,"Llamada (fijo)","B","dra-elia-diaz-dentista","Listo para enviar","","Listada en prótesis bucal. Número fijo; llamar.","Sección Amarilla","ninguna","sereno claro"),
 ("Administradora Dental","dental","El Batán","3336569604","",5,"Llamada (fijo)","A","administradora-dental-el-batan","Listo para enviar","","Aparece como dentista de urgencia. Nombre poco claro; confirmar giro al llamar.","Sección Amarilla","ninguna","sereno claro"),
]

def msg_old(nombre, giro, col, v, slug):
    link = URL.format(slug)
    if v == "A":
        return (f"Hola, buen día. Soy Leonardo, de Zapopan. Vi {nombre} en {col} y le preparé una página para que vea cómo quedaría: {link} "
                f"Verla es gratis. Si le gusta, cuesta 5,000 MXN (50% al iniciar y 50% al entregar); si no, la ajustamos a su gusto. {BAJA}")
    return (f"Hola, buen día. Busqué {GIRO_PL[giro]} en {col} y vi que {nombre} solo aparece en directorios, sin página propia. "
            f"Le hice una de muestra para que sus clientes lo contacten directo: {link} ¿Qué le cambiaría? "
            f"Verla es gratis; si le gusta, son 5,000 MXN en dos pagos. {BAJA}")

def tipo_tel(canal):
    return "Fijo" if "fijo" in canal.lower() or "llamada" in canal.lower() else "Celular"

GNAME = {"barberia": "Barbería", "estetica": "Estética", "taller": "Taller", "dental": "Dentista"}
rows = []
for (n, g, col, tel, mail, pts, canal, v, slug, est, fenv, notas, fuente, img, estilo) in OLD:
    m = msg_old(n, g, col, v, slug)
    rows.append(dict(fecha="2026-11-05 (mañana)", negocio=n, giro=GNAME[g], municipio="Zapopan", colonia=col, tel=tel, tipo=tipo_tel(canal),
                     correo=mail, puntos=pts, canal=canal, variante=v, url=URL.format(slug), wa="https://wa.me/52" + tel + "?text=" + urllib.parse.quote(m, safe=""),
                     mensaje=m, estado=est, fenvio=fenv, respuesta="Sin respuesta" if est == "Enviado" else "", resultado="", monto="", seg=0,
                     notas=notas, fuente=fuente, imagenes=img, estilo=estilo, dia="jueves" if fenv else "", lote="mañana"))
for p in P:
    mm = MSG[p["slug"]]; e = ENV.get(p["slug"], {})
    canal = p["canal"]
    est = "Enviado" if e.get("enviado") else "Listo para enviar"
    notas = p["notas"] + (" Correo enviado " + e["fecha"] + " (variante " + mm["variante"] + ")." if e.get("enviado") else "")
    rows.append(dict(fecha=HOY + " (tarde)", negocio=p["nombre"], giro=GNAME[p["giro"]], municipio="Zapopan", colonia=p["colonia"], tel=p["tel"],
                     tipo=tipo_tel(canal) + (" (verificar)" if p["slug"] == "susana-estetica" else ""), correo=p["correo"], puntos=p["puntos"], canal=canal,
                     variante=mm["variante"], url=URL.format(p["slug"]), wa="https://wa.me/52" + p["tel"] + "?text=" + urllib.parse.quote(mm["mensaje"], safe=""),
                     mensaje=e.get("mensaje", mm["mensaje"]), estado=est, fenvio=e.get("fecha", ""), respuesta="Sin respuesta" if e.get("enviado") else "", resultado="", monto="",
                     seg=0, notas=notas, fuente=p["fuente"], imagenes="Pixabay (2)", estilo={"barberia": "oscuro sobrio v2", "estetica": "cálido claro v2", "taller": "alto contraste v2", "dental": "sereno claro v2"}[p["giro"]],
                     dia="jueves" if e.get("enviado") else "", lote="tarde", slug=p["slug"], guion=mm["guion"]))
rows.sort(key=lambda r: (-r["puntos"], r["fecha"]))
json.dump(rows, open(os.path.join(BASE, "rows.json"), "w"), ensure_ascii=False, indent=1)

enviados_hoy = 1 + sum(1 for v in ENV.values() if v.get("enviado"))
wa_pend = sum(1 for r in rows if r["estado"] == "Listo para enviar" and r["tipo"].startswith("Celular"))
llamadas = [r for r in rows if r["tipo"] == "Fijo"]

wb = xlsxwriter.Workbook(os.path.join(BASE, f"Prospeccion_Web_{HOY}.xlsx"))
H = wb.add_format({"bold": True, "bg_color": "#1f2937", "font_color": "#ffffff", "border": 1, "text_wrap": True, "valign": "vcenter"})
W = wb.add_format({"text_wrap": True, "valign": "top"})
LNK = wb.add_format({"font_color": "#1d4ed8", "underline": 1, "valign": "top"})
T = wb.add_format({"bold": True, "font_size": 16})
B = wb.add_format({"bold": True})
N = wb.add_format({"num_format": "#,##0", "valign": "top"})
PCT = wb.add_format({"num_format": "0%", "valign": "top"})

# ---------- Hoy ----------
ws = wb.add_worksheet("Hoy")
ws.write("A1", f"Corrida del {HOY} (tarde) · Prospección web Zapopan", T)
ws.write("A2", "Hora de la corrida: 20:25 h Guadalajara. Segunda corrida del día; el tope de correos es por día.")
ws.write_row("A4", ["#", "Paso", "Qué hacer", "Hecho"], H)
pasos = [
 ("Revisar prioridades", "No hay interesados, quejas ni borradores pendientes.", "Sí"),
 ("Mandar WhatsApp", f"Abrir cada enlace 'Abrir WhatsApp' de la pestaña Prospectos con estado 'Listo para enviar' y tipo Celular ({wa_pend} en total, empieza por la puntuación más alta). Cambiar el estado a 'Enviado' y anotar fecha.", "No"),
 ("Hacer llamadas", f"Pestaña Llamadas: {len(llamadas)} números fijos con guion. Anotar resultado.", "No"),
 ("Revisar correos enviados hoy", f"{enviados_hoy} de 10 correos del día usados. Si alguien responde, se procesa en la siguiente corrida.", "Sí"),
 ("Seguimientos", "Ninguno toca hoy. Los primeros (Aguirre y los 3 correos de hoy) tocan el 8 o 9 de noviembre.", "Sí"),
 ("Pegar filas en el registro", "Copiar las filas nuevas de la hoja de Drive 'Prospección Web - Corrida 2026-11-05 tarde' a la pestaña Prospectos del registro principal.", "No"),
 ("Anotar resultados", "En Prospectos: Respuesta, Resultado y Monto cobrado de cada contacto (WhatsApp y llamadas).", "No"),
]
for i, (a, b, c) in enumerate(pasos):
    ws.write_row(5 + i - 1, 0, [i + 1, a, b, c], W)
ws.data_validation(4, 3, 4 + len(pasos), 3, {"validate": "list", "source": ["Sí", "No"]})
r0 = 6 + len(pasos)
ws.write(r0, 0, "Resumen en números", B)
resumen = [("Prospectos nuevos (esta corrida)", len(P)), ("Prospectos totales en el registro", len(rows)),
           ("Correos enviados hoy / tope", f"{enviados_hoy} / 10"), ("WhatsApp por mandar", wa_pend), ("Llamadas por hacer", len(llamadas)),
           ("Seguimientos que tocan hoy", 0), ("Respuestas recibidas", 0), ("Ventas del día", 0), ("Ventas acumuladas", 0), ("Ingresos acumulados (MXN)", 0)]
for i, (k, v) in enumerate(resumen):
    ws.write(r0 + 1 + i, 0, k); ws.write(r0 + 1 + i, 2, v)
ws.set_column("A:A", 34); ws.set_column("B:B", 26); ws.set_column("C:C", 90); ws.set_column("D:D", 8)

# ---------- Prospectos ----------
ws = wb.add_worksheet("Prospectos")
cols = ["Fecha", "Negocio", "Giro", "Municipio", "Colonia", "Teléfono", "Tipo de tel.", "Correo", "Puntuación", "Canal", "Variante",
        "Ver demo", "Abrir WhatsApp", "Mensaje", "Estado", "Fecha y hora de envío", "Respuesta", "Resultado", "Monto cobrado (MXN)",
        "Seguimientos", "Notas", "Fuente", "Imágenes", "Estilo de demo"]
ws.write_row(0, 0, cols, H)
for i, r in enumerate(rows, start=1):
    vals = [r["fecha"], r["negocio"], r["giro"], r["municipio"], r["colonia"], r["tel"], r["tipo"], r["correo"], r["puntos"], r["canal"], r["variante"]]
    ws.write_row(i, 0, vals, W)
    ws.write_url(i, 11, r["url"], LNK, "Ver demo")
    if r["tipo"].startswith("Celular"):
        ws.write_url(i, 12, r["wa"], LNK, "Abrir WhatsApp")
    else:
        ws.write(i, 12, "Fijo: llamar", W)
    ws.write_row(i, 13, [r["mensaje"], r["estado"], r["fenvio"], r["respuesta"], r["resultado"]], W)
    ws.write(i, 18, r["monto"], N)
    ws.write_row(i, 19, [r["seg"], r["notas"], r["fuente"], r["imagenes"], r["estilo"]], W)
n = len(rows)
ws.data_validation(1, 14, n + 200, 14, {"validate": "list", "source": ["Listo para enviar", "Enviado", "Respondió", "Interesado", "Vendido", "Cerrado sin respuesta", "No contactar"]})
ws.data_validation(1, 16, n + 200, 16, {"validate": "list", "source": ["Sin respuesta", "Interesado", "Pide cambios", "Pregunta precio/pago", "Pregunta cómo funciona", "Objeción", "No interesado", "BAJA"]})
ws.data_validation(1, 17, n + 200, 17, {"validate": "list", "source": ["Pendiente", "Venta", "Perdido", "No contactar"]})
colors = {"Listo para enviar": "#fef3c7", "Enviado": "#dbeafe", "Respondió": "#e0e7ff", "Interesado": "#dcfce7", "Vendido": "#86efac", "Cerrado sin respuesta": "#e5e7eb", "No contactar": "#fecaca"}
for k, c in colors.items():
    ws.conditional_format(1, 0, n + 200, len(cols) - 1, {"type": "formula", "criteria": f'=$O2="{k}"', "format": wb.add_format({"bg_color": c})})
widths = [16, 30, 11, 10, 20, 12, 12, 28, 10, 16, 8, 10, 15, 60, 18, 18, 18, 12, 14, 11, 50, 16, 13, 18]
for i, w in enumerate(widths):
    ws.set_column(i, i, w)
ws.freeze_panes(1, 2); ws.autofilter(0, 0, n, len(cols) - 1)

# ---------- Llamadas ----------
ws = wb.add_worksheet("Llamadas")
ws.write_row(0, 0, ["Negocio", "Giro", "Colonia", "Teléfono", "Puntuación", "Resumen del negocio", "Guion de 30 segundos", "Ver demo", "Resultado de la llamada", "Fecha de llamada"], H)
def guion_old(r):
    return (f"Buenas tardes, ¿hablo con {r['negocio']}? Soy Leonardo, de Zapopan. Vi su negocio en {r['colonia']} y no encontré página propia, "
            f"así que le preparé una de muestra con su dirección y teléfono. ¿Le puedo mandar el enlace por WhatsApp o por correo para que la vea? "
            f"Verla es gratis; si le gusta, cuesta 5,000 pesos en dos pagos. Si no le interesa, no le vuelvo a llamar.")
for i, r in enumerate(llamadas, start=1):
    ws.write_row(i, 0, [r["negocio"], r["giro"], r["colonia"], r["tel"], r["puntos"], r["notas"], r.get("guion") or guion_old(r)], W)
    ws.write_url(i, 7, r["url"], LNK, "Ver demo")
ws.data_validation(1, 8, len(llamadas) + 50, 8, {"validate": "list", "source": ["No contestó", "Interesado", "Pidió enlace por WhatsApp", "Pidió enlace por correo", "Lo piensa", "No interesado", "Número equivocado"]})
for i, w in enumerate([30, 11, 20, 12, 10, 45, 80, 10, 24, 14]):
    ws.set_column(i, i, w)

# ---------- Seguimientos ----------
ws = wb.add_worksheet("Seguimientos")
ws.write_row(0, 0, ["Negocio", "Canal", "Fecha del primer envío", "Seguimiento #", "Mensaje listo", "Enlace wa.me / correo", "Toca el"], H)
seg_rows = [("Aguirre Automotriz", "Correo", "2026-11-05", 1, "", "Se enviará por correo", "2026-11-08 o 09")]
for p in P:
    if ENV.get(p["slug"], {}).get("enviado"):
        seg_rows.append((p["nombre"], "Correo", HOY, 1, "", "Se enviará por correo", "2026-11-08 o 09"))
ws.write(1, 0, "Ninguno toca hoy. Próximos seguimientos programados:", B)
for i, rr in enumerate(seg_rows, start=2):
    ws.write_row(i, 0, rr, W)
for i, w in enumerate([34, 10, 18, 13, 50, 24, 16]):
    ws.set_column(i, i, w)

# ---------- Playbook ----------
ws = wb.add_worksheet("Playbook")
ws.write_row(0, 0, ["Tema", "Versión vigente", "Desde", "Evidencia", "Notas"], H)
PB = [
 ("Variante A (directa)", "Hola, buen día. Soy Leonardo, de Zapopan. Vi [negocio] en [colonia] y le preparé una página para que vea cómo quedaría: [link] Verla es gratis. Si le gusta, cuesta 5,000 MXN (50% al iniciar y 50% al entregar); si no, la ajustamos a su gusto. " + BAJA, "2026-11-05", "0 envíos", "Primera línea: presentación + negocio + colonia"),
 ("Variante B (problema + pregunta)", "Hola, buen día. Busqué [giro] en [colonia] y vi que [negocio] solo aparece en [directorios | Facebook y directorios], sin página propia. Le hice una de muestra para que sus clientes lo contacten directo: [link] ¿Qué le cambiaría? Verla es gratis; si le gusta, son 5,000 MXN en dos pagos. " + BAJA, "2026-11-05", "1 envío, 0 respuestas", "Ajuste de hoy: decir 'Facebook y directorios' cuando el negocio tiene página de Facebook, para no afirmar algo falso"),
 ("Asunto de correo", "Página para [Negocio]", "2026-11-05", "Datos insuficientes", ""),
 ("Firma de correo", "Leonardo Gonzalez · WhatsApp 33 1366 8338 (antes de la línea de BAJA)", "2026-11-05", "", ""),
 ("Reparto de variantes", "Muestreo de Thompson, Beta(1+positivas, 1+envíos−positivas) por variante. Hoy: A 15, B 5.", "2026-11-05 tarde", "A 0/0, B 0/1", "Se reequilibra solo al llegar respuestas; ningún grupo queda en cero"),
 ("Reparto de giros y zonas", "Zapopan. Esta corrida: barberías 30%, estéticas 20%, talleres 25%, dentistas 25%.", "2026-11-05 tarde", "Sin respuestas aún; se subió dentistas porque 2 de 3 correos públicos encontrados son de consultorios", "Reparto por Thompson cuando haya respuestas"),
 ("Criterios de puntuación", "+ dirección consistente en varias fuentes; + servicios específicos listados; + celular (WhatsApp probable); + correo público; − datos contradictorios; − número fijo; − nombre poco claro; − una sola fuente", "2026-11-05", "Criterio inicial (ajuste manual)", "Regresión logística al llegar a 100 envíos y 10 respuestas positivas"),
 ("Fuentes de prospectos", "Fresha (barberías, estéticas), Sección Amarilla (talleres, dentistas), Facebook para correo público (buscar '[giro] Zapopan @hotmail.com / @gmail.com').", "2026-11-05 tarde", "Facebook dio 3 correos en 20 prospectos (antes 1 en 17)", ""),
 ("Descartes automáticos", "Descartar si tiene sitio en ueniweb.com, Wix, Google Sites o dominio propio, o si Sección Amarilla enlaza a un dominio (p. ej. dentistaengdl.com). Descartar cadenas con varias sucursales.", "2026-11-05 tarde", "Dental Smile, Beauty Fit Spa y Dra. Amparo Peña tenían sitio", ""),
 ("Diseño de demos", "Plantilla v2 (la de Chakon): hero con foto, datos clave, servicios, cómo agendar, reseñas de ejemplo marcadas, mapa, llamada final; Lenis + GSAP; 2 fotos de Pixabay sin caras ni marcas. Por giro: barbería oscuro, estética cálido claro, taller alto contraste en mayúsculas, dentista sereno claro. Contraste ≥4.5:1 verificado. Fijos: botón 'Llamar' en lugar de WhatsApp.", "2026-11-05 tarde", "Prueba: con fotos (20) vs sin fotos (16)", ""),
 ("Objeción: está caro", "Entiendo. Es un pago único, sin mensualidades, y puede dar 50% al iniciar y 50% al entregar. Si quiere, ajustamos la página a lo que realmente necesita.", "2026-11-05", "Inicial", ""),
 ("Objeción: ya tengo Facebook", "Qué bueno. La página no lo reemplaza, lo complementa: aparece en Google cuando alguien busca su servicio en la zona y le manda directo a WhatsApp.", "2026-11-05", "Inicial", ""),
 ("Objeción: no tengo tiempo", "No necesita hacer nada. La página ya está hecha; solo dígame qué cambiaría.", "2026-11-05", "Inicial", ""),
 ("Objeción: cómo consiguieron mis datos", "Su información es pública en Google Maps y directorios. Si prefiere que no le contacte, con gusto lo dejo así.", "2026-11-05", "Inicial", ""),
 ("Objeción: lo pienso", "Un solo seguimiento amable a los 3–4 días sin presionar.", "2026-11-05", "Inicial", ""),
 ("Guion de llamada (30 s)", "Buenas tardes, ¿hablo con [negocio]? Soy Leonardo, de Zapopan. Vi su negocio en [colonia] y no encontré página propia, así que le preparé una de muestra. ¿Le puedo mandar el enlace por WhatsApp o correo? Verla es gratis; si le gusta, son 5,000 pesos en dos pagos. Si no le interesa, no le vuelvo a llamar.", "2026-11-05 tarde", "Nuevo", ""),
]
for i, rr in enumerate(PB, start=1):
    ws.write_row(i, 0, rr, W)
for i, w in enumerate([28, 90, 16, 36, 40]):
    ws.set_column(i, i, w)

# ---------- Aprendizajes ----------
ws = wb.add_worksheet("Aprendizajes")
ws.write_row(0, 0, ["Fecha", "Hallazgo", "Evidencia", "Cambio aplicado"], H)
AP = [
 ("2026-11-05", "Desde la sandbox no se puede abrir Google Maps, Facebook ni Fresha; no hay fotos ni reseñas/horarios para la mayoría", "Bloqueo de red (403); la búsqueda web solo devuelve directorios", "Demos sin fotos; horario 'Pregúntanos por WhatsApp'"),
 ("2026-11-05", "Muy pocos negocios tienen correo público (1 de 17)", "Solo Aguirre Automotriz en Sección Amarilla", "WhatsApp es el canal principal; correo secundario"),
 ("2026-11-05", "Varios listados de Fresha tienen direcciones/teléfonos contradictorios", "Shelter, Jam's, True, Loyalty, Color y Estilo", "Bajar puntuación cuando hay contradicción; confirmar al contactar"),
 ("2026-11-05 tarde", "La API de Pixabay ya funciona: se pueden poner fotos reales en las demos", "Clave PIXABAY_API_KEY respondió; 20 demos con 2 fotos cada una", "PRUEBA: demos con fotos (20 de esta corrida + Chakon) vs sin fotos (16 de la mañana). Medir tasa de respuesta por grupo"),
 ("2026-11-05 tarde", "Buscar en Facebook '[giro] Zapopan @hotmail.com / @gmail.com' encuentra correos públicos", "3 correos en 20 prospectos (15%) vs 1 en 17 (6%) por directorios", "Agregado a Fuentes del Playbook"),
 ("2026-11-05 tarde", "Algunos resultados de búsqueda son sitios propios disfrazados de directorio (ueniweb.com) o la ficha de Sección Amarilla enlaza a un dominio", "Dental Smile, Beauty Fit Spa, Maca Beauty, Dra. Amparo Peña (dentistaengdl.com)", "Regla de descarte agregada al Playbook"),
 ("2026-11-05 tarde", "4 de 5 talleres de Sección Amarilla tienen número fijo", "Precisión, Coronado, Frenos Frescos, Nuevos Frenos Únicos", "Para talleres el canal principal es la llamada; la demo muestra botón 'Llamar'"),
]
for i, rr in enumerate(AP, start=1):
    ws.write_row(i, 0, rr, W)
for i, w in enumerate([16, 60, 50, 60]):
    ws.set_column(i, i, w)

# ---------- Métricas ----------
ws = wb.add_worksheet("Métricas")
ws.write("A1", "Métricas por grupo (enviados = correos y WhatsApp marcados 'Enviado'; llamadas aparte)", B)
ws.write_row(2, 0, ["Dimensión", "Grupo", "Prospectos", "Enviados", "Respuestas", "Tasa de respuesta", "Interesados", "Cierres", "Ingresos (MXN)", "Nota"], H)
from collections import Counter, defaultdict
def grp(key):
    d = defaultdict(lambda: [0, 0])
    for r in rows:
        d[key(r)][0] += 1
        if r["estado"] == "Enviado": d[key(r)][1] += 1
    return d
dims = [("Giro", lambda r: r["giro"]), ("Colonia", lambda r: r["colonia"]), ("Canal", lambda r: r["canal"]), ("Variante", lambda r: r["variante"]),
        ("Tipo de teléfono", lambda r: r["tipo"].split(" ")[0]), ("Correo público", lambda r: "Sí" if r["correo"] else "No"), ("Fuente", lambda r: r["fuente"]),
        ("Imágenes", lambda r: "Con fotos" if "Pixabay" in r["imagenes"] else "Sin fotos"), ("Estilo", lambda r: r["estilo"]), ("Puntuación", lambda r: str(r["puntos"])),
        ("Día de envío", lambda r: r["dia"] or "(sin enviar)")]
row = 3
for dn, f in dims:
    for gname, (pr, en) in sorted(grp(f).items()):
        ws.write_row(row, 0, [dn, gname, pr, en, 0], W)
        ws.write(row, 5, 0 if en else "", PCT)
        ws.write_row(row, 6, [0, 0, 0, "Datos insuficientes (<10 envíos)"], W)
        row += 1
row += 1
ws.write(row, 0, "Prueba A/B", B); row += 1
ws.write_row(row, 0, ["Variante", "Enviados", "Respuestas positivas", "Beta α", "Beta β", "Estado"], H); row += 1
enviados_ab = Counter(r["variante"] for r in rows if r["estado"] == "Enviado")
for v in ("A", "B"):
    ws.write_row(row, 0, [v, enviados_ab.get(v, 0), 0, 1, 1 + enviados_ab.get(v, 0), "Sin ganador: se necesitan 20 envíos por lado"], W); row += 1
row += 1
ws.write(row, 0, "Reparto del día (muestreo de Thompson, semilla 20261105)", B); row += 1
ws.write_row(row, 0, ["Negocio", "Variante asignada", "Muestra A", "Muestra B"], H); row += 1
for p in P:
    mm = MSG[p["slug"]]
    ws.write_row(row, 0, [p["nombre"], mm["variante"], mm["draws"]["A"], mm["draws"]["B"]], W); row += 1
row += 1
ws.write(row, 0, "Evolución diaria", B); row += 1
ws.write_row(row, 0, ["Fecha", "Prospectos nuevos", "Correos enviados", "WhatsApp enviados (anotados)", "Llamadas", "Respuestas", "Interesados", "Ventas", "Ingresos (MXN)"], H); row += 1
ws.write_row(row, 0, ["2026-11-05 (mañana)", 17, 1, 0, 0, 0, 0, 0, 0], W); row += 1
ws.write_row(row, 0, ["2026-11-05 (tarde)", len(P), enviados_hoy - 1, 0, 0, 0, 0, 0, 0], W)
for i, w in enumerate([22, 34, 12, 12, 12, 14, 12, 10, 14, 34]):
    ws.set_column(i, i, w)
wb.close()

# ---------- CSV para la hoja de la corrida en Drive (columnas del registro principal A:S) ----------
with open(os.path.join(BASE, "corrida_tarde.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["fecha", "negocio", "giro", "municipio/colonia", "teléfono", "correo", "puntuación", "canal", "variante A/B", "URL demo", "enlace wa.me", "estado", "fecha envío", "respuesta", "resultado", "seguimientos", "notas", "imágenes", "estilo de demo"])
    for r in rows:
        if r["lote"] != "tarde": continue
        w.writerow([HOY, r["negocio"], r["giro"].lower(), f"Zapopan / {r['colonia']}", r["tel"], r["correo"], r["puntos"], r["canal"], r["variante"], r["url"],
                    r["wa"] if r["tipo"].startswith("Celular") else "Fijo: llamar", r["estado"], r["fenvio"], r["respuesta"], "", 0, r["notas"] + " Fuente: " + r["fuente"] + ".", r["imagenes"], r["estilo"]])
with open(os.path.join(BASE, "aprendizajes_tarde.csv"), "w", newline="") as f:
    w = csv.writer(f); w.writerow(["PESTAÑA", "fecha / tema", "hallazgo / versión vigente", "evidencia / desde", "cambio aplicado / evidencia"])
    for a in AP[3:]: w.writerow(["Aprendizajes", *a])
    for pb in PB:
        if "tarde" in pb[2] or pb[0].startswith("Variante B"): w.writerow(["Playbook", pb[0], pb[1], pb[2], pb[3]])
print("ok", len(rows), "filas;", "correos hoy", enviados_hoy, "; WA pend", wa_pend, "; llamadas", len(llamadas))
