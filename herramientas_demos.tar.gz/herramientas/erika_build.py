import math, random, os, urllib.parse, html, shutil

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "out")
N = "Erika Salón y Microblading"
TEL = "3314170577"; TEL_F = "33 1417 0577"
MAIL = "erikasalon.provi@gmail.com"
DIR = "Av. San Mateo 712, Parques de Tesistán, 45200 Zapopan, Jal."
WA = "https://wa.me/52" + TEL + "?text=" + urllib.parse.quote("Hola, quiero agendar una cita en Erika Salón.", safe="")
WA_MB = "https://wa.me/52" + TEL + "?text=" + urllib.parse.quote("Hola, quiero información de microblading.", safe="")
Q = urllib.parse.quote(f"{N}, {DIR}", safe="")
e = html.escape

# ---------------- ceja procedural ----------------
def brow_svg(cls, n=58, seed=7, guide=True):
    rng = random.Random(seed)
    # línea central de la ceja: cabeza (x=40) -> arco (x=300) -> cola (x=470)
    def center(t):
        x = 40 + 430 * t
        y = 150 - 70 * math.sin(min(t / 0.62, 1) * math.pi / 2) if t < 0.62 else 80 + 62 * ((t - 0.62) / 0.38) ** 1.4
        return x, y
    def thick(t):  # grosor: ancho en la cabeza, se afina en la cola
        return 34 * (1 - t) ** 0.7 + 4
    # contorno guía (paso 1: diseño)
    top, bot = [], []
    for i in range(41):
        t = i / 40; x, y = center(t); h = thick(t) / 2
        top.append((x, y - h)); bot.append((x, y + h))
    pts = top + bot[::-1]
    d_guide = "M" + " L".join(f"{x:.1f} {y:.1f}" for x, y in pts) + " Z"
    def tangent(t):
        a, b = center(max(t - .005, 0)), center(min(t + .005, 1))
        return math.atan2(b[1] - a[1], b[0] - a[0])  # radianes, y hacia abajo
    hairs = []
    for i in range(n):
        # más densidad en el cuerpo de la ceja que en la cola
        t = (i + rng.uniform(0, 1)) / n
        t = t ** 1.08
        x, y = center(t); h = thick(t) / 2
        tan = tangent(t)
        # inclinación respecto a la curva: casi vertical en la cabeza, se acuesta hacia la cola
        lift = math.radians(70 * (1 - min(t / .22, 1)) + 24 * min(t / .22, 1) * (1 - t) + 8 + rng.uniform(-5, 5))
        ang = tan - lift
        # nace en la mitad inferior y cruza hacia arriba
        off = rng.uniform(-.2, .95) * h
        nx, ny = -math.sin(tan), math.cos(tan)  # normal hacia abajo
        x0, y0 = x + nx * off, y + ny * off
        L = max(thick(t) * rng.uniform(.95, 1.35), 9)
        x1, y1 = x0 + math.cos(ang) * L, y0 + math.sin(ang) * L
        bend = rng.uniform(.10, .22) * L
        cx, cy = (x0 + x1) / 2 + math.cos(tan) * bend, (y0 + y1) / 2 + math.sin(tan) * bend
        w = "a" if rng.random() < .65 else "b"
        hairs.append(f'<path class="hair {w}" pathLength="1" d="M{x0:.1f} {y0:.1f} Q{cx:.1f} {cy:.1f} {x1:.1f} {y1:.1f}"/>')
    g = f'<path class="guide" pathLength="1" d="{d_guide}"/>' if guide else ""
    return (f'<svg class="{cls}" viewBox="0 0 520 200" fill="none" aria-hidden="true" focusable="false">{g}'
            f'<g class="hairs">{"".join(hairs)}</g></svg>')

WA_ICON = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5a8.4 8.4 0 0 1-12.4 7.4L3 21l2.1-5.4A8.4 8.4 0 1 1 21 11.5z"/></svg>'
ARROW = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>'

def img(id_, alt, w, h, cls="", eager=False):
    pri = 'fetchpriority="high"' if eager else 'loading="lazy" decoding="async"'
    return (f'<img class="{cls}" src="img/{id_}-1280.webp" srcset="img/{id_}-720.webp 720w, img/{id_}-1280.webp 1280w" '
            f'sizes="(min-width: 900px) 50vw, 100vw" width="{w}" height="{h}" alt="{e(alt)}" {pri}>')

FONTS = '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">'

CSS = r"""
:root{--bg:#f7f1ea;--paper:#fffaf5;--sand:#efe4d8;--ink:#2a1f1c;--muted:#66554d;--line:#e2d3c4;--rose:#9a3b52;--rose-ink:#7e2d42;--on-rose:#ffffff;--cocoa:#2e1f1b;--cocoa-2:#3a2924;--cream:#f3e7dc;--taupe:#c9a58c;--cocoa-muted:#c2ac9c;--head:"Fraunces",Georgia,serif;--body:"DM Sans",-apple-system,"Segoe UI",Roboto,Arial,sans-serif;--ease:cubic-bezier(.2,.7,.1,1)}
*{box-sizing:border-box;margin:0;padding:0}
html{-webkit-text-size-adjust:100%}
body{background:var(--bg);color:var(--ink);font-family:var(--body);font-size:17px;line-height:1.6;-webkit-font-smoothing:antialiased;overflow-x:clip}
a{color:inherit}img,svg,iframe{display:block;max-width:100%}
.wrap{max-width:1200px;margin:0 auto;padding:0 20px}
.skip{position:absolute;left:-999px}.skip:focus{left:16px;top:12px;background:var(--rose);color:var(--on-rose);padding:8px 12px;z-index:50}
a:focus-visible,.btn:focus-visible,button:focus-visible{outline:3px solid var(--rose);outline-offset:3px}
.progress{position:fixed;inset:0 0 auto 0;height:3px;background:var(--rose);transform-origin:0 50%;transform:scaleX(0);z-index:40}
/* header */
header.bar{position:fixed;inset:0 0 auto 0;z-index:30;transition:background-color .3s var(--ease),box-shadow .3s var(--ease)}
header.bar.solid{background:rgba(247,241,234,.98);box-shadow:0 1px 0 var(--line)}
header.bar .wrap{display:flex;align-items:center;justify-content:space-between;gap:16px;min-height:68px}
.brand{text-decoration:none;display:flex;flex-direction:column;line-height:1}
.brand b{font-family:var(--head);font-weight:500;font-size:26px;letter-spacing:-.01em}
.brand small{font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:var(--muted);margin-top:4px}
.nav{display:none;gap:30px;font-size:15px}
.nav a{text-decoration:none;color:var(--muted)}.nav a:hover{color:var(--ink)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:10px;min-height:50px;padding:12px 24px;border-radius:999px;font-weight:600;font-size:16px;text-decoration:none;background:var(--rose);color:var(--on-rose);border:1px solid var(--rose);transition:background-color .2s var(--ease)}
.btn:hover{background:var(--rose-ink)}
.btn.ghost{background:transparent;color:var(--ink);border-color:var(--ink)}
.btn.ghost:hover{background:var(--ink);color:var(--bg)}
.btn.sm{min-height:44px;padding:8px 18px;font-size:15px}
.kicker{display:inline-flex;align-items:center;gap:10px;font-size:13px;font-weight:600;letter-spacing:.16em;text-transform:uppercase;color:var(--rose)}
.kicker::before{content:"";width:28px;height:1px;background:currentColor}
/* hero */
.hero{padding:120px 0 64px;position:relative}
.hero .grid{display:grid;gap:44px;align-items:center}
h1{font-family:var(--head);font-weight:400;font-size:clamp(50px,10.5vw,124px);line-height:.95;letter-spacing:-.025em;margin:22px 0 0}
h1 em{font-style:italic;color:var(--rose)}
.hero .brow-hero{width:min(320px,70%);margin:18px 0 0 -6px}
.lede{color:var(--muted);font-size:clamp(18px,2vw,20px);max-width:38ch;margin:20px 0 30px}
.actions{display:flex;flex-wrap:wrap;gap:12px}
.collage{position:relative;min-height:440px}
.collage .main{position:relative;width:78%;margin-left:auto;aspect-ratio:4/5;border-radius:220px 220px 16px 16px;overflow:hidden;background:var(--sand)}
.collage .main img{width:100%;height:115%;object-fit:cover}
.collage .small{position:absolute;left:0;bottom:-24px;width:46%;aspect-ratio:1;border-radius:16px;overflow:hidden;border:8px solid var(--bg);background:var(--sand)}
.collage .small img{width:100%;height:100%;object-fit:cover}
.collage .badge{position:absolute;right:-6px;top:22px;width:118px;height:118px}
.badge text{font-family:var(--body);font-size:9.6px;letter-spacing:.24em;text-transform:uppercase;fill:var(--ink)}
/* marquee */
.marquee{border-block:1px solid var(--line);overflow:hidden;padding:18px 0;background:var(--paper)}
.marquee .track{display:flex;width:max-content;gap:0}
.marquee span{font-family:var(--head);font-size:clamp(26px,4vw,44px);font-style:italic;white-space:nowrap;padding-right:40px}
.marquee span i{font-style:normal;color:var(--rose);padding-left:40px}
/* microblading */
.mb{background:var(--cocoa);color:var(--cream);position:relative}
.mb .wrap{display:grid;gap:40px;padding-top:96px;padding-bottom:96px}
.mb h2,.salon h2,.agenda h2,.voces h2,.visita h2,.galeria h2{font-family:var(--head);font-weight:400;font-size:clamp(40px,6vw,76px);line-height:1;letter-spacing:-.02em}
.mb h2 em{font-style:italic;color:var(--taupe)}
.mb .kicker{color:var(--taupe)}
.mb .intro{color:var(--cocoa-muted);max-width:44ch;margin-top:18px;font-size:18px}
.steps-mb{list-style:none;display:grid;gap:4px;margin-top:34px}
.steps-mb li{padding:18px 0 18px 64px;border-top:1px solid rgba(243,231,220,.16);position:relative;transition:opacity .4s var(--ease)}
.steps-mb li:last-child{border-bottom:1px solid rgba(243,231,220,.16)}
.steps-mb .n{position:absolute;left:0;top:16px;font-family:var(--head);font-size:30px;color:var(--taupe);line-height:1}
.steps-mb h3{font-family:var(--head);font-weight:500;font-size:24px}
.steps-mb p{color:var(--cocoa-muted);font-size:16px;margin-top:4px;max-width:40ch}
.motion .steps-mb li{opacity:.38}.motion .steps-mb li.on{opacity:1}
.stage{position:relative;border-radius:20px;background:var(--cocoa-2);padding:28px;display:grid;place-items:center;min-height:300px;overflow:hidden}
.stage .brow-big{width:100%;max-width:560px}
.brow-big .guide{stroke:var(--taupe);stroke-width:1.4;stroke-dasharray:.012 .012;opacity:.7}
.brow-big .hair{stroke:var(--cream);stroke-width:1.5;stroke-linecap:round}
.brow-big .hair.b{stroke:var(--taupe);stroke-width:1.2}
.brow-hero .guide{display:none}
.brow-hero .hair{stroke:var(--rose);stroke-width:2;stroke-linecap:round}
.brow-hero .hair.b{stroke:var(--ink);stroke-width:1.5;opacity:.75}
.stage .caption{position:absolute;left:24px;bottom:18px;font-size:13px;color:var(--cocoa-muted)}
.stage .count{position:absolute;right:24px;top:18px;font-family:var(--head);font-size:15px;color:var(--taupe);font-variant-numeric:tabular-nums}
.mb .cta-mb{margin-top:30px}
.mb .btn{background:var(--cream);color:var(--cocoa);border-color:var(--cream)}.mb .btn:hover{background:#fff}
/* salón */
section.block{padding:96px 0}
.head{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:end;gap:20px;margin-bottom:40px}
.head p{color:var(--muted);max-width:40ch}
.cards{display:grid;gap:22px}
.card{background:var(--paper);border:1px solid var(--line);border-radius:18px;overflow:hidden;display:flex;flex-direction:column}
.card .ph{aspect-ratio:4/3;overflow:hidden;background:var(--sand)}
.card .ph img{width:100%;height:100%;object-fit:cover;transform-origin:50% 50%}
.card .tx{padding:22px 22px 26px}
.card h3{font-family:var(--head);font-weight:500;font-size:28px;line-height:1.1}
.card p{color:var(--muted);margin-top:8px}
.card .note{display:inline-block;margin-top:14px;font-size:14px;font-weight:600;color:var(--rose)}
/* galería */
.galeria{background:var(--paper);border-block:1px solid var(--line);overflow:hidden}
.galeria .wrap.top{padding-top:90px}
.gal-viewport{overflow-x:auto;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;padding:34px 0 90px}
.gal-track{display:flex;gap:18px;padding:0 20px;width:max-content}
.gal-track figure{scroll-snap-align:start;width:min(78vw,520px);flex:none}
.gal-track figure .f{aspect-ratio:4/5;border-radius:16px;overflow:hidden;background:var(--sand)}
.gal-track figure:nth-child(even) .f{aspect-ratio:1;margin-top:60px}
.gal-track img{width:100%;height:100%;object-fit:cover}
.gal-track figcaption{font-size:14px;color:var(--muted);margin-top:10px}
.gal-note{font-size:14px;color:var(--muted);margin-top:12px}
/* agenda */
.agenda .list{list-style:none;display:grid;gap:18px;counter-reset:a;position:relative}
.agenda li{counter-increment:a;padding:28px;background:var(--paper);border:1px solid var(--line);border-radius:18px}
.agenda li::before{content:"0" counter(a);display:block;font-family:var(--head);font-size:56px;line-height:1;color:var(--rose);margin-bottom:12px}
.agenda h3{font-size:20px}.agenda p{color:var(--muted);margin-top:6px}
/* reseñas */
.notice{border:1px dashed var(--muted);border-radius:10px;padding:10px 14px;color:var(--muted);font-size:14px;margin-bottom:24px}
.revs{display:grid;gap:18px}
.rev{background:var(--paper);border:1px solid var(--line);border-radius:18px;padding:26px;display:flex;flex-direction:column;gap:14px}
.stars{color:var(--rose);letter-spacing:3px}
.rev blockquote{font-family:var(--head);font-size:23px;line-height:1.3}
.who{color:var(--muted);font-size:14px;margin-top:auto}
/* visita */
.loc{display:grid;gap:28px}
.map{border-radius:18px;overflow:hidden;aspect-ratio:4/3;background:var(--sand);border:1px solid var(--line)}
.map iframe{width:100%;height:100%;border:0}
dl{display:grid;gap:22px}
dt{color:var(--muted);font-size:14px}
dd{font-size:19px;overflow-wrap:anywhere}
.link{color:var(--rose-ink);font-weight:600;text-underline-offset:3px}
/* final */
.final{background:var(--rose);color:var(--on-rose);border-radius:28px;padding:64px 24px;text-align:center;overflow:hidden;position:relative}
.final h2{font-family:var(--head);font-weight:400;font-size:clamp(54px,12vw,150px);line-height:.9;letter-spacing:-.03em}
.final h2 em{font-style:italic}
.final p{margin:18px auto 30px;max-width:36ch;font-size:18px}
.final .btn{background:var(--paper);color:var(--rose-ink);border-color:var(--paper)}
.final .btn:hover{background:#fff}
footer{padding:48px 0 64px;color:var(--muted);font-size:14px;border-top:1px solid var(--line);margin-top:96px}
footer nav{display:flex;flex-wrap:wrap;gap:20px;margin-bottom:14px}
footer p+p{margin-top:6px}
/* estados iniciales solo con animación activa (sin JS todo se ve) */
.motion [data-reveal]{opacity:0}
.motion .brow-big .hair,.motion .brow-big .guide{stroke-dasharray:1;stroke-dashoffset:1}
.motion .brow-big .guide{stroke-dasharray:1}
.motion .brow-hero .hair{stroke-dasharray:1;stroke-dashoffset:1}
@media (min-width:900px){
 .nav{display:flex}
 .hero{padding:150px 0 90px}
 .hero .grid{grid-template-columns:1.1fr .9fr}
 .collage{min-height:600px}
 .mb .wrap{grid-template-columns:.9fr 1.1fr;align-items:center;min-height:100vh}
 .cards{grid-template-columns:repeat(3,1fr)}
 .agenda .list{grid-template-columns:repeat(3,1fr)}
 .revs{grid-template-columns:repeat(3,1fr)}
 .loc{grid-template-columns:1.2fr .8fr;align-items:start}
 .final{padding:110px 40px}
 .gal-viewport{overflow:visible;padding-bottom:110px}
 .gal-track{padding-left:max(20px,calc((100vw - 1160px)/2))}
 .gal-track figure{width:440px}
}
@media (prefers-reduced-motion:reduce){*{transition:none!important}}
"""

JS = r"""
<script src="https://cdn.jsdelivr.net/npm/lenis@1.3.4/dist/lenis.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.13.0/dist/gsap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.13.0/dist/ScrollTrigger.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.13.0/dist/SplitText.min.js"></script>
<script>
(function(){
  var root = document.documentElement;
  var bar = document.querySelector('header.bar');
  function solid(){ bar.classList.toggle('solid', window.scrollY > 20); }
  window.addEventListener('scroll', solid, {passive:true}); solid();
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce || !window.gsap || !window.ScrollTrigger) return;
  gsap.registerPlugin(ScrollTrigger, window.SplitText ? SplitText : null);
  root.classList.add('motion');

  // Scroll suave + enlaces internos
  var lenis = null;
  if (window.Lenis) {
    lenis = new Lenis({ duration: 1.15, smoothWheel: true });
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add(function(t){ lenis.raf(t * 1000); });
    gsap.ticker.lagSmoothing(0);
  }
  document.querySelectorAll('a[href^="#"]').forEach(function(a){
    a.addEventListener('click', function(ev){
      var id = a.getAttribute('href'); if (id.length < 2) return;
      var el = document.querySelector(id); if (!el) return;
      ev.preventDefault(); lenis ? lenis.scrollTo(el, { offset: -70 }) : el.scrollIntoView({behavior:'smooth'});
    });
  });

  // Barra de progreso
  gsap.to('.progress', { scaleX: 1, ease: 'none', scrollTrigger: { trigger: document.body, start: 'top top', end: 'bottom bottom', scrub: .3 } });

  // Revelados genéricos
  gsap.utils.toArray('[data-reveal]').forEach(function(el){
    gsap.fromTo(el, { autoAlpha: 0, y: 28 }, { autoAlpha: 1, y: 0, duration: .9, ease: 'power3.out',
      scrollTrigger: { trigger: el, start: 'top 88%', once: true } });
  });

  // Títulos por líneas
  function lines(sel, opts){
    if (!window.SplitText) return;
    gsap.utils.toArray(sel).forEach(function(el){
      SplitText.create(el, { type: 'lines', mask: 'lines', autoSplit: true, onSplit: function(self){
        return gsap.from(self.lines, Object.assign({ yPercent: 110, duration: 1, ease: 'expo.out', stagger: .09 }, opts ? opts(el) : {}));
      }});
    });
  }
  lines('.hero h1');
  lines('[data-lines]', function(el){ return { scrollTrigger: { trigger: el, start: 'top 85%', once: true } }; });

  // Hero: ceja que se dibuja, collage con máscara y parallax
  var hero = gsap.timeline({ delay: .15 });
  hero.from('.hero .kicker, .hero .lede, .hero .actions', { autoAlpha: 0, y: 20, duration: .8, ease: 'power3.out', stagger: .1 }, .25)
      .to('.brow-hero .hair', { strokeDashoffset: 0, duration: .5, ease: 'power1.out', stagger: { each: .018 } }, .45)
      .from('.collage .main', { clipPath: 'inset(100% 0% 0% 0% round 220px 220px 16px 16px)', duration: 1.3, ease: 'expo.inOut' }, 0)
      .from('.collage .main img', { scale: 1.25, duration: 1.6, ease: 'expo.out' }, .2)
      .from('.collage .small', { autoAlpha: 0, y: 40, duration: 1, ease: 'power3.out' }, .7)
      .from('.collage .badge', { autoAlpha: 0, scale: .6, duration: .8, ease: 'back.out(1.6)' }, 1);
  gsap.to('.collage .badge', { rotate: 360, ease: 'none', scrollTrigger: { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: true } });
  gsap.to('.collage .main img', { yPercent: -10, ease: 'none', scrollTrigger: { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: true } });
  gsap.to('.collage .small', { yPercent: -28, ease: 'none', scrollTrigger: { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: true } });

  // Cinta que acelera y cambia de dirección con el scroll
  var track = document.querySelector('.marquee .track');
  if (track) {
    track.innerHTML += track.innerHTML;
    var loop = gsap.to(track, { xPercent: -50, duration: 28, ease: 'none', repeat: -1 });
    ScrollTrigger.create({ onUpdate: function(self){
      var v = gsap.utils.clamp(-6, 6, self.getVelocity() / 300);
      gsap.to(loop, { timeScale: (self.direction === -1 ? -1 : 1) * (1 + Math.abs(v)), duration: .3, overwrite: true });
    }});
  }

  // Microblading: la ceja se traza pelo a pelo con el scroll
  var hairs = gsap.utils.toArray('.brow-big .hair');
  var steps = gsap.utils.toArray('.steps-mb li');
  var count = document.querySelector('.stage .count');
  var mm = gsap.matchMedia();
  function browTL(st){
    st.onUpdate = function(self){
      var p = self.progress, i = p < .3 ? 0 : (p < .88 ? 1 : 2);
      steps.forEach(function(li, k){ li.classList.toggle('on', k === i); });
      if (count) count.textContent = Math.round(gsap.utils.clamp(0, 1, (p - .3) / .58) * hairs.length) + ' / ' + hairs.length + ' trazos';
    };
    var tl = gsap.timeline({ scrollTrigger: st });
    tl.to('.brow-big .guide', { strokeDashoffset: 0, duration: .28, ease: 'none' })
      .to(hairs, { strokeDashoffset: 0, duration: .02, ease: 'none', stagger: { each: .55 / hairs.length } }, .3)
      .to('.brow-big .guide', { opacity: 0, duration: .12 }, .9)
      .to({}, { duration: .1 });
    return tl;
  }
  steps[0] && steps[0].classList.add('on');
  mm.add('(min-width: 900px)', function(){
    browTL({ trigger: '.mb', start: 'top top', end: '+=180%', pin: true, scrub: .6 });
  });
  mm.add('(max-width: 899px)', function(){
    browTL({ trigger: '.stage', start: 'top 75%', end: 'bottom 25%', scrub: .6 });
  });

  // Tarjetas del salón: la foto se descubre y se asienta
  gsap.utils.toArray('.card').forEach(function(c, i){
    var tl = gsap.timeline({ scrollTrigger: { trigger: c, start: 'top 85%', once: true } });
    tl.from(c, { y: 50, autoAlpha: 0, duration: .9, ease: 'power3.out', delay: (i % 3) * .08 })
      .from(c.querySelector('.ph'), { clipPath: 'inset(0 0 100% 0)', duration: 1, ease: 'expo.inOut' }, '<.1')
      .from(c.querySelector('img'), { scale: 1.3, duration: 1.4, ease: 'expo.out' }, '<');
  });

  // Galería horizontal fija en escritorio
  mm.add('(min-width: 900px)', function(){
    var t = document.querySelector('.gal-track');
    var dist = function(){ return t.scrollWidth - window.innerWidth + 40; };
    gsap.to(t, { x: function(){ return -dist(); }, ease: 'none',
      scrollTrigger: { trigger: '.galeria', start: 'top top', end: function(){ return '+=' + dist(); }, pin: true, scrub: .6, invalidateOnRefresh: true } });
    gsap.utils.toArray('.gal-track img').forEach(function(im){
      gsap.fromTo(im, { scale: 1.18 }, { scale: 1, ease: 'none', scrollTrigger: { trigger: '.galeria', start: 'top top', end: function(){ return '+=' + dist(); }, scrub: true } });
    });
  });

  // Pasos para agendar y reseñas en cascada
  ['.agenda li', '.rev'].forEach(function(sel){
    gsap.from(sel, { y: 40, autoAlpha: 0, duration: .8, ease: 'power3.out', stagger: .12,
      scrollTrigger: { trigger: sel, start: 'top 85%', once: true } });
  });

  // Cierre: letras que suben y botón magnético
  if (window.SplitText) {
    SplitText.create('.final h2', { type: 'chars', autoSplit: true, onSplit: function(self){
      return gsap.from(self.chars, { yPercent: 100, autoAlpha: 0, rotate: 6, duration: .9, ease: 'back.out(1.7)', stagger: .03,
        scrollTrigger: { trigger: '.final', start: 'top 75%', once: true } });
    }});
  }
  if (window.matchMedia('(pointer: fine)').matches) {
    document.querySelectorAll('[data-magnet]').forEach(function(b){
      var xTo = gsap.quickTo(b, 'x', { duration: .4, ease: 'power3' }), yTo = gsap.quickTo(b, 'y', { duration: .4, ease: 'power3' });
      b.addEventListener('pointermove', function(ev){ var r = b.getBoundingClientRect(); xTo((ev.clientX - r.left - r.width / 2) * .3); yTo((ev.clientY - r.top - r.height / 2) * .4); });
      b.addEventListener('pointerleave', function(){ xTo(0); yTo(0); });
    });
  }
  window.addEventListener('load', function(){ ScrollTrigger.refresh(); });
})();
</script>"""

def page_head(title, desc, rel=""):
    return f"""<!doctype html>
<html lang="es-MX">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>{e(title)}</title>
<meta name="description" content="{e(desc)}">
<meta name="theme-color" content="#f7f1ea">
<link rel="icon" type="image/svg+xml" href="{rel}favicon.svg">
{FONTS}
<style>{CSS}</style>
</head>
<body>
<div class="progress" aria-hidden="true"></div>
<a class="skip" href="#main">Saltar al contenido</a>
<header class="bar"><div class="wrap"><a class="brand" href="{rel or './'}"><b>Erika</b><small>Salón &amp; Microblading</small></a>
<nav class="nav" aria-label="Secciones"><a href="{rel or './'}#microblading">Microblading</a><a href="{rel or './'}#salon">Salón</a><a href="{rel or './'}#agenda">Agenda</a><a href="{rel or './'}#visita">Ubicación</a></nav>
<a class="btn sm" href="{e(WA)}">WhatsApp</a></div></header>
"""

FOOT = lambda rel: f"""<footer><div class="wrap">
<nav><a href="{rel or './'}">Inicio</a><a href="{rel}terminos/">Términos y condiciones</a><a href="{rel}privacidad/">Aviso de privacidad</a></nav>
<p>{e(N)}, {e(DIR)} Tel. {TEL_F}.</p>
<p>Página de muestra preparada para {e(N)}. Los datos vienen de su información pública y se pueden ajustar. Fotos ilustrativas de Pixabay.</p>
</div></footer>
"""

BADGE = '<svg class="badge" viewBox="0 0 120 120" aria-hidden="true"><defs><path id="c" d="M60 60m-46 0a46 46 0 1 1 92 0a46 46 0 1 1-92 0"/></defs><circle cx="60" cy="60" r="58" fill="#fffaf5" stroke="#e2d3c4"/><text><textPath href="#c">Pelo a pelo · Parques de Tesistán ·</textPath></text><circle cx="60" cy="60" r="5" fill="#9a3b52"/></svg>'

def index():
    revs = [("Me explicó todo el proceso antes de empezar y quedé contenta con la forma.", 5),
            ("Agendar por WhatsApp fue rápido y me atendieron a mi hora.", 5),
            ("Lugar limpio y tranquilo. Volvería para el corte.", 4)]
    stars = {5: "★★★★★", 4: "★★★★☆"}
    rv = "".join(f'<figure class="rev"><div class="stars" aria-label="{s} de 5 estrellas">{stars[s]}</div><blockquote>{e(q)}</blockquote><figcaption class="who">Clienta de ejemplo</figcaption></figure>' for q, s in revs)
    gal = [("5441655", "Salón amplio con ventanales, espejo grande y sillas de corte", 1280, 852),
           ("2693077", "Sillón de lavado de cabello en un salón de tonos cálidos", 1280, 850),
           ("4057094", "Estilista aplicando mechas con papel aluminio", 1280, 809),
           ("5441659", "Repisas iluminadas con productos para el cabello", 1280, 853),
           ("3173438", "Corte con tijera visto desde atrás", 1280, 801)]
    galhtml = "".join(f'<figure><div class="f">{img(i, a, w, h)}</div><figcaption>{e(a)}</figcaption></figure>' for i, a, w, h in gal)
    return page_head(f"{N} | Microblading y salón en Parques de Tesistán, Zapopan",
                     "Erika Salón y Microblading en Parques de Tesistán, Zapopan. Microblading de cejas pelo a pelo y servicios de salón. Agenda por WhatsApp.") + f"""<main id="main">
<section class="hero"><div class="wrap grid">
<div>
<p class="kicker">Parques de Tesistán · Zapopan</p>
<h1>Cejas trazadas <em>pelo a pelo</em></h1>
{brow_svg("brow-hero", n=64, seed=3, guide=False)}
<p class="lede">Microblading y servicios de salón en Av. San Mateo. Escríbenos, platicamos la forma que quieres y te damos fecha.</p>
<div class="actions"><a class="btn" href="{e(WA_MB)}" data-magnet>{WA_ICON}Pregunta por microblading</a><a class="btn ghost" href="#microblading">Cómo funciona {ARROW}</a></div>
</div>
<div class="collage">
<div class="main">{img("brow", "Kit para cejas con polvo y brochitas sobre una mesa de madera", 820, 853, eager=True)}</div>
<div class="small">{img("1853957", "Trenza vista desde atrás", 1280, 851)}</div>
{BADGE}
</div>
</div></section>
<div class="marquee" aria-hidden="true"><div class="track"><span>Microblading <i>✦</i></span><span>Corte <i>✦</i></span><span>Color <i>✦</i></span><span>Peinado <i>✦</i></span><span>Parques de Tesistán <i>✦</i></span></div></div>
<section class="mb" id="microblading"><div class="wrap">
<div>
<p class="kicker">Microblading</p>
<h2 data-lines>Una ceja, <em>trazo por trazo</em></h2>
<p class="intro">Diseño de cejas pelo a pelo. Antes de empezar te explicamos el proceso y los cuidados, sin prisa.</p>
<ol class="steps-mb">
<li><span class="n">01</span><h3>Diseño</h3><p>Platicamos la forma que quieres y la marcamos juntas antes de empezar.</p></li>
<li><span class="n">02</span><h3>Trazo pelo a pelo</h3><p>Se dibujan trazos finos que siguen la dirección natural de tu ceja.</p></li>
<li><span class="n">03</span><h3>Cuidados</h3><p>Te decimos cómo cuidarlas en los días siguientes.</p></li>
</ol>
<div class="cta-mb"><a class="btn" href="{e(WA_MB)}">{WA_ICON}Agendar valoración</a></div>
</div>
<div class="stage">{brow_svg("brow-big", n=120, seed=7)}<span class="count" aria-hidden="true"></span><span class="caption">Ilustración del trazo pelo a pelo</span></div>
</div></section>
<section class="block salon" id="salon"><div class="wrap">
<div class="head"><div><p class="kicker">Salón</p><h2 data-lines>También en el salón</h2></div><p>Además del microblading, atendemos corte, color y peinado. Pregúntanos por lo que buscas.</p></div>
<div class="cards">
<article class="card"><div class="ph">{img("1516352", "Estilista cortando cabello con peine y tijera", 1280, 853)}</div><div class="tx"><h3>Corte</h3><p>Dinos cómo lo traes y cómo lo quieres; lo platicamos antes de cortar.</p><span class="note">Precio por WhatsApp</span></div></article>
<article class="card"><div class="ph">{img("5965371", "Tazón con tinte y brocha para aplicar color", 1280, 853)}</div><div class="tx"><h3>Color</h3><p>Tinte y mechas. Te decimos qué tono te conviene según tu cabello.</p><span class="note">Precio por WhatsApp</span></div></article>
<article class="card"><div class="ph">{img("1853957", "Trenza vista desde atrás", 1280, 851)}</div><div class="tx"><h3>Peinado</h3><p>Para eventos o para el día a día. Agenda con anticipación si es fecha especial.</p><span class="note">Precio por WhatsApp</span></div></article>
</div>
</div></section>
<section class="galeria" aria-labelledby="g-t">
<div class="wrap top"><p class="kicker">El espacio</p><h2 id="g-t" data-lines>Así se vive una cita</h2><p class="gal-note">Fotos ilustrativas. En la página final van fotos del salón.</p></div>
<div class="gal-viewport"><div class="gal-track">{galhtml}</div></div>
</section>
<section class="block agenda" id="agenda"><div class="wrap">
<div class="head"><div><p class="kicker">Agenda</p><h2 data-lines>Tu cita en tres pasos</h2></div></div>
<ol class="list">
<li><h3>Escríbenos</h3><p>Dinos qué servicio te interesa y qué día te acomoda.</p></li>
<li><h3>Te confirmamos</h3><p>Te damos horario y lo que necesitas saber antes de llegar.</p></li>
<li><h3>Llegas a tu cita</h3><p>Si se te complica, avísanos y la movemos.</p></li>
</ol>
</div></section>
<section class="block voces" style="padding-top:0"><div class="wrap">
<div class="head"><div><p class="kicker">Reseñas</p><h2 data-lines>Lo que dicen en Google</h2></div></div>
<p class="notice">Reseñas de ejemplo para esta demostración. En la página final se muestran sus reseñas reales de Google.</p>
<div class="revs">{rv}</div>
</div></section>
<section class="block visita" id="visita" style="padding-top:0"><div class="wrap">
<div class="head"><div><p class="kicker">Ubicación</p><h2 data-lines>Visítanos</h2></div></div>
<div class="loc">
<div class="map" data-reveal><iframe src="https://www.google.com/maps?q={Q}&output=embed" title="Mapa de {e(N)}" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
<dl data-reveal>
<div><dt>Dirección</dt><dd>{e(DIR)}</dd></div>
<div><dt>Horario</dt><dd>Pregúntanos por WhatsApp</dd></div>
<div><dt>Teléfono y WhatsApp</dt><dd><a class="link" href="tel:+52{TEL}">{TEL_F}</a></dd></div>
<div><dt>Correo</dt><dd><a class="link" href="mailto:{MAIL}">{MAIL}</a></dd></div>
<div><a class="link" href="https://www.google.com/maps/search/?api=1&amp;query={Q}">Abrir en Google Maps</a></div>
</dl>
</div>
</div></section>
<section class="wrap"><div class="final">
<h2>¿<em>Agendamos</em>?</h2>
<p>Mándanos un mensaje con el servicio que te interesa y te damos los horarios libres.</p>
<a class="btn" href="{e(WA)}" data-magnet>{WA_ICON}Escribir por WhatsApp</a>
</div></section>
</main>
""" + FOOT("") + JS + "\n</body>\n</html>\n"

LEGAL_JS = "<script>(function(){var b=document.querySelector('header.bar');function s(){b.classList.toggle('solid',scrollY>20)}addEventListener('scroll',s,{passive:true});s()})();</script>"

def legal(kind):
    contacto = f'escríbenos por <a class="link" href="{e(WA)}">WhatsApp</a>, llama al {TEL_F} o escribe a <a class="link" href="mailto:{MAIL}">{MAIL}</a>'
    if kind == "terminos":
        title = "Términos y condiciones"
        body = f"""<h2>1. Quiénes somos</h2><p>Este sitio pertenece a {e(N)}, con domicilio en {e(DIR)} Al usarlo aceptas estos términos.</p>
<h2>2. Información de servicios</h2><p>Los servicios descritos son informativos. Precios, disponibilidad y tiempos se confirman directamente antes de cada servicio. Para microblading se hace una valoración previa.</p>
<h2>3. Citas y cancelaciones</h2><p>Las citas se agendan por WhatsApp o por teléfono. Si no puedes asistir, avísanos con anticipación para liberar el horario.</p>
<h2>4. Uso del sitio</h2><p>Puedes consultar y compartir este sitio para fines personales. No está permitido copiar sus textos o diseño para uso comercial sin autorización.</p>
<h2>5. Responsabilidad</h2><p>Procuramos que la información esté actualizada, pero puede cambiar sin aviso. Las fotos del sitio son ilustrativas.</p>
<h2>6. Enlaces externos</h2><p>El sitio enlaza a servicios de terceros como WhatsApp y Google Maps, que tienen sus propios términos.</p>
<h2>7. Ley aplicable</h2><p>Estos términos se rigen por las leyes de México. Cualquier controversia se atenderá ante los tribunales competentes de Zapopan, Jalisco.</p>
<h2>8. Contacto</h2><p>Para cualquier duda {contacto}.</p>"""
    else:
        title = "Aviso de privacidad"
        body = f"""<h2>Responsable</h2><p>{e(N)}, con domicilio en {e(DIR)} es responsable del uso y protección de tus datos personales, conforme a la Ley Federal de Protección de Datos Personales en Posesión de los Particulares.</p>
<h2>Datos que recabamos</h2><ul><li>Nombre.</li><li>Número de teléfono o WhatsApp y correo.</li><li>La información que nos compartas al pedir una cita o cotización.</li></ul><p>No solicitamos datos financieros a través de este sitio.</p>
<h2>Para qué los usamos</h2><ul><li>Agendar, confirmar o cambiar tus citas.</li><li>Responder tus preguntas y enviarte cotizaciones.</li></ul><p>No usamos tus datos para publicidad ni los vendemos.</p>
<h2>Transferencias</h2><p>No compartimos tus datos con terceros, salvo que la ley lo exija.</p>
<h2>Derechos ARCO</h2><p>Puedes pedir acceder, rectificar, cancelar u oponerte al uso de tus datos, o revocar tu consentimiento: {contacto}. Te responderemos en un plazo máximo de 20 días hábiles.</p>
<h2>Cookies</h2><p>Este sitio no usa cookies de seguimiento ni herramientas de publicidad.</p>
<h2>Cambios</h2><p>Cualquier cambio a este aviso se publicará en esta misma página.</p>"""
    style = "<style>.legal{max-width:760px;padding:130px 20px 0}.legal h1{font-size:clamp(40px,7vw,64px);margin:12px 0 10px}.legal h2{font-family:var(--head);font-weight:500;font-size:26px;margin:32px 0 8px}.legal p,.legal li{margin-bottom:10px}.legal ul{padding-left:22px}.draft{background:var(--paper);border-left:4px solid var(--rose);padding:12px 16px;margin:20px 0 8px;font-size:15px}</style>"
    return (page_head(f"{title} | {N}", f"{title} | {N}", "../").replace("</head>", style + "</head>")
            + f"""<main class="wrap legal" id="main"><p class="kicker">Erika Salón</p><h1>{title}</h1>
<p class="draft">Borrador para revisión de {e(N)}. Antes de publicar la página final, el negocio debe confirmar o ajustar este texto.</p>
<p>Última actualización: 5 de noviembre de 2026.</p>
{body}</main>
""" + FOOT("../") + LEGAL_JS + "\n</body>\n</html>\n")

FAV = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#9a3b52"/><path d="M12 40 Q24 22 40 24 Q50 25 54 32" fill="none" stroke="#fffaf5" stroke-width="4" stroke-linecap="round"/><path d="M18 36l3-7M24 32l4-7M31 29l4-6M38 28l5-4M45 29l5-2" stroke="#fffaf5" stroke-width="2.4" stroke-linecap="round"/></svg>'

if __name__ == "__main__":
    if os.path.exists(OUT): shutil.rmtree(OUT)
    os.makedirs(os.path.join(OUT, "img"))
    for f in os.listdir(os.path.join(BASE, "img")):
        shutil.copy(os.path.join(BASE, "img", f), os.path.join(OUT, "img", f))
    open(os.path.join(OUT, "index.html"), "w").write(index())
    for k in ("terminos", "privacidad"):
        os.makedirs(os.path.join(OUT, k)); open(os.path.join(OUT, k, "index.html"), "w").write(legal(k))
    open(os.path.join(OUT, "favicon.svg"), "w").write(FAV)
    print("ok")
