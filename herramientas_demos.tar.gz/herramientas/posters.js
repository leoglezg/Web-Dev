const {chromium}=require('playwright'); const jobs=require('/tmp/claude-0/-home-user-Web-Dev/35bc8042-8169-5a4e-946f-8c0f65a30f15/scratchpad/top/all3d.json');
(async()=>{const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const p=await b.newPage({viewport:{width:900,height:900}}); p.on('pageerror',e=>console.log('PE',e.message));
 for (const [slug,[model,cfg]] of Object.entries(jobs)) {
  const P={maquina:[0.32,0.6],auto:[0.22,0.55],diente:[0.32,0.9],labial:[0.32,0.9],pluma:[0.25,0.5]}[model];const c=Object.assign({prx:P[0],pry:P[1]}, cfg);
  await p.goto('http://localhost:8770/lib3d/preview.html?'+slug+'#'+encodeURIComponent(JSON.stringify(c)));
  await p.waitForFunction(()=>document.title==='ok',null,{timeout:20000}); await p.waitForTimeout(150);
  await p.locator('#c').screenshot({path:'/tmp/claude-0/-home-user-Web-Dev/35bc8042-8169-5a4e-946f-8c0f65a30f15/scratchpad/opt/poster_'+slug+'.png',omitBackground:true}); }
 await b.close();})();
