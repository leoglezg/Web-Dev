import json, os, sys, random, urllib.parse
sys.path.insert(0, os.path.dirname(__file__))
from prospectos import P

BASE = os.path.dirname(__file__)
URL = "https://leoglezg.github.io/Web-Dev/demos/{}/"
GIRO_PL = {"barberia": "barberías", "estetica": "estéticas", "taller": "talleres mecánicos", "dental": "dentistas"}
BAJA = "Si no le interesa, responda BAJA y no le vuelvo a escribir."
FB = {"erika-salon-microblading", "dentista-lomas-de-zapopan", "centro-odontologico-puerta-de-hierro"}

# Muestreo de Thompson: Beta(1+positivas, 1+envíos-positivas). Datos al 2026-11-05: A 0/0 (sin envíos), B 0/1.
STATS = {"A": (0, 0), "B": (0, 1)}
rng = random.Random(20261105)

def thompson():
    draws = {v: rng.betavariate(1 + s, 1 + n - s) for v, (s, n) in STATS.items()}
    return max(draws, key=draws.get), draws

def msg(p, v):
    link = URL.format(p["slug"])
    if v == "A":
        t = (f"Hola, buen día. Soy Leonardo, de Zapopan. Vi {p['nombre']} en {p['colonia']} y le preparé una página para que vea cómo quedaría: {link} "
             f"Verla es gratis. Si le gusta, cuesta 5,000 MXN (50% al iniciar y 50% al entregar); si no, la ajustamos a su gusto. {BAJA}")
    else:
        donde = "Facebook y directorios" if p["slug"] in FB else "directorios"
        t = (f"Hola, buen día. Busqué {GIRO_PL[p['giro']]} en {p['colonia']} y vi que {p['nombre']} solo aparece en {donde}, sin página propia. "
             f"Le hice una de muestra para que sus clientes lo contacten directo: {link} ¿Qué le cambiaría? "
             f"Verla es gratis; si le gusta, son 5,000 MXN en dos pagos. {BAJA}")
    return t

def guion(p):
    return (f"Buenas tardes, ¿hablo con {p['nombre']}? Soy Leonardo, de Zapopan. Vi su negocio en {p['colonia']} en Sección Amarilla "
            f"y no encontré página propia, así que le preparé una de muestra con su dirección y teléfono. ¿Le puedo mandar el enlace por WhatsApp "
            f"o por correo para que la vea? Verla es gratis; si le gusta, cuesta 5,000 pesos en dos pagos. Si no le interesa, no le vuelvo a llamar.")

out = []
for p in P:
    v, draws = thompson()
    m = msg(p, v)
    wa = "https://wa.me/52" + p["tel"] + "?text=" + urllib.parse.quote(m, safe="")
    words = len(m.split())
    out.append(dict(slug=p["slug"], variante=v, draws={k: round(x, 3) for k, x in draws.items()}, mensaje=m, palabras=words, wa=wa,
                    asunto=f"Página para {p['nombre']}", guion=guion(p) if "fijo" in p["canal"] else ""))
json.dump(out, open(os.path.join(BASE, "mensajes.json"), "w"), indent=1, ensure_ascii=False)
for o in out:
    print(o["slug"], o["variante"], o["palabras"], o["draws"])
