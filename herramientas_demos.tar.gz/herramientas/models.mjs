const len = (a, b, c = 0) => Math.sqrt(a * a + b * b + c * c);
const smin = (a, b, k) => { const h = Math.max(k - Math.abs(a - b), 0) / k; return Math.min(a, b) - h * h * k * .25; };
const box = (px, py, pz, bx, by, bz, r) => { const qx = Math.abs(px) - bx + r, qy = Math.abs(py) - by + r, qz = Math.abs(pz) - bz + r;
  return len(Math.max(qx, 0), Math.max(qy, 0), Math.max(qz, 0)) + Math.min(Math.max(qx, Math.max(qy, qz)), 0) - r; };
const box2 = (px, py, bx, by, r) => { const qx = Math.abs(px) - bx + r, qy = Math.abs(py) - by + r; return len(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - r; };
const rot = (x, y, a) => [x * Math.cos(a) - y * Math.sin(a), x * Math.sin(a) + y * Math.cos(a)];
const cylY = (x, y, z, r, y0, y1, rr = 0) => { const dr = len(x, z) - r + rr, dy = Math.abs(y - (y0 + y1) / 2) - (y1 - y0) / 2 + rr;
  return Math.min(Math.max(dr, dy), 0) + len(Math.max(dr, 0), Math.max(dy, 0)) - rr; };

// NAVAJA clásica abierta: hoja a la derecha, mango negro a la izquierda
export const navaja = {
  hoja(x, y, z) {
    const [bx, by] = rot(x - .42, y + .02, .05);
    const u = Math.max(0, Math.min(1, (bx + .5) / 1));                 // 0 junto al perno → 1 punta
    const edge = -.1 - .1 * Math.sin(u * Math.PI * .5);                 // filo curvo que baja hacia la punta
    let d2 = Math.max(by - .17, edge - by);
    d2 = Math.max(d2, Math.abs(bx) - .5);
    d2 = Math.max(d2, len(Math.max(bx - .38, 0), Math.max(by - .05, 0)) - .12 > 0 ? len(Math.max(bx - .38, 0), Math.max(by - .05, 0)) - .12 : d2); // punta redondeada arriba
    const t = Math.max(0, Math.min(1, (by - edge) / (.17 - edge)));
    const dz = Math.abs(z) - (.02 + .035 * t);
    let d = Math.max(d2, dz);
    d = Math.min(d, box(x + .06, y - .04, z, .1, .06, .03, .02));
    return d;
  },
  mango(x, y, z) {
    const [hx, hy] = rot(x + .52, y + .06, -.16);
    let d = box(hx, hy, z, .44, .085, .055, .045);
    d = Math.min(d, Math.max(len(x + .08, y - .03) - .04, Math.abs(z) - .08)); // perno
    return d;
  },
};

// DISCO DE FRENO perforado con caliper (eje z hacia la cámara)
export const freno = {
  disco(x, y, z) {
    const r = len(x, y);
    let d = Math.max(r - .82, Math.abs(z) - .065);
    d = Math.max(d, -(r - .1));                                    // centro
    d = Math.min(d, Math.max(r - .36, Math.abs(z - .08) - .14));   // campana
    d = Math.max(d, -(r - .1));
    for (let i = 0; i < 5; i++) { const a = i * 2 * Math.PI / 5; d = Math.max(d, -(len(x - .23 * Math.cos(a), y - .23 * Math.sin(a)) - .045)); }
    for (const [rr, n, off] of [[.5, 10, 0], [.6, 12, .13], [.71, 14, .05]])
      for (let i = 0; i < n; i++) { const a = i * 2 * Math.PI / n + off; d = Math.max(d, -(len(x - rr * Math.cos(a), y - rr * Math.sin(a)) - .03)); }
    return d;
  },
  caliper(x, y, z) {
    const rr = len(x, y), a = Math.atan2(y, x) - Math.PI / 4;
    const aa = Math.atan2(Math.sin(a), Math.cos(a));
    const dr = Math.abs(rr - .74) - .2, da = (Math.abs(aa) - .5) * rr, dz = Math.abs(z) - .18, k = .05;
    return len(Math.max(dr + k, 0), Math.max(da + k, 0), Math.max(dz + k, 0)) + Math.min(Math.max(dr + k, Math.max(da + k, dz + k)), 0) - k;
  },
};

// LABIAL: estuche dorado y barra de color con corte inclinado (vertical)
export const labial = {
  estuche(x, y, z) {
    let d = cylY(x, y, z, .27, -.98, -.16, .03);
    d = Math.max(d, -(Math.max(Math.abs(y + .55) - .012, -(len(x, z) - .262))));  // ranura decorativa
    d = Math.min(d, cylY(x, y, z, .205, -.2, .06, .015));                          // manga interior
    return d;
  },
  barra(x, y, z) {
    let d = cylY(x, y, z, .17, 0, .9, .02);
    const cut = (y - .72) + (x + .17) * .75;                                          // plano inclinado
    return Math.max(d, cut * .8);
  },
};

const cylZ = (x, y, z, r, h, rr = 0) => { const dr = len(x, y) - r + rr, dz = Math.abs(z) - h + rr;
  return Math.min(Math.max(dr, dz), 0) + len(Math.max(dr, 0), Math.max(dz, 0)) - rr; };
const cylX = (x, y, z, r, h, rr = 0) => cylZ(y, z, x, r, h, rr);
const ssub = (a, b, k) => -smin(-a, b, k);
const WHEELS = [[-.56, -.3, .37], [.58, -.3, .37], [-.56, -.3, -.37], [.58, -.3, -.37]];

// AUTO sencillo de perfil (frente a la derecha)
export const auto = {
  carroceria(x, y, z) {
    let d = box(x, y + .14, z, .95, .17, .38, .1);                          // cuerpo bajo
    d = smin(d, box(x + .08, y - .13, z, .5, .16, .33, .12), .16);           // cabina
    for (const [wx, wy] of WHEELS.slice(0, 2)) d = ssub(d, len(x - wx, y - wy) - .25, .04);   // pasos de rueda
    return d;
  },
  cristales(x, y, z) {
    let d = box(x + .08, y - .15, z, .44, .1, .345, .07);
    d = Math.max(d, -(Math.abs(x + .06) - .025));                            // poste entre ventanas
    return Math.max(d, -(y - .04));
  },
  llantas(x, y, z) { let d = 9; for (const [wx, wy, wz] of WHEELS) d = Math.min(d, cylZ(x - wx, y - wy, z - wz, .21, .075, .04)); return d; },
  rines(x, y, z) { let d = 9; for (const [wx, wy, wz] of WHEELS) d = Math.min(d, cylZ(x - wx, y - wy, z - wz * 1.06, .11, .06, .02)); return d; },
};

// MÁQUINA PARA CORTAR PELO (vertical, cuchillas arriba)
export const maquina = {
  cuerpo(x, y, z) {
    const w = .25 - .05 * Math.max(0, Math.min(1, (-y + .1) / 1));          // se angosta hacia abajo
    let d = box(x, y + .18, z * 1.25, w, .72, .2, .14);
    d = ssub(d, box(x - w - .02, y - .12, z, .03, .05, .07, .02), .02);      // hueco de la palanca
    return d;
  },
  anillo(x, y, z) { return Math.max(box(x, y - .38, z * 1.25, .27, .045, .215, .04), -box(x, y - .38, z * 1.25, .2, .2, .15, .02)); },
  cuchillas(x, y, z) {
    let d = box(x, y - .63, z, .27, .1, .06, .02);
    const tx = ((x + 10) % .045) - .0225;                                    // dientes del peine
    const teeth = Math.max(box(tx, y - .74, z - .02, .012, .05, .02, .006), Math.abs(x) - .26);
    d = Math.min(d, teeth);
    d = Math.min(d, box(x + .3, y - .1, z, .03, .045, .05, .02));            // palanca
    return d;
  },
};

// PLUMA DE MICROBLADING (diagonal)
export const pluma = {
  mango(x, y, z) { const [u, v] = rot(x, y, -.75); return cylX(u + .25, v, z, .085, .6, .03); },
  agarre(x, y, z) {
    const [u, v] = rot(x, y, -.75);
    let d = cylX(u - .45, v, z, .1, .14, .02);
    for (let i = -3; i <= 3; i++) d = ssub(d, cylX(u - .45 - i * .036, v, z, .12, .008), .006);   // estrías
    return d;
  },
  cuchilla(x, y, z) {
    const [u, v] = rot(x, y, -.75);
    let d = cylX(u - .66, v, z, .05, .07, .01);                              // portacuchilla
    const fan = Math.max(Math.max(len(u - .7, v) - .17, -(len(u - .7, v) - .11)), Math.abs(z) - .008); // abanico de agujas
    return Math.min(d, Math.max(fan, Math.abs(v) - .09, -(u - .74)));
  },
};
