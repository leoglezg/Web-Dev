"""Dentista Lomas de Zapopan v3: bloques de color estilo Fine Acts + diente 3D, calma✦ y capítulos."""
import os, sys, json, ast, urllib.parse, html, shutil
BASE = os.path.dirname(os.path.abspath(__file__)); SP = os.path.dirname(BASE)
sys.path.insert(0, BASE)
import build2, build4
from negocios import NEG
e = html.escape
b = next(x for x in NEG if x["slug"] == "dentista-lomas-de-zapopan")
build2.build(b)                                     # genera legales, favicon e imágenes
d = os.path.join(BASE, "out", b["slug"])
for f in ("three-lite.js", "diente.bin"):
    if os.path.exists(os.path.join(d, f)): os.remove(os.path.join(d, f))
shutil.copy(os.path.join(SP, "diente-3d.webp"), os.path.join(d, "img", "diente-3d.webp"))

N = b["nombre"]; TEL = b["tel"]; TELF = build2.ftel(TEL); MAIL = b["mail"]; DIR = b["dir"]
WA = "https://wa.me/52" + TEL + "?text=" + urllib.parse.quote("Hola, quiero agendar una cita en Dentista Lomas de Zapopan.", safe="")
Q = urllib.parse.quote(f"{N}, {DIR}", safe="")
SPARK = build4.SPARK
def img(i, alt, cls=""):
    w, h = build2.dims(i)
    return f'<img class="{cls}" src="img/{i}-1280.webp" srcset="img/{i}-720.webp 720w, img/{i}-1280.webp 1280w" sizes="(min-width: 900px) 45vw, 92vw" width="{w}" height="{h}" alt="{e(alt)}" loading="lazy" decoding="async">'

SERV = [("Consulta y revisión", "Revisamos tu boca y te explicamos lo que encontramos antes de empezar.", "2589770", "Sillón dental e instrumental en un consultorio blanco"),
        ("Tratamientos dentales", "Somos un grupo de dentistas. Pregúntanos por el tratamiento que buscas.", "3528684", "Unidad dental con instrumental listo"),
        ("Trato cercano", "Te atendemos con calma y resolvemos tus dudas.", "759929", "Modelo de dientes en yeso blanco"),
        ("Citas por WhatsApp", "Escríbenos y te damos el primer horario disponible.", "2584260", "Consultorio dental blanco y luminoso")]
CITA = [("Escríbenos", "Mándanos un WhatsApp con el día que te acomoda."), ("Valoración", "Revisamos y te explicamos opciones y costos."), ("Tratamiento", "Empezamos cuando estés de acuerdo con el plan.")]
REV = [("Me explicaron el tratamiento con calma y sin presión.", 5), ("Puntuales con la cita.", 5), ("Consultorio limpio y buen trato.", 4)]
CH = [("Valoración", "Revisamos tu boca y te decimos qué encontramos, con calma y sin prisa."), ("Plan y costo", "Te explicamos las opciones y cuánto cuesta cada una antes de empezar."), ("Tratamiento", "Empezamos solo cuando estés de acuerdo con el plan.")]

src = open(os.path.join(BASE, "build3.py")).read()
S3D_CSS = next(n.value.value for n in ast.parse(src).body if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", "") == "CSS")

CSS = """
:root{--ink:#0b0d0e;--paper:#f6f6f3;--sky:#a9d9f1;--pink:#f4b6e6;--mint:#8fe0c6;--grey:#bcbfbf;--yellow:#f2ee3c;--teal:#0f6e78;--line:rgba(11,13,14,.18);
 --bg:var(--sky);--muted:#33393c;--acc:#0b0d0e;--feat-acc:#0f6e78;--head:"Inter",-apple-system,"Segoe UI",Roboto,Arial,sans-serif;--body:"Inter",-apple-system,"Segoe UI",Roboto,Arial,sans-serif;--hdr:var(--sky);--hdr-ink:var(--ink)}
*{box-sizing:border-box;margin:0;padding:0}html{-webkit-text-size-adjust:100%}
body{background:var(--paper);color:var(--ink);font-family:var(--body);font-size:17px;line-height:1.5;-webkit-font-smoothing:antialiased;overflow-x:clip}
a{color:inherit}img,svg,iframe{display:block;max-width:100%}
.skip{position:absolute;left:-999px}.skip:focus{left:16px;top:12px;background:var(--ink);color:#fff;padding:8px 12px;z-index:60}
a:focus-visible,.btn:focus-visible{outline:3px solid var(--teal);outline-offset:3px}
.wrap{max-width:1240px;margin:0 auto;padding:0 20px}
header.bar{position:fixed;inset:0 0 auto 0;z-index:40;background:var(--hdr);color:var(--hdr-ink);transition:background-color .35s ease,color .35s ease}
header.bar .wrap{display:flex;align-items:center;justify-content:space-between;min-height:60px;gap:16px}
.logo{font-weight:800;letter-spacing:.02em;text-decoration:none;font-size:17px;white-space:nowrap}
.logo i{display:inline-block;font-style:normal;transform:rotate(14deg) translateY(-1px)}.logo i.b{transform:rotate(-12deg)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:10px;min-height:50px;padding:12px 24px;border-radius:999px;font-weight:600;font-size:16px;text-decoration:none;background:var(--ink);color:#fff;border:0;transition:transform .2s ease}
.btn:hover{transform:translateY(-1px)}.btn.sm{min-height:44px;padding:8px 18px;font-size:15px}
header .btn{background:var(--hdr-ink);color:var(--hdr)}
.progress{position:fixed;inset:0 0 auto 0;height:3px;background:var(--ink);transform-origin:0 50%;transform:scaleX(0);z-index:50}
.kicker{display:inline-flex;align-items:center;gap:10px;font-size:13px;font-weight:600;letter-spacing:.14em;text-transform:uppercase}
.kicker::before{content:"";width:28px;height:1px;background:currentColor}
/* bloques */
.blk{position:relative;padding:110px 0 120px}
.blk .ttl{font-weight:800;letter-spacing:-.055em;line-height:.86;font-size:clamp(64px,15vw,210px);overflow:hidden;padding-bottom:.06em}
.blk .sub{font-size:clamp(18px,2vw,22px);margin-top:16px;max-width:30ch}
.blk.dark{background:var(--ink);color:#fff}.blk.pink{background:var(--pink)}.blk.grey{background:var(--grey)}.blk.white{background:var(--paper)}
/* lista activa (servicios y cita) */
.alist{list-style:none;margin-top:44px}
.alist li{font-size:clamp(26px,3.6vw,46px);font-weight:500;letter-spacing:-.025em;line-height:1.08;padding:6px 0 6px 0;color:rgba(255,255,255,.38);transition:color .3s ease,padding .3s ease;position:relative}
.white .alist li,.pink .alist li{color:rgba(11,13,14,.32)}
.alist li.on{color:#fff;padding-left:34px}.white .alist li.on,.pink .alist li.on{color:var(--ink)}
.alist li::before{content:"";position:absolute;left:0;top:.42em;width:.42em;height:.42em;border-radius:50%;background:currentColor;transform:scale(0);transition:transform .3s ease}
.alist li.on::before{transform:scale(1)}
.split{display:grid;gap:36px}
.media{position:relative;aspect-ratio:4/3;border-radius:14px;overflow:hidden;background:#222}
.media img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:0;transform:scale(1.06);transition:opacity .5s ease,transform .8s ease}
.media img.on{opacity:1;transform:none}
.desc{margin-top:16px;font-size:18px;color:rgba(255,255,255,.75);min-height:3em}
.pink .desc{color:var(--muted)}
.bignum{font-weight:800;letter-spacing:-.06em;line-height:1;font-size:clamp(130px,30vw,380px);height:1em;overflow:hidden;display:flex;align-items:flex-start}
.bignum .col{display:flex;flex-direction:column}.bignum .col span{height:1em;display:block}
.notice{border:1px dashed currentColor;border-radius:10px;padding:10px 14px;font-size:14px;margin-top:22px;max-width:640px;opacity:.85}
.revs{display:flex;gap:16px;overflow-x:auto;scroll-snap-type:x mandatory;margin-top:30px;padding-bottom:10px;-webkit-overflow-scrolling:touch;scrollbar-width:none}
.revs::-webkit-scrollbar{display:none}
.rev{flex:none;width:min(84vw,460px);scroll-snap-align:start;background:var(--paper);border-radius:14px;padding:12px}
.rev .q{background:var(--yellow);border-radius:10px;padding:34px 26px;font-size:clamp(22px,2.4vw,28px);font-weight:600;letter-spacing:-.02em;line-height:1.2;min-height:210px;display:flex;align-items:flex-end}
.rev .who{font-size:14px;padding:12px 6px 4px;color:var(--muted)}.rev .stars{letter-spacing:3px;font-size:14px;padding:0 6px}
.dots{display:flex;gap:18px;font-weight:600;margin-top:18px}.dots span{opacity:.35;transition:opacity .3s}.dots span.on{opacity:1}
.dots span.on::before{content:"● "}
.rows{margin-top:40px;border-top:1px solid var(--line)}
.rows div{display:grid;grid-template-columns:1fr;gap:4px;padding:18px 0;border-bottom:1px solid var(--line)}
.rows dt{font-size:13px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.rows dd{font-size:clamp(20px,2.4vw,28px);font-weight:500;letter-spacing:-.02em;overflow-wrap:anywhere}
.rows a{text-underline-offset:4px}
.map{margin-top:30px;border-radius:14px;overflow:hidden;aspect-ratio:16/10;background:#ddd}.map iframe{width:100%;height:100%;border:0;filter:grayscale(.2)}
.cta-row{display:flex;flex-wrap:wrap;gap:12px;margin-top:30px}
footer{background:var(--ink);color:#fff;padding:90px 0 40px;overflow:hidden}
.mega{display:flex;flex-wrap:wrap;font-weight:800;letter-spacing:-.05em;line-height:.85;font-size:clamp(64px,13.5vw,200px)}
.mega span{display:inline-block;will-change:transform}.mega .sp{width:.28em}
.tag{font-weight:800;letter-spacing:.02em;text-transform:uppercase;font-size:14px;margin-top:72px;position:relative;z-index:1}
.flinks{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px 24px;margin-top:28px;font-size:15px}
.flinks a{text-decoration:none;opacity:.85}.flinks a:hover{opacity:1;text-decoration:underline}
.fnote{margin-top:34px;font-size:13px;opacity:.6;max-width:70ch}
@media (min-width:900px){.split{grid-template-columns:1.05fr .95fr;align-items:center}.rows div{grid-template-columns:220px 1fr;align-items:baseline}.flinks{grid-template-columns:repeat(4,max-content)}}
/* escena 3D: fondo que cambia de color */
.s3d{background:var(--sky)!important;transition:background-color .6s ease}
.s3d .word .pre{font-family:var(--body);font-style:normal;font-weight:500;letter-spacing:-.02em;color:var(--ink)}
.pre .rot{display:inline-block}
.s3d .kicker,.ch .num{color:var(--ink)}
.m3d .s3d-progress span::after{background:var(--ink)}.m3d .s3d-progress span{background:rgba(11,13,14,.18)}
.s3d-canvas .shadow{background:radial-gradient(closest-side,rgba(11,13,14,.25),rgba(11,13,14,0))}
.motion .reveal-ttl .ch-l{display:inline-block}
@media (prefers-reduced-motion:reduce){*{transition:none!important}}
"""

def word_html():
    w = "calma"
    return (f'<span class="big" style="--len:5">{w[:-1]}<span class="swap"><span class="spark-l" aria-hidden="true">{SPARK}</span><span class="real">{w[-1]}</span></span></span>')

chs = "".join(f'<article class="ch" data-i="{i}"><p class="num">.0{i+1}</p><h2>{e(t)}</h2><p>{e(dd)}</p></article>' for i, (t, dd) in enumerate(CH))
serv_list = "".join(f'<li data-i="{i}"{" class=on" if i == 0 else ""}>{e(t)}</li>' for i, (t, _, _, _) in enumerate(SERV))
serv_img = "".join(img(i, a, "on" if k == 0 else "") for k, (_, _, i, a) in enumerate(SERV))
cita_list = "".join(f'<li data-i="{i}"{" class=on" if i == 0 else ""}>{e(t)}</li>' for i, (t, _) in enumerate(CITA))
stars = {5: "★★★★★", 4: "★★★★☆"}
revs = "".join(f'<figure class="rev"><blockquote class="q">{e(q)}</blockquote><div class="stars" aria-label="{s} de 5 estrellas">{stars[s]}</div><figcaption class="who">Paciente de ejemplo</figcaption></figure>' for q, s in REV)
mega = "".join('<span class="sp"> </span>' if c == " " else f"<span>{c}</span>" for c in "DENTISTA LOMAS")

HTML = f"""<!doctype html>
<html lang="es-MX">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>{e(N)} | Consultorio dental en Lomas de Zapopan</title>
<meta name="description" content="Dentista Lomas de Zapopan: consultorio dental en Av. de la Mancha 798, Lomas de Zapopan. Agenda tu cita por WhatsApp.">
<meta name="theme-color" content="#a9d9f1">
<link rel="icon" type="image/svg+xml" href="favicon.svg">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;800&display=swap" rel="stylesheet">
<style>{CSS}{S3D_CSS}
.s3d .word .big{{font-size:clamp(84px,19vw,250px)}}
</style>
</head>
<body>
<div class="progress" aria-hidden="true"></div>
<a class="skip" href="#main">Saltar al contenido</a>
<header class="bar"><div class="wrap"><a class="logo" href="./" aria-label="Dentista Lomas, inicio">DENTIST<i>A</i> L<i class="b">O</i>MAS</a><a class="btn sm" href="{e(WA)}">WhatsApp</a></div></header>
<main id="main">
<section class="s3d" id="atencion" data-hdr="#a9d9f1" aria-label="Dentista Lomas de Zapopan">
<div class="s3d-pin">
  <div class="s3d-intro">
    <p class="kicker">Lomas de Zapopan · Zapopan</p>
    <h1 class="word" aria-label="Tu sonrisa con calma"><span class="pre"><span class="rot">tu sonrisa</span> con</span>{word_html()}</h1>
    <span class="fly f1" aria-hidden="true">{SPARK}</span><span class="fly f2" aria-hidden="true">{SPARK}</span><span class="fly f3" aria-hidden="true">{SPARK}</span>
  </div>
  <div class="s3d-canvas"><div class="shadow" aria-hidden="true"></div><canvas aria-hidden="true"></canvas>
    <img class="poster" src="img/diente-3d.webp" width="900" height="900" alt="Ilustración 3D de un diente" fetchpriority="high"></div>
  <div class="s3d-chapters">{chs}</div>
  <dl class="s3d-specs"><div><dt>Ubicación</dt><dd>Lomas de Zapopan</dd></div><div><dt>Citas</dt><dd>WhatsApp</dd></div><div><dt>Atención</dt><dd>Grupo de dentistas</dd></div></dl>
  <div class="s3d-cta"><a class="btn" href="{e(WA)}" data-magnet>Agendar cita</a><span class="hint">Desliza para ver cómo te atendemos</span></div>
  <div class="s3d-progress" aria-hidden="true"><span></span><span></span><span></span></div>
</div>
</section>

<section class="blk dark" id="servicios" data-hdr="#0b0d0e" data-hdr-ink="#ffffff">
<div class="wrap">
  <h2 class="ttl" data-ttl>Servicios</h2>
  <p class="sub">Lo que hacemos en el consultorio.</p>
  <div class="split pinlist" data-count="{len(SERV)}">
    <div><ul class="alist">{serv_list}</ul><p class="desc" aria-live="polite">{e(SERV[0][1])}</p></div>
    <div class="media">{serv_img}</div>
  </div>
</div>
</section>

<section class="blk pink" id="agenda" data-hdr="#f4b6e6">
<div class="wrap">
  <h2 class="ttl" data-ttl>Tu cita</h2>
  <p class="sub">Tres pasos, sin prisa.</p>
  <div class="split pinlist" data-count="{len(CITA)}">
    <div><ul class="alist">{cita_list}</ul><p class="desc" aria-live="polite">{e(CITA[0][1])}</p></div>
    <div class="bignum" aria-hidden="true"><div class="col"><span>0</span></div><div class="col roll"><span>1</span><span>2</span><span>3</span></div></div>
  </div>
</div>
</section>

<section class="blk grey" id="resenas" data-hdr="#bcbfbf">
<div class="wrap">
  <h2 class="ttl" data-ttl>Reseñas</h2>
  <p class="notice">Reseñas de ejemplo para esta demostración. En la página final se muestran sus reseñas reales de Google.</p>
  <div class="revs">{revs}</div>
  <div class="dots" aria-hidden="true"><span class="on">01</span><span>02</span><span>03</span></div>
</div>
</section>

<section class="blk white" id="visita" data-hdr="#f6f6f3">
<div class="wrap">
  <h2 class="ttl" data-ttl>Visítanos</h2>
  <dl class="rows">
    <div><dt>Dirección</dt><dd>{e(DIR)}</dd></div>
    <div><dt>Horario</dt><dd>Pregúntanos por WhatsApp</dd></div>
    <div><dt>Teléfono y WhatsApp</dt><dd><a href="tel:+52{TEL}">{TELF}</a></dd></div>
    <div><dt>Correo</dt><dd><a href="mailto:{MAIL}">{MAIL}</a></dd></div>
  </dl>
  <div class="map"><iframe src="https://www.google.com/maps?q={Q}&output=embed" title="Mapa de {e(N)}" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
  <div class="cta-row"><a class="btn" href="{e(WA)}" data-magnet>Escribir por WhatsApp</a><a class="btn" style="background:transparent;color:var(--ink);box-shadow:inset 0 0 0 1.5px var(--ink)" href="https://www.google.com/maps/search/?api=1&amp;query={Q}">Abrir en Google Maps</a></div>
</div>
</section>
</main>
<footer data-hdr="#0b0d0e" data-hdr-ink="#ffffff">
<div class="wrap">
  <div class="mega" aria-label="Dentista Lomas">{mega}</div>
  <p class="tag">Tu sonrisa, con calma.</p>
  <nav class="flinks" aria-label="Pie de página"><a href="#servicios">Servicios</a><a href="#agenda">Tu cita</a><a href="#visita">Ubicación</a><a href="{e(WA)}">WhatsApp</a><a href="terminos/">Términos y condiciones</a><a href="privacidad/">Aviso de privacidad</a></nav>
  <p class="fnote">{e(N)}, {e(DIR)} Tel. {TELF}. Página de muestra preparada para {e(N)}. Los datos vienen de su información pública y se pueden ajustar. Fotos ilustrativas de Pixabay.</p>
</div>
</footer>
"""

CFG = json.dumps(build4.CFG["diente"])
JS = r"""
<script src="https://cdn.jsdelivr.net/npm/lenis@1.3.4/dist/lenis.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.13.0/dist/gsap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.13.0/dist/ScrollTrigger.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.13.0/dist/SplitText.min.js"></script>
<script>
(function(){
  var root = document.documentElement, hdr = document.querySelector('header.bar');
  // encabezado del color de la sección visible (también sin animaciones)
  var secs = [].slice.call(document.querySelectorAll('[data-hdr]'));
  function paint(){ var y = 70, cur = secs[0];
    secs.forEach(function(s){ if (s.getBoundingClientRect().top <= y) cur = s; });
    if (cur.classList.contains('s3d') && root.classList.contains('m3d')) return;
    hdr.style.setProperty('--hdr', cur.getAttribute('data-hdr')); hdr.style.setProperty('--hdr-ink', cur.getAttribute('data-hdr-ink') || '#0b0d0e'); }
  addEventListener('scroll', paint, {passive:true}); paint();
  // carrusel de reseñas: 01 02 03
  var revs = document.querySelector('.revs'), dots = [].slice.call(document.querySelectorAll('.dots span'));
  revs && revs.addEventListener('scroll', function(){ var i = Math.round(revs.scrollLeft / (revs.firstElementChild.offsetWidth + 16));
    dots.forEach(function(d, k){ d.classList.toggle('on', k === i); }); }, {passive:true});
  if (matchMedia('(prefers-reduced-motion: reduce)').matches || !window.gsap || !window.ScrollTrigger) return;
  gsap.registerPlugin(ScrollTrigger, window.SplitText ? SplitText : null);
  root.classList.add('motion');
  var lenis = null;
  if (window.Lenis) { lenis = new Lenis({ duration: 1.1 }); lenis.on('scroll', ScrollTrigger.update); gsap.ticker.add(function(t){ lenis.raf(t * 1000); }); gsap.ticker.lagSmoothing(0); }
  document.querySelectorAll('a[href^="#"]').forEach(function(a){ a.addEventListener('click', function(ev){ var id = a.getAttribute('href'); if (id.length < 2) return; var el = document.querySelector(id); if (!el) return;
    ev.preventDefault(); lenis ? lenis.scrollTo(el, { offset: -60 }) : el.scrollIntoView({behavior:'smooth'}); }); });
  gsap.to('.progress', { scaleX: 1, ease: 'none', scrollTrigger: { trigger: document.body, start: 'top top', end: 'bottom bottom', scrub: .3 } });
  // títulos gigantes que suben por letra
  if (window.SplitText) gsap.utils.toArray('[data-ttl]').forEach(function(t){
    SplitText.create(t, { type: 'chars', mask: 'chars', autoSplit: true, onSplit: function(s){
      return gsap.from(s.chars, { yPercent: 105, duration: .9, ease: 'expo.out', stagger: .035, scrollTrigger: { trigger: t, start: 'top 85%', once: true } }); } }); });
  // listas activas con pin: servicios (imagen) y cita (número que sube)
  var mm = gsap.matchMedia();
  gsap.utils.toArray('.pinlist').forEach(function(box){
    var items = [].slice.call(box.querySelectorAll('.alist li')), n = items.length, desc = box.querySelector('.desc');
    var imgs = [].slice.call(box.querySelectorAll('.media img')), roll = box.querySelector('.roll');
    var texts = box.closest('#servicios') ? __SERV__ : __CITA__, cur = 0;
    function set(i){ if (i === cur) return; cur = i;
      items.forEach(function(li, k){ li.classList.toggle('on', k === i); }); imgs.forEach(function(im, k){ im.classList.toggle('on', k === i); });
      if (desc) gsap.fromTo(desc, { autoAlpha: 0, y: 10 }, { autoAlpha: 1, y: 0, duration: .35, onStart: function(){ desc.textContent = texts[i]; } });
      if (roll) gsap.to(roll, { yPercent: -100 * i / n, duration: .45, ease: 'power3.out', overwrite: true }); }
    ScrollTrigger.create({ trigger: box, start: 'center 58%', end: '+=' + (n * 55) + '%', pin: box.closest('.blk'), pinSpacing: true,
      onUpdate: function(self){ set(Math.min(n - 1, Math.floor(self.progress * n))); } });
  });
  // cierre: letras gigantes que se dispersan
  var L = gsap.utils.toArray('.mega span:not(.sp)');
  var sm = innerWidth < 760 ? .45 : 1;
  gsap.to(L, { y: function(){ return gsap.utils.random(10, 70) * sm; }, x: function(){ return gsap.utils.random(-18, 18) * sm; }, rotate: function(){ return gsap.utils.random(-32, 32); },
    ease: 'none', stagger: { each: .02, from: 'random' }, scrollTrigger: { trigger: 'footer', start: 'top 70%', end: 'bottom bottom', scrub: .6 } });
  // logotipo: letras giradas que se mueven un poco con el scroll
  gsap.to('.logo i', { rotate: function(i){ return i ? 12 : -14; }, ease: 'none', scrollTrigger: { trigger: document.body, start: 'top top', end: 'bottom bottom', scrub: true } });
  if (window.matchMedia('(pointer: fine)').matches) document.querySelectorAll('[data-magnet]').forEach(function(b){
    var xTo = gsap.quickTo(b, 'x', { duration: .4, ease: 'power3' }), yTo = gsap.quickTo(b, 'y', { duration: .4, ease: 'power3' });
    b.addEventListener('pointermove', function(ev){ var r = b.getBoundingClientRect(); xTo((ev.clientX - r.left - r.width / 2) * .3); yTo((ev.clientY - r.top - r.height / 2) * .4); });
    b.addEventListener('pointerleave', function(){ xTo(0); yTo(0); }); });
  window.addEventListener('load', function(){ ScrollTrigger.refresh(); });
})();
</script>"""
JS = JS.replace("__SERV__", json.dumps([s[1] for s in SERV], ensure_ascii=False)).replace("__CITA__", json.dumps([c[1] for c in CITA], ensure_ascii=False))

# Escena 3D (misma de las demás) + frase rotativa con fondos de color
J3 = build4.JS.replace("__CFG__", CFG)
J3 = J3.replace("  draw(); ST.sort(); ST.refresh();", r"""  const s3d = document.querySelector('.s3d'), COL = ['#a9d9f1', '#f4b6e6', '#8fe0c6'];
  // frase de arriba que rota mientras no hay scroll
  const rot = document.querySelector('.pre .rot'), W = ['tu sonrisa', 'tu revisión', 'tu tratamiento']; let rotI = 0;
  const tick = setInterval(() => { if (scrollY > 30) return; rotI = (rotI + 1) % W.length;
    gsap.to(rot, { yPercent: -60, autoAlpha: 0, duration: .25, ease: 'power2.in', onComplete: () => { rot.textContent = W[rotI];
      gsap.fromTo(rot, { yPercent: 60, autoAlpha: 0 }, { yPercent: 0, autoAlpha: 1, duration: .35, ease: 'power2.out' }); } });
    s3d.style.setProperty('background-color', COL[rotI], 'important'); document.querySelector('header.bar').style.setProperty('--hdr', COL[rotI]); }, 2600);
  // fondos de color por capítulo (estilo bloques)
  ST.create({ trigger: '.s3d', start: 'top top', end: '+=420%', onUpdate(self) { const p = self.progress, i = p < .53 ? 0 : (p < .76 ? 1 : 2);
    const c = p < .3 ? COL[rotI] : COL[i]; s3d.style.setProperty('background-color', c, 'important'); document.querySelector('header.bar').style.setProperty('--hdr', c); } });
  draw(); ST.sort(); ST.refresh();""")

out = HTML + JS + J3 + "\n</body>\n</html>\n"
open(os.path.join(d, "index.html"), "w").write(out)
print("ok", len(out))
