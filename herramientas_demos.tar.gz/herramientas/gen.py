import json, os, shutil, sys, html, urllib.parse
sys.path.insert(0, os.path.dirname(__file__))
from prospectos import P

BASE = os.path.dirname(__file__)
OUT = os.path.join(BASE, "main", "demos")
LIB = json.load(open(os.path.join(BASE, "px", "lib.json")))
FECHA = "5 de noviembre de 2026"

ALT = {
 "10552936": "Barbero rebajando el cabello con máquina",
 "1453064": "Sillón de barbero clásico en una barbería tradicional",
 "2165745": "Barbería con sillones de época y espejos",
 "4666064": "Estuche con tijeras sobre la estación de trabajo",
 "6560988": "Brocha, rastrillo y espejo para afeitado",
 "7576856": "Tijeras de barbero colgadas en la estación de trabajo",
 "2450766": "Consultorio dental con sillón, lámpara y monitor",
 "2589770": "Sillón dental e instrumental en un consultorio blanco",
 "2589771": "Vista superior de un sillón dental",
 "3528684": "Unidad dental con instrumental listo",
 "1761648": "Brochas de maquillaje, paleta de sombras y rizador de pestañas",
 "2693077": "Sillón de lavado de cabello en un salón de tonos cálidos",
 "3277314": "Salón de belleza con estación de lavado y estantes de productos",
 "4541766": "Estilista trabajando un peinado con ondas",
 "5653459": "Uñas pintadas de rojo con diseño de flores",
 "870857": "Esmaltes de uñas de varios colores",
 "1868726": "Auto clásico dentro de un taller lleno de herramientas",
 "1954636": "Cambio de discos de freno en un auto sobre el elevador",
 "3116534": "Motor y llanta de un auto clásico",
 "3758513": "Equipo de alineación montado en la llanta de un auto",
 "864983": "Herramientas de taller sobre una mesa de madera",
}
POOL = {
 "barberia": ["2165745", "4666064", "6560988", "10552936"],
 "estetica": ["2693077", "3277314", "4541766", "1761648", "5653459", "870857"],
 "taller": ["1868726", "1954636", "3758513", "3116534", "864983"],
 "dental": ["2450766", "2589770", "2589771", "3528684"],
}
LIBKEY = {"barberia": "barber", "estetica": "estetica", "taller": "taller", "dental": "dental"}

THEME = {
 "barberia": dict(bg="#111110", surface="#1a1a18", raise_="#22221f", text="#f2ede4", muted="#b0a99d", line="#2f2e2a", on="#111110", dark=True,
                  fonts="family=Cormorant+Garamond:wght@500;600;700&family=Work+Sans:wght@400;500;600",
                  head='"Cormorant Garamond",Georgia,serif', body='"Work Sans",-apple-system,"Segoe UI",Roboto,Arial,sans-serif', upper=False, radius="4px"),
 "estetica": dict(bg="#fbf7f2", surface="#f3ece4", raise_="#ece2d7", text="#2b211d", muted="#665850", line="#e2d6ca", on="#ffffff", dark=False,
                  fonts="family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=DM+Sans:wght@400;500;600",
                  head='"Fraunces",Georgia,serif', body='"DM Sans",-apple-system,"Segoe UI",Roboto,Arial,sans-serif', upper=False, radius="999px"),
 "taller": dict(bg="#121417", surface="#1b1e22", raise_="#24282d", text="#f4f4f2", muted="#a9adb3", line="#2e3238", on="#121417", dark=True,
                fonts="family=Barlow+Condensed:wght@600;700&family=Barlow:wght@400;500;600",
                head='"Barlow Condensed","Arial Narrow",Arial,sans-serif', body='"Barlow",-apple-system,"Segoe UI",Roboto,Arial,sans-serif', upper=True, radius="2px"),
 "dental": dict(bg="#f5f9fa", surface="#ffffff", raise_="#e9f1f3", text="#0f2329", muted="#4b6168", line="#d6e3e7", on="#ffffff", dark=False,
                fonts="family=Newsreader:opsz,wght@6..72,500;6..72,600&family=Inter:wght@400;500;600",
                head='"Newsreader",Georgia,serif', body='"Inter",-apple-system,"Segoe UI",Roboto,Arial,sans-serif', upper=False, radius="10px"),
}
GIRO = {
 "barberia": dict(label="Barbería", tag="Corte, barba y navaja", lede="Una barbería de colonia en {col}. Escríbenos por WhatsApp, aparta tu hora y llega directo a la silla.",
                  wa="Hola, quiero apartar un lugar en {n}.", final=("¿Te toca corte esta semana?", "Manda un mensaje y te decimos qué horarios quedan libres."),
                  steps=[("Escríbenos","Manda un mensaje con el servicio que quieres y el día que te acomoda."),("Te damos hora","Te contestamos con los horarios libres y apartas el tuyo."),("Llegas y te atendemos","Sin fila. Si se te complica, avísanos para mover la cita.")],
                  reviews=[("Me dejaron el degradado parejo y la barba bien marcada.",5),("Aparté por mensaje y me atendieron a la hora que dijeron.",5),("Buen trato y el lugar limpio. Ya voy cada dos semanas.",4)]),
 "estetica": dict(label="Estética", tag="Tu cita, sin vueltas", lede="Estética en {col}. Nos escribes, eliges el servicio y te apartamos el lugar.",
                  wa="Hola, quiero agendar una cita en {n}.", final=("¿Tienes un evento cerca?", "Escríbenos con la fecha y te confirmamos disponibilidad."),
                  steps=[("Escríbenos","Dinos qué servicio te interesa y qué día te acomoda."),("Te confirmamos","Te damos horario y lo que necesitas saber antes de llegar."),("Llegas a tu cita","Si se te complica, avísanos y la movemos.")],
                  reviews=[("Me explicaron todo antes de empezar y quedé contenta.",5),("Agendar por WhatsApp fue rápido.",5),("Lugar limpio y tranquilo. Volvería.",4)]),
 "taller": dict(label="Taller mecánico", tag="Te decimos qué tiene tu auto", lede="Taller en {col}, Zapopan. Llámanos, cuéntanos qué tiene tu auto y te decimos cuándo traerlo.",
                wa="Hola, quiero que revisen mi auto en {n}.", final=("¿Tu auto hace un ruido raro?", "Llámanos y te decimos cuándo traerlo a revisión."),
                steps=[("Llama o escribe","Cuéntanos marca, modelo y qué le notas al auto."),("Lo revisamos","Te damos fecha para traerlo y lo revisamos."),("Te explicamos antes de reparar","Te decimos qué necesita y cuánto cuesta antes de hacer el trabajo.")],
                reviews=[("Me explicaron qué tenía el carro antes de arreglarlo.",5),("Cumplieron con la fecha de entrega.",5),("Precio justo por el cambio de balatas.",4)]),
 "dental": dict(label="Consultorio dental", tag="Atención con calma", lede="Consultorio dental en {col}, Zapopan. Agenda tu cita y te explicamos el tratamiento antes de empezar.",
                wa="Hola, quiero agendar una cita en {n}.", final=("¿Toca revisión?", "Escríbenos y te damos el primer horario disponible."),
                steps=[("Agenda","Escríbenos o llama y te damos el primer horario disponible."),("Valoración","Revisamos y te explicamos opciones y costos."),("Tratamiento","Empezamos solo cuando estés de acuerdo con el plan.")],
                reviews=[("Me explicaron el tratamiento con calma y sin presión.",5),("Puntuales con la cita.",5),("Consultorio limpio y buen trato.",4)]),
}

def fmt_tel(t):
    return f"{t[:2]} {t[2:6]} {t[6:]}"

def lum(h):
    h = h.lstrip("#"); r, g, b = [int(h[i:i+2], 16) / 255 for i in (0, 2, 4)]
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)

def cr(a, b):
    la, lb = sorted([lum(a), lum(b)], reverse=True)
    return (la + 0.05) / (lb + 0.05)

def favicon(p, t):
    a = p["accent"]; bg = t["bg"] if t["dark"] else a; fg = a if t["dark"] else "#ffffff"
    letter = html.escape(p["corto"].strip('"')[0].upper())
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="12" fill="{bg}"/>'
            f'<text x="32" y="44" text-anchor="middle" font-family="Georgia,serif" font-size="36" font-weight="700" fill="{fg}">{letter}</text></svg>')

def css(t, a):
    up = "text-transform:uppercase;letter-spacing:.01em;" if t["upper"] else ""
    hover = "brightness(1.08)" if t["dark"] else "brightness(.9)"
    final_btn_text = t["text"] if t["dark"] else a
    bar = t["bg"].lstrip("#"); r, g, b = [int(bar[i:i+2], 16) for i in (0, 2, 4)]
    return f""":root{{--bg:{t['bg']};--surface:{t['surface']};--raise:{t['raise_']};--text:{t['text']};--muted:{t['muted']};--line:{t['line']};--accent:{a};--on-accent:{t['on']};--head:{t['head']};--body:{t['body']};--r:{t['radius']}}}
*{{box-sizing:border-box;margin:0;padding:0}}
html{{-webkit-text-size-adjust:100%}}
body{{background:var(--bg);color:var(--text);font-family:var(--body);font-size:17px;line-height:1.6;-webkit-font-smoothing:antialiased}}
a{{color:inherit}}
img,svg,iframe{{display:block;max-width:100%}}
.wrap{{max-width:1120px;margin:0 auto;padding:0 20px}}
.skip{{position:absolute;left:-999px}}.skip:focus{{left:16px;top:12px;background:var(--accent);color:var(--on-accent);padding:8px 12px;z-index:20}}
header.bar{{position:sticky;top:0;z-index:10;background:rgba({r},{g},{b},.94);border-bottom:1px solid var(--line)}}
header.bar .wrap{{display:flex;align-items:center;justify-content:space-between;min-height:64px;gap:16px}}
.brand{{font-family:var(--head);font-weight:700;font-size:22px;text-decoration:none;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;{up}}}
.nav{{display:none;gap:28px;font-size:15px;color:var(--muted)}}
.nav a{{text-decoration:none}}.nav a:hover{{color:var(--text)}}
.btn{{display:inline-flex;align-items:center;justify-content:center;gap:10px;min-height:48px;padding:12px 22px;border-radius:var(--r);font-weight:600;font-size:16px;text-decoration:none;background:var(--accent);color:var(--on-accent);border:1px solid var(--accent);transition:filter .15s ease}}
.btn:hover{{filter:{hover}}}
.btn.ghost{{background:transparent;color:var(--text);border-color:var(--line)}}
.btn.ghost:hover{{filter:none;border-color:var(--muted)}}
.btn.sm{{min-height:44px;padding:8px 16px;font-size:15px;flex-shrink:0}}
a:focus-visible,.btn:focus-visible{{outline:3px solid var(--accent);outline-offset:3px}}
.hero{{padding:56px 0 52px}}
.hero .grid{{display:grid;gap:40px;align-items:center}}
.kicker{{font-size:14px;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:var(--accent);margin-bottom:16px}}
h1{{font-family:var(--head);font-weight:700;font-size:clamp(46px,9vw,96px);line-height:.95;letter-spacing:-.01em;overflow-wrap:anywhere;{up}}}
h1 span{{display:block;color:var(--muted);font-weight:500;font-size:.4em;letter-spacing:0;margin-top:14px;line-height:1.15;text-transform:none}}
.lede{{color:var(--muted);font-size:clamp(18px,2.1vw,20px);max-width:42ch;margin:24px 0 30px}}
.actions{{display:flex;flex-wrap:wrap;gap:12px}}
.photo{{border:1px solid var(--line);border-radius:8px;overflow:hidden;aspect-ratio:4/5;max-height:560px;background:var(--surface)}}.photo img{{width:100%;height:100%;object-fit:cover}}
.band img{{width:100%;height:auto;aspect-ratio:21/9;object-fit:cover;border-radius:8px;border:1px solid var(--line)}}
.facts{{border-top:1px solid var(--line);border-bottom:1px solid var(--line)}}
.facts ul{{list-style:none;display:grid;grid-template-columns:1fr}}
.facts li{{padding:18px 0;border-bottom:1px solid var(--line);font-size:16px;color:var(--muted)}}
.facts li:last-child{{border-bottom:0}}
.facts b{{display:block;font-family:var(--head);font-size:24px;font-weight:600;color:var(--text);line-height:1.2;{up}}}
section.block{{padding:76px 0}}
.head{{display:flex;justify-content:space-between;align-items:end;gap:20px;margin-bottom:28px;flex-wrap:wrap}}
h2{{font-family:var(--head);font-weight:700;font-size:clamp(34px,5.2vw,54px);line-height:1.02;{up}}}
.sub{{color:var(--muted);max-width:42ch}}
.svc{{list-style:none;border-top:1px solid var(--line)}}
.svc li{{display:grid;grid-template-columns:1fr;gap:4px;padding:22px 0;border-bottom:1px solid var(--line)}}
.svc h3{{font-family:var(--head);font-size:26px;font-weight:600;line-height:1.15;{up}}}
.svc p{{color:var(--muted)}}
.svc .note{{color:var(--accent);font-size:14px;font-weight:600}}
.steps{{display:grid;gap:16px;counter-reset:s;list-style:none}}
.steps li{{background:var(--surface);border:1px solid var(--line);border-radius:8px;padding:24px;counter-increment:s}}
.steps li::before{{content:counter(s);display:block;font-family:var(--head);font-size:42px;font-weight:700;color:var(--accent);line-height:1;margin-bottom:10px}}
.steps h3{{font-size:18px;margin-bottom:6px}}
.steps p{{color:var(--muted);font-size:16px}}
.notice{{border:1px dashed var(--muted);border-radius:6px;padding:10px 14px;color:var(--muted);font-size:14px;margin-bottom:20px}}
.reviews{{display:grid;gap:16px}}
.review{{background:var(--surface);border:1px solid var(--line);border-radius:8px;padding:24px;display:flex;flex-direction:column;gap:12px}}
.stars{{color:var(--accent);letter-spacing:3px}}
.review blockquote{{font-family:var(--head);font-size:22px;line-height:1.3}}
.who{{color:var(--muted);font-size:14px;margin-top:auto}}
.loc{{display:grid;gap:28px}}
.map{{border:1px solid var(--line);border-radius:8px;overflow:hidden;aspect-ratio:4/3;background:var(--surface)}}
.map iframe{{width:100%;height:100%;border:0}}
dl{{display:grid;gap:22px}}
dt{{color:var(--muted);font-size:14px;margin-bottom:2px}}
dd{{font-size:19px}}
.link{{color:var(--accent);font-weight:600;text-underline-offset:3px}}
.final{{background:var(--accent);color:var(--on-accent);border-radius:8px;padding:44px 24px}}
.final h2{{color:var(--on-accent)}}
.final p{{margin:14px 0 26px;max-width:40ch;font-size:18px}}
.final .btn{{background:var(--on-accent);color:{final_btn_text};border-color:var(--on-accent)}}
footer{{padding:44px 0 60px;color:var(--muted);font-size:14px;border-top:1px solid var(--line);margin-top:80px}}
footer nav{{display:flex;flex-wrap:wrap;gap:20px;margin-bottom:14px}}
footer p+p{{margin-top:6px}}
.legal h1{{font-size:clamp(38px,6vw,54px);line-height:1.05;margin-bottom:12px}}.legal h2{{font-size:26px;margin:32px 0 8px}}.legal p,.legal li{{margin-bottom:10px}}.legal ul{{padding-left:22px}}.draft{{background:var(--surface);border-left:4px solid var(--accent);padding:12px 16px;margin:20px 0 8px;font-size:15px}}
@media (min-width:760px){{.nav{{display:flex}}.hero{{padding:92px 0 80px}}.hero .grid{{grid-template-columns:1.15fr .85fr}}.facts ul{{grid-template-columns:repeat(3,1fr)}}.facts li{{border-bottom:0;border-right:1px solid var(--line);padding:22px 24px}}.facts li:first-child{{padding-left:0}}.facts li:last-child{{border-right:0}}section.block{{padding:108px 0}}.svc li{{grid-template-columns:1fr 1.3fr auto;align-items:baseline;gap:24px}}.steps{{grid-template-columns:repeat(3,1fr)}}.reviews{{grid-template-columns:repeat(3,1fr)}}.loc{{grid-template-columns:1.2fr .8fr;align-items:start}}.final{{padding:64px}}}}
"""

WA_ICON = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5a8.4 8.4 0 0 1-12.4 7.4L3 21l2.1-5.4A8.4 8.4 0 1 1 21 11.5z"/></svg>'
TEL_ICON = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></svg>'

SCRIPTS = """<link rel="stylesheet" href="https://unpkg.com/lenis@1.1.13/dist/lenis.css">
<script src="https://unpkg.com/lenis@1.1.13/dist/lenis.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
<script>
(function(){
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce || !window.gsap) return;
  gsap.registerPlugin(ScrollTrigger);
  if (window.Lenis) {
    var lenis = new Lenis({ duration: 1.1 });
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add(function(t){ lenis.raf(t * 1000); });
    gsap.ticker.lagSmoothing(0);
    document.querySelectorAll('a[href^="#"]').forEach(function(a){
      a.addEventListener('click', function(e){ var id = a.getAttribute('href'); if (id.length < 2) return; var el = document.querySelector(id); if (el){ e.preventDefault(); lenis.scrollTo(el, { offset: -72 }); } });
    });
  }
  gsap.from('.hero .kicker, .hero h1, .hero .lede, .hero .actions', { y: 18, opacity: 0, duration: .7, ease: 'power2.out', stagger: .08 });
  gsap.from('.hero .photo', { opacity: 0, duration: .9, delay: .25, ease: 'power1.out' });
  document.querySelectorAll('section.block h2').forEach(function(h){
    gsap.from(h, { y: 16, opacity: 0, duration: .6, ease: 'power2.out', scrollTrigger: { trigger: h, start: 'top 85%', once: true } });
  });
})();
</script>"""

def build(p, idx_in_giro):
    t = THEME[p["giro"]]; g = GIRO[p["giro"]]; a = p["accent"]
    n = p["nombre"]; e = html.escape
    tel = p["tel"]; wa_ok = "fijo" not in p["canal"]
    wa_url = "https://wa.me/52" + tel + "?text=" + urllib.parse.quote(g["wa"].format(n=n), safe="")
    tel_url = "tel:+52" + tel
    pool = POOL[p["giro"]]; hero_id = pool[idx_in_giro % len(pool)]; band_id = pool[(idx_in_giro + 1) % len(pool)]
    meta = {str(x["id"]): x for x in LIB[LIBKEY[p["giro"]]]}
    d = os.path.join(OUT, p["slug"]); os.makedirs(os.path.join(d, "img"), exist_ok=True)
    for pid in (hero_id, band_id):
        shutil.copy(os.path.join(BASE, "px", meta[pid]["file"]), os.path.join(d, "img", pid + ".webp"))
    hm, bm = meta[hero_id], meta[band_id]
    if wa_ok:
        cta = f'<a class="btn" href="{e(wa_url)}">{WA_ICON}Escríbenos por WhatsApp</a>'
        top = f'<a class="btn sm" href="{e(wa_url)}">WhatsApp</a>'
        cta_final = f'<a class="btn" href="{e(wa_url)}">{WA_ICON}Mandar mensaje</a>'
        reserva = ("Con cita", "Se aparta por WhatsApp o teléfono")
    else:
        cta = f'<a class="btn" href="{tel_url}">{TEL_ICON}Llamar {fmt_tel(tel)}</a>'
        top = f'<a class="btn sm" href="{tel_url}">Llamar</a>'
        cta_final = f'<a class="btn" href="{tel_url}">{TEL_ICON}Llamar ahora</a>'
        reserva = ("Por teléfono", "Llama y te damos fecha")
    lede = g["lede"].format(col=p["colonia"])
    if not wa_ok and p["giro"] != "taller":
        lede = lede.replace("Escríbenos por WhatsApp", "Llámanos")
    svc = "".join(f'<li><h3>{e(s)}</h3><p>{e(dsc)}</p><span class="note">Precio por {"WhatsApp" if wa_ok else "teléfono"}</span></li>' for s, dsc in p["servicios"])
    steps = "".join(f"<li><h3>{e(h)}</h3><p>{e(x)}</p></li>" for h, x in g["steps"])
    stars = {5: "★★★★★", 4: "★★★★☆"}
    revs = "".join(f'<figure class="review"><div class="stars" aria-label="{s} de 5 estrellas">{stars[s]}</div><blockquote>{e(q)}</blockquote><figcaption class="who">Cliente de ejemplo</figcaption></figure>' for q, s in g["reviews"])
    q = urllib.parse.quote(f'{n}, {p["dir"]}', safe="")
    horario = p["horario"] or ("Pregúntanos por WhatsApp" if wa_ok else "Pregúntanos por teléfono")
    nav = '<nav class="nav" aria-label="Secciones"><a href="{r}#servicios">Servicios</a><a href="{r}#resenas">Reseñas</a><a href="{r}#ubicacion">Ubicación</a></nav>'
    def head(title, desc, rel):
        return f"""<!doctype html>
<html lang="es-MX">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>{e(title)}</title>
<meta name="description" content="{e(desc)}">
<meta name="theme-color" content="{t['bg']}">
<link rel="icon" type="image/svg+xml" href="{rel}favicon.svg">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?{t['fonts']}&display=swap" rel="stylesheet">
<style>
{css(t, a)}</style>
</head>
<body>
<a class="skip" href="#main">Saltar al contenido</a>
<header class="bar"><div class="wrap"><a class="brand" href="{rel or './'}">{e(p['corto'])}</a>{nav.format(r=rel or './')}{top}</div></header>
"""
    footer = lambda rel: f"""<footer><div class="wrap">
<nav><a href="{rel or './'}">Inicio</a><a href="{rel}terminos/">Términos y condiciones</a><a href="{rel}privacidad/">Aviso de privacidad</a></nav>
<p>{e(n)}, {e(p['dir'])} Tel. {fmt_tel(tel)}.</p>
<p>Página de muestra preparada para {e(n)}. Los datos vienen de su información pública y se pueden ajustar.</p>
</div></footer>
"""
    desc = f"{n} en {p['colonia']}, Zapopan. {', '.join(s for s, _ in p['servicios'][:3])}."
    index = head(f"{n} | {g['label']} en {p['colonia']}, Zapopan", desc, "") + f"""<main id="main">
<section class="hero"><div class="wrap grid">
<div>
<p class="kicker">{e(g['label'])} en {e(p['colonia'])}, Zapopan</p>
<h1>{e(p['corto'])}<span>{e(g['tag'])}</span></h1>
<p class="lede">{e(lede)}</p>
<div class="actions">{cta}<a class="btn ghost" href="#ubicacion">Cómo llegar</a></div>
</div>
<figure class="photo"><img src="img/{hero_id}.webp" width="{hm['w']}" height="{hm['h']}" alt="{e(ALT[hero_id])}" fetchpriority="high"></figure>
</div></section>
<div class="facts"><div class="wrap"><ul>
<li><b>{e(p['colonia'])}</b>{e(p['dir'].split(',')[0])}, Zapopan</li>
<li><b>{reserva[0]}</b>{reserva[1]}</li>
<li><b>{len(p['servicios'])} servicios</b>{e(', '.join(s for s, _ in p['servicios'])[:60])}</li>
</ul></div></div>
<section class="block" id="servicios"><div class="wrap">
<div class="head"><h2>Servicios</h2><p class="sub">Lo que hacemos. Si buscas algo distinto, pregúntanos.</p></div>
<ul class="svc">{svc}</ul>
</div></section>
<div class="wrap band"><img src="img/{band_id}.webp" width="{bm['w']}" height="{bm['h']}" alt="{e(ALT[band_id])}" loading="lazy"></div>
<section class="block"><div class="wrap">
<div class="head"><h2>Cómo agendar</h2></div>
<ol class="steps">{steps}</ol>
</div></section>
<section class="block" id="resenas" style="padding-top:0"><div class="wrap">
<div class="head"><h2>Lo que dicen en Google</h2></div>
<p class="notice">Reseñas de ejemplo para esta demostración. En la página final se muestran sus reseñas reales de Google.</p>
<div class="reviews">{revs}</div>
</div></section>
<section class="block" id="ubicacion" style="padding-top:0"><div class="wrap">
<div class="head"><h2>Dónde estamos</h2></div>
<div class="loc">
<div class="map"><iframe src="https://www.google.com/maps?q={q}&output=embed" title="Mapa de {e(n)}" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
<dl>
<div><dt>Dirección</dt><dd>{e(p['dir'])}</dd></div>
<div><dt>Horario</dt><dd>{e(horario)}</dd></div>
<div><dt>Teléfono</dt><dd><a class="link" href="{tel_url}">{fmt_tel(tel)}</a></dd></div>
<div><a class="link" href="https://www.google.com/maps/search/?api=1&amp;query={q}">Abrir en Google Maps</a></div>
</dl>
</div>
</div></section>
<section class="wrap"><div class="final">
<h2>{e(g['final'][0])}</h2>
<p>{e(g['final'][1])}</p>
{cta_final}
</div></section>
</main>
""" + footer("") + SCRIPTS + "\n</body>\n</html>\n"
    contacto = (f'escríbenos por <a class="link" href="{e(wa_url)}">WhatsApp</a> o llama al {fmt_tel(tel)}' if wa_ok else f'llámanos al <a class="link" href="{tel_url}">{fmt_tel(tel)}</a>')
    terminos = head(f"Términos y condiciones | {n}", f"Términos y condiciones | {n}", "../") + f"""<main class="wrap legal" id="main" style="padding:56px 20px 0;max-width:760px">
<h1>Términos y condiciones</h1>
<p class="draft">Borrador para revisión de {e(n)}. Antes de publicar la página final, el negocio debe confirmar o ajustar este texto.</p>
<p>Última actualización: {FECHA}.</p>
<h2>1. Quiénes somos</h2>
<p>Este sitio pertenece a {e(n)}, con domicilio en {e(p['dir'])} Al usarlo aceptas estos términos.</p>
<h2>2. Información de servicios</h2>
<p>Los servicios descritos son informativos. Precios, disponibilidad y tiempos se confirman directamente antes de cada servicio.</p>
<h2>3. Citas y cancelaciones</h2>
<p>Las citas se agendan por WhatsApp o por teléfono. Si no puedes asistir, avísanos con anticipación para liberar el horario.</p>
<h2>4. Uso del sitio</h2>
<p>Puedes consultar y compartir este sitio para fines personales. No está permitido copiar sus textos o diseño para uso comercial sin autorización.</p>
<h2>5. Responsabilidad</h2>
<p>Procuramos que la información esté actualizada, pero puede cambiar sin aviso.</p>
<h2>6. Enlaces externos</h2>
<p>El sitio enlaza a servicios de terceros como WhatsApp y Google Maps, que tienen sus propios términos.</p>
<h2>7. Ley aplicable</h2>
<p>Estos términos se rigen por las leyes de México. Cualquier controversia se atenderá ante los tribunales competentes de Zapopan, Jalisco.</p>
<h2>8. Contacto</h2>
<p>Para cualquier duda {contacto}.</p>
</main>
""" + footer("../") + "\n</body>\n</html>\n"
    privacidad = head(f"Aviso de privacidad | {n}", f"Aviso de privacidad | {n}", "../") + f"""<main class="wrap legal" id="main" style="padding:56px 20px 0;max-width:760px">
<h1>Aviso de privacidad</h1>
<p class="draft">Borrador para revisión de {e(n)}. Debe validarse con el responsable del negocio antes de publicar la página final.</p>
<p>Última actualización: {FECHA}.</p>
<h2>Responsable</h2>
<p>{e(n)}, con domicilio en {e(p['dir'])} es responsable del uso y protección de tus datos personales, conforme a la Ley Federal de Protección de Datos Personales en Posesión de los Particulares.</p>
<h2>Datos que recabamos</h2>
<ul><li>Nombre.</li><li>Número de teléfono o WhatsApp.</li><li>La información que nos compartas al pedir una cita o cotización.</li></ul>
<p>No solicitamos datos sensibles ni financieros a través de este sitio.</p>
<h2>Para qué los usamos</h2>
<ul><li>Agendar, confirmar o cambiar tus citas.</li><li>Responder tus preguntas y enviarte cotizaciones.</li></ul>
<p>No usamos tus datos para publicidad ni los vendemos.</p>
<h2>Transferencias</h2>
<p>No compartimos tus datos con terceros, salvo que la ley lo exija.</p>
<h2>Derechos ARCO</h2>
<p>Puedes pedir acceder, rectificar, cancelar u oponerte al uso de tus datos, o revocar tu consentimiento: {contacto}. Te responderemos en un plazo máximo de 20 días hábiles.</p>
<h2>Cookies</h2>
<p>Este sitio no usa cookies de seguimiento ni herramientas de publicidad.</p>
<h2>Cambios</h2>
<p>Cualquier cambio a este aviso se publicará en esta misma página.</p>
</main>
""" + footer("../") + "\n</body>\n</html>\n"
    open(os.path.join(d, "index.html"), "w").write(index)
    for sub, txt in (("terminos", terminos), ("privacidad", privacidad)):
        os.makedirs(os.path.join(d, sub), exist_ok=True)
        open(os.path.join(d, sub, "index.html"), "w").write(txt)
    open(os.path.join(d, "favicon.svg"), "w").write(favicon(p, t))
    # contraste
    checks = {"texto/fondo": cr(t["text"], t["bg"]), "texto tenue/fondo": cr(t["muted"], t["bg"]), "acento/fondo": cr(a, t["bg"]),
              "texto botón/acento": cr(t["on"], a), "botón final": cr(t["on"], t["text"] if t["dark"] else a),
              "tenue/superficie": cr(t["muted"], t["surface"])}
    bad = {k: round(v, 2) for k, v in checks.items() if v < 4.5}
    return dict(hero=hero_id, band=band_id, bad=bad)

if __name__ == "__main__":
    cnt = {}; res = {}
    for p in P:
        i = cnt.get(p["giro"], 0) + (1 if p["giro"] == "barberia" else 0); cnt[p["giro"]] = cnt.get(p["giro"], 0) + 1
        res[p["slug"]] = build(p, i)
    json.dump(res, open(os.path.join(BASE, "gen_result.json"), "w"), indent=1)
    for k, v in res.items():
        print(k, v["hero"], v["band"], v["bad"] or "OK")
