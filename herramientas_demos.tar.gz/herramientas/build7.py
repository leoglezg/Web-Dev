"""Estilo v3 (bloques de color + 3D) para las 9 demos mejor puntuadas, con la paleta de cada empresa."""
import os, sys, json, ast, re, urllib.parse, html, subprocess
BASE = os.path.dirname(os.path.abspath(__file__)); SP = os.path.dirname(BASE)
sys.path.insert(0, BASE)
import build2, build4
from negocios import NEG
e = html.escape

def lit(path, name):
    src = open(path).read()
    return next(n.value.value for n in ast.parse(src).body if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", "") == name)
CSS6 = lit(os.path.join(BASE, "build6.py"), "CSS")
JS6 = lit(os.path.join(BASE, "build6.py"), "JS")
S3D_CSS = lit(os.path.join(BASE, "build3.py"), "CSS")

# ---------------- color ----------------
def rgb(h): h = h.lstrip("#"); return [int(h[i:i+2], 16) for i in (0, 2, 4)]
def hexc(c): return "#" + "".join(f"{max(0, min(255, round(v))):02x}" for v in c)
def mix(a, b, t): A, B = rgb(a), rgb(b); return hexc([A[i] * (1 - t) + B[i] * t for i in range(3)])
def lum(h):
    f = lambda c: c / 12.92 if c <= .03928 else ((c + .055) / 1.055) ** 2.4
    r, g, b = [v / 255 for v in rgb(h)]; return .2126 * f(r) + .7152 * f(g) + .0722 * f(b)
def cr(a, b): x, y = sorted([lum(a), lum(b)], reverse=True); return (x + .05) / (y + .05)
INK = "#0b0d0e"
def light(acc, t, need=7.0):          # tinte del color de marca con texto negro legible
    c = mix(acc, "#ffffff", t)
    while cr(INK, c) < need and t < .97: t += .03; c = mix(acc, "#ffffff", t)
    return c
VIVID = {  # tríos contrastantes para la escena 3D (marca + dos compañeros del giro)
 "aguirre-automotriz": ["#ff8f3f", "#4cc3e6", "#b9c5cd"],
 "jmv-mecanica-automotriz": ["#ffd23f", "#4cc3e6", "#b9c5cd"],
 "diesel-mecanica-paseos-del-sol": ["#ff8f3f", "#ffd23f", "#b9c5cd"],
 "chakon-barberia": ["#e3906a", "#f1e3c8", "#93b8de"],
 "barberia-locotes": ["#86c9a8", "#f1e3c8", "#e6966f"],
 "barberia-ma-la-magdalena": ["#93b4e8", "#f1e3c8", "#ec8f80"],
 "centro-odontologico-puerta-de-hierro": ["#8ec5ef", "#95e0c8", "#f3e39a"],
 "maty-guillen-estetica": ["#f2a7cf", "#f7c39f", "#c9b3ef"],
 "violette-salon": ["#c7b0f2", "#f4a9d4", "#f6c7a3"],
}
def vivid(c):
    while cr(INK, c) < 7: c = mix(c, "#ffffff", .06)
    return c
def palette(b):
    t = build2.THEMES[b["theme"]]; acc = b["acc"]
    v = [vivid(c) for c in VIVID[b['slug']]] if b['slug'] in VIVID else [light(acc, .84, 12), light(acc, .66, 9), light(acc, .5, 7)]
    ag = acc if (b['theme'] == 'taller' and cr(INK, acc) >= 7) else v[1]
    return dict(c1=v[0], c2=v[1], c3=v[2], agenda=ag,
                dark=t["feat"], grey=mix(t["sand"], "#9a9a9a", .25), paper=t["bg"], hl=(acc if cr(INK, acc) >= 7 else light(acc, .5, 7)))

# ---------------- textos por negocio ----------------
ROT = {"chakon-barberia": ["corte, barba y", "afeitado a", "rasurado a"],
       "barberia-locotes": ["cabeza y barba al", "rasurado al", "perfilado al"],
       "barberia-ma-la-magdalena": ["corte y barba con", "degradado con", "perfilado con"],
       "aguirre-automotriz": ["primero el", "frenos con", "afinación con"],
       "jmv-mecanica-automotriz": ["mecánica e", "limpieza de", "laboratorio de"],
       "diesel-mecanica-paseos-del-sol": ["motores", "mecánica", "servicio"],
       "centro-odontologico-puerta-de-hierro": ["cuidamos tu", "revisamos tu", "atendemos tu"],
       "maty-guillen-estetica": ["maquillaje de", "peinado de", "look de"],
       "violette-salon": ["novias y", "maquillaje para", "looks para"]}
TAG = {"barber": "Corte, barba y navaja.", "taller": "Primero el diagnóstico.", "dental": "Tu sonrisa, con calma.", "makeup": "Tu look, a tu medida."}
SUB = {"barber": "Lo que hacemos en la silla.", "taller": "Lo que hacemos en el taller.", "dental": "Lo que hacemos en el consultorio.", "makeup": "Lo que hacemos en el salón."}
CITA_T = {"barber": "Tu hora", "taller": "Tu revisión", "dental": "Tu cita", "makeup": "Tu cita"}

def logo(brand):
    s = brand.upper(); idx = [i for i, c in enumerate(s) if c.isalpha()]
    rot = {idx[1]: "", idx[-2]: " b"} if len(idx) > 3 else {}
    return "".join(f'<i class="{rot[i].strip()}">{e(c)}</i>' if i in rot else e(c) for i, c in enumerate(s))

def build(b):
    slug = b["slug"]; pre_list = ROT[slug]; pre0, word, specs = build4.TOP[slug]
    build2.build(b)                                         # legales, favicon e imágenes
    d = os.path.join(BASE, "out", slug); P = palette(b)
    stars_ok = b["theme"] in ("dental", "makeup")
    wa = "https://wa.me/52" + b["tel"] + "?text=" + urllib.parse.quote(b["wa_msg"], safe="")
    tel = "tel:+52" + b["tel"]; TELF = build2.ftel(b["tel"])
    main_href, main_txt = (wa, b["cta"]) if b["wa"] else (tel, f"Llamar {TELF}")
    top_btn = f'<a class="btn sm" href="{e(wa)}">WhatsApp</a>' if b["wa"] else f'<a class="btn sm" href="{tel}">Llamar</a>'
    q = urllib.parse.quote(f'{b["nombre"]}, {b["dir"]}', safe="")
    def img(i, alt, cls=""):
        w, h = build2.dims(i)
        return f'<img class="{cls}" src="img/{i}-1280.webp" srcset="img/{i}-720.webp 720w, img/{i}-1280.webp 1280w" sizes="(min-width: 900px) 45vw, 92vw" width="{w}" height="{h}" alt="{e(alt)}" loading="lazy" decoding="async">'
    SERV = [(t, x, i, a) for t, x, i, a in b["cards"]]
    CITA = b["agenda"]
    serv_list = "".join(f'<li data-i="{k}"{" class=on" if k == 0 else ""}>{e(t)}</li>' for k, (t, *_r) in enumerate(SERV))
    serv_img = "".join(img(i, a, "on" if k == 0 else "") for k, (_, _, i, a) in enumerate(SERV))
    cita_list = "".join(f'<li data-i="{k}"{" class=on" if k == 0 else ""}>{e(t)}</li>' for k, (t, _) in enumerate(CITA))
    stars = {5: "★★★★★", 4: "★★★★☆"}
    revs = "".join(f'<figure class="rev"><blockquote class="q">{e(x)}</blockquote><div class="stars" aria-label="{s} de 5 estrellas">{stars[s]}</div><figcaption class="who">{b["quien"]} de ejemplo</figcaption></figure>' for x, s in b["reviews"])
    mega = "".join('<span class="sp"> </span>' if c == " " else f"<span>{e(c)}</span>" for c in b["brand"].upper())
    chs = "".join(f'<article class="ch" data-i="{i}"><p class="num">.0{i+1}</p><h2>{e(t)}</h2><p>{e(x)}</p></article>' for i, (t, x) in enumerate(build4.CAP[b["theme"]]))
    sp = "".join(f"<div><dt>{e(k)}</dt><dd>{e(v)}</dd></div>" for k, v in specs)
    S = build4.SPARK; model = build4.MODEL[b["theme"]]
    if stars_ok:
        big = (f'<span class="big" style="--len:{len(word)}">{e(word[:-1])}<span class="swap"><span class="spark-l" aria-hidden="true">{S}</span><span class="real">{e(word[-1])}</span></span></span></h1>\n'
               f'    <span class="fly f1" aria-hidden="true">{S}</span><span class="fly f2" aria-hidden="true">{S}</span><span class="fly f3" aria-hidden="true">{S}</span>')
    else:
        big = f'<span class="big" style="--len:{len(word)}">{e(word)}</span></h1>'
    rows = [("Dirección", e(b["dir"])), ("Horario", e(b["horario"])),
            ("Teléfono y WhatsApp" if b["wa"] else "Teléfono", f'<a href="{tel}">{TELF}</a>')]
    if b.get("tel2"): rows.append(("Otro teléfono", f'<a href="tel:+52{b["tel2"]}">{build2.ftel(b["tel2"])}</a>'))
    if b.get("mail"): rows.append(("Correo", f'<a href="mailto:{b["mail"]}">{b["mail"]}</a>'))
    rows_h = "".join(f"<div><dt>{k}</dt><dd>{v}</dd></div>" for k, v in rows)
    alt3d = {"maquina": "máquina para cortar pelo", "auto": "auto", "diente": "diente", "labial": "labial"}[model]
    vars_ = (f":root{{--sky:{P['c1']};--pink:{P['agenda']};--mint:{P['c3']};--grey:{P['grey']};--yellow:{P['hl']};--paper:{P['paper']};--teal:{b['acc_text']};"
             f"--feat-acc:{b['acc']};--acc:{INK}}}.blk.dark,footer{{background:{P['dark']}}}.fly,.swap .spark-l{{color:{b['acc']}}}.fly.f2{{color:{P['c3']}}}")
    H = f"""<!doctype html>
<html lang="es-MX">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>{e(b['title'])}</title>
<meta name="description" content="{e(b['desc'])}">
<meta name="theme-color" content="{P['c1']}">
<link rel="icon" type="image/svg+xml" href="favicon.svg">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;800&display=swap" rel="stylesheet">
<style>{CSS6}{S3D_CSS}
.s3d .word .big{{white-space:nowrap;font-size:clamp(56px,calc(104vw / var(--len)),calc(1250px / var(--len)))}}
{vars_}
</style>
</head>
<body>
<div class="progress" aria-hidden="true"></div>
<a class="skip" href="#main">Saltar al contenido</a>
<header class="bar"><div class="wrap"><a class="logo" href="./" aria-label="{e(b['brand'])}, inicio">{logo(b['brand'])}</a>{top_btn}</div></header>
<main id="main">
<section class="s3d" id="{b['feat_id']}" data-hdr="{P['c1']}" aria-label="{e(b['nombre'])}">
<div class="s3d-pin">
  <div class="s3d-intro">
    <p class="kicker">{e(b['kicker'])}</p>
    <h1 class="word" aria-label="{e(pre0 + ' ' + word)}"><span class="pre"><span class="rot">{e(pre0)}</span></span>{big}
  </div>
  <div class="s3d-canvas"><div class="shadow" aria-hidden="true"></div><canvas aria-hidden="true"></canvas>
    <img class="poster" src="img/{model}-3d.webp" width="900" height="900" alt="Ilustración 3D: {alt3d}" fetchpriority="high"></div>
  <div class="s3d-chapters">{chs}</div>
  <dl class="s3d-specs">{sp}</dl>
  <div class="s3d-cta"><a class="btn" href="{e(main_href)}" data-magnet>{e(main_txt)}</a><span class="hint">Desliza para ver cómo trabajamos</span></div>
  <div class="s3d-progress" aria-hidden="true"><span></span><span></span><span></span></div>
</div>
</section>
<section class="blk dark" id="servicios" data-hdr="{P['dark']}" data-hdr-ink="#ffffff">
<div class="wrap">
  <h2 class="ttl" data-ttl>Servicios</h2>
  <p class="sub">{SUB[b['theme']]}</p>
  <div class="split pinlist" data-count="{len(SERV)}">
    <div><ul class="alist">{serv_list}</ul><p class="desc" aria-live="polite">{e(SERV[0][1])}</p></div>
    <div class="media">{serv_img}</div>
  </div>
</div>
</section>
<section class="blk pink" id="agenda" data-hdr="{P['agenda']}">
<div class="wrap">
  <h2 class="ttl" data-ttl>{CITA_T[b['theme']]}</h2>
  <p class="sub">Tres pasos, sin vueltas.</p>
  <div class="split pinlist" data-count="{len(CITA)}">
    <div><ul class="alist">{cita_list}</ul><p class="desc" aria-live="polite">{e(CITA[0][1])}</p></div>
    <div class="bignum" aria-hidden="true"><div class="col"><span>0</span></div><div class="col roll"><span>1</span><span>2</span><span>3</span></div></div>
  </div>
</div>
</section>
<section class="blk grey" id="resenas" data-hdr="{P['grey']}">
<div class="wrap">
  <h2 class="ttl" data-ttl>Reseñas</h2>
  <p class="notice">Reseñas de ejemplo para esta demostración. En la página final se muestran sus reseñas reales de Google.</p>
  <div class="revs">{revs}</div>
  <div class="dots" aria-hidden="true"><span class="on">01</span><span>02</span><span>03</span></div>
</div>
</section>
<section class="blk white" id="visita" data-hdr="{P['paper']}">
<div class="wrap">
  <h2 class="ttl" data-ttl>Visítanos</h2>
  <dl class="rows">{rows_h}</dl>
  <div class="map"><iframe src="https://www.google.com/maps?q={q}&output=embed" title="Mapa de {e(b['nombre'])}" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
  <div class="cta-row"><a class="btn" href="{e(main_href)}" data-magnet>{'Escribir por WhatsApp' if b['wa'] else 'Llamar ahora'}</a><a class="btn" style="background:transparent;color:var(--ink);box-shadow:inset 0 0 0 1.5px var(--ink)" href="https://www.google.com/maps/search/?api=1&amp;query={q}">Abrir en Google Maps</a></div>
</div>
</section>
</main>
<footer data-hdr="{P['dark']}" data-hdr-ink="#ffffff">
<div class="wrap">
  <div class="mega" aria-label="{e(b['brand'])}">{mega}</div>
  <p class="tag">{TAG[b['theme']]}</p>
  <nav class="flinks" aria-label="Pie de página"><a href="#servicios">Servicios</a><a href="#agenda">{CITA_T[b['theme']]}</a><a href="#visita">Ubicación</a><a href="{e(main_href)}">{'WhatsApp' if b['wa'] else 'Llamar'}</a><a href="terminos/">Términos y condiciones</a><a href="privacidad/">Aviso de privacidad</a></nav>
  <p class="fnote">{e(b['nombre'])}, {e(b['dir'])} Tel. {TELF}. Página de muestra preparada para {e(b['nombre'])}. Los datos vienen de su información pública y se pueden ajustar. Fotos ilustrativas de Pixabay.</p>
</div>
</footer>
"""
    js = JS6.replace("__SERV__", json.dumps([s[1] for s in SERV], ensure_ascii=False)).replace("__CITA__", json.dumps([c[1] for c in CITA], ensure_ascii=False))
    j3 = build4.JS.replace("__CFG__", json.dumps(build4.cfg_for(b)))
    COL = json.dumps([P["c1"], P["c2"], P["c3"]]); W = json.dumps(pre_list, ensure_ascii=False)
    j3 = j3.replace("  draw(); ST.sort(); ST.refresh();", f"""  const s3d = document.querySelector('.s3d'), COL = {COL}, hb = document.querySelector('header.bar');
  const rot = document.querySelector('.pre .rot'), W = {W}; let rotI = 0;
  const tick = setInterval(() => {{ if (scrollY > 30) return; rotI = (rotI + 1) % W.length;
    gsap.to(rot, {{ yPercent: -60, autoAlpha: 0, duration: .25, ease: 'power2.in', onComplete: () => {{ rot.textContent = W[rotI];
      gsap.fromTo(rot, {{ yPercent: 60, autoAlpha: 0 }}, {{ yPercent: 0, autoAlpha: 1, duration: .35, ease: 'power2.out' }}); }} }});
    s3d.style.setProperty('background-color', COL[rotI], 'important'); hb.style.setProperty('--hdr', COL[rotI]); }}, 2600);
  ST.create({{ trigger: '.s3d', start: 'top top', end: '+=420%', onUpdate(self) {{ const p = self.progress, i = p < .53 ? 0 : (p < .76 ? 1 : 2);
    const c = p < .3 ? COL[rotI] : COL[i]; s3d.style.setProperty('background-color', c, 'important'); hb.style.setProperty('--hdr', c); }} }});
  draw(); ST.sort(); ST.refresh();""")
    open(os.path.join(d, "index.html"), "w").write(H + js + j3 + "\n</body>\n</html>\n")
    # imagen fija del objeto 3D (ya renderizada antes)
    subprocess.run(["convert", os.path.join(SP, "opt", f"poster_{slug}.png"), "-trim", "+repage", "-resize", "760x760", "-background", "none",
                    "-gravity", "center", "-extent", "900x900", "-quality", "82", os.path.join(d, "img", f"{model}-3d.webp")], check=True)
    return P

if __name__ == "__main__":
    out = {}
    for b in NEG:
        if b["slug"] in ROT:
            P = build(b); out[b["slug"]] = P
            bad = [(k, round(cr(INK, P[k]), 1)) for k in ("c1", "c2", "c3", "grey", "hl", "paper") if cr(INK, P[k]) < 4.5]
            bad += [("blanco/oscuro", round(cr("#ffffff", P["dark"]), 1))] if cr("#ffffff", P["dark"]) < 4.5 else []
            print(b["slug"], P["c1"], P["c2"], P["c3"], P["dark"], "contraste OK" if not bad else bad)
    json.dump(out, open(os.path.join(BASE, "v3pal.json"), "w"), indent=0)
