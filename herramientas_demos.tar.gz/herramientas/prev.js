const {chromium}=require('playwright'); const cfgs=require('./cfgs.json');
(async()=>{const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const p=await b.newPage({viewport:{width:900,height:900}}); p.on('pageerror',e=>console.log('PE',e.message));
 for (const [k,c] of Object.entries(cfgs).filter(([k])=>!process.argv[2]||process.argv.slice(2).includes(k))) for (const ry of [0.9, 2.4]) {
  await p.goto('http://localhost:8770/lib3d/preview.html?'+k+ry+'#'+encodeURIComponent(JSON.stringify(Object.assign({pry:ry},c))));
  await p.waitForFunction(()=>document.title==='ok',null,{timeout:20000}); await p.waitForTimeout(200);
  await p.locator('#c').screenshot({path:`p_${k}_${ry}.png`,omitBackground:true}); }
 await b.close();})();
