import * as THREE from 'three';
import { MarchingCubes } from 'three/addons/objects/MarchingCubes.js';
import { mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';
import { MeshoptSimplifier } from 'meshoptimizer';
import * as M from './models.mjs';
import fs from 'fs';
await MeshoptSimplifier.ready;
const R = 128, keep = { navaja: .3, freno: .12, labial: .1, auto: .14, maquina: .2, pluma: .25 };
fs.mkdirSync('lib3d', { recursive: true });
const ONLY = process.argv.slice(2);
for (const [model, parts] of Object.entries(M)) if (!ONLY.length || ONLY.includes(model)) for (const [part, f] of Object.entries(parts)) {
  const mc = new MarchingCubes(R, new THREE.MeshBasicMaterial(), false, false, 900000), half = R / 2;
  for (let k = 0; k < R; k++) for (let j = 0; j < R; j++) for (let i = 0; i < R; i++)
    mc.field[i + j * R + k * R * R] = 80 - f((i - half) / half * 1.04, (j - half) / half * 1.04, (k - half) / half * 1.04) * 300;
  mc.update();
  const n = mc.geometry.drawRange.count, g0 = new THREE.BufferGeometry();
  g0.setAttribute('position', new THREE.BufferAttribute(mc.geometry.attributes.position.array.slice(0, n * 3), 3));
  const g = mergeVertices(g0, 1e-4), pos = g.attributes.position.array;
  const target = Math.floor(g.index.count * keep[model] / 3) * 3;
  const [out] = MeshoptSimplifier.simplify(new Uint32Array(g.index.array), pos, 3, target, 0.003, []);
  const map = new Int32Array(pos.length / 3).fill(-1), P = [], I = new Uint16Array(out.length);
  for (let i = 0; i < out.length; i++) { const v = out[i]; if (map[v] < 0) { map[v] = P.length / 3; P.push(pos[v * 3], pos[v * 3 + 1], pos[v * 3 + 2]); } I[i] = map[v]; }
  let m = 0; for (const x of P) m = Math.max(m, Math.abs(x));
  const Q = new Int16Array(P.length); for (let i = 0; i < P.length; i++) Q[i] = Math.round(P[i] / m * 32767);
  const buf = Buffer.concat([Buffer.from(new Float32Array([m, P.length / 3, I.length, 0]).buffer), Buffer.from(Q.buffer), Buffer.from(I.buffer)]);
  fs.writeFileSync(`lib3d/${model}-${part}.bin`, buf);
  console.log(model, part, 'MC', n / 3, '→', I.length / 3, 'tris,', P.length / 3, 'verts,', buf.length, 'bytes');
}
fs.copyFileSync('diente.bin', 'lib3d/diente.bin'); fs.copyFileSync('three-lite.js', 'lib3d/three-lite.js');
