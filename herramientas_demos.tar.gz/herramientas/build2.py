import math, random, os, urllib.parse, html, shutil, subprocess, json, sys

BASE = os.path.dirname(os.path.abspath(__file__))
LIB = os.path.join(BASE, "lib")
OUT = os.path.join(BASE, "out")
e = html.escape
_dims = {}
def dims(i):
    if i not in _dims:
        _dims[i] = tuple(map(int, subprocess.check_output(["identify", "-format", "%w %h", os.path.join(LIB, f"{i}-1280.webp")]).decode().split()))
    return _dims[i]

# ---------------------------------------------------------------- temas por giro
THEMES = {
 "barber": dict(bg="#f2ede4", paper="#faf7f1", sand="#e6ddcf", ink="#171512", muted="#5d554c", line="#d9cfbf",
                feat="#141210", feat2="#211d19", feat_text="#f2ede4", feat_acc="#d9a066", feat_muted="#b9ad9f",
                fonts="family=DM+Serif+Display:ital@0;1&family=Inter+Tight:wght@400;500;600",
                head='"DM Serif Display",Georgia,serif', body='"Inter Tight",-apple-system,"Segoe UI",Roboto,Arial,sans-serif',
                hw=400, upper=False, radius="18px 18px 18px 18px", pill="6px"),
 "taller": dict(bg="#eceae4", paper="#f7f6f2", sand="#dcd9d0", ink="#121417", muted="#4d5259", line="#cfcbc1",
                feat="#121417", feat2="#1d2126", feat_text="#f4f4f2", feat_acc="#f2b705", feat_muted="#a9adb3",
                fonts="family=Barlow+Condensed:ital,wght@0,600;0,700;1,600&family=Barlow:wght@400;500;600",
                head='"Barlow Condensed","Arial Narrow",Arial,sans-serif', body='"Barlow",-apple-system,"Segoe UI",Roboto,Arial,sans-serif',
                hw=700, upper=True, radius="6px 6px 6px 6px", pill="4px"),
 "dental": dict(bg="#f3f7f8", paper="#ffffff", sand="#e3edf0", ink="#0f2329", muted="#4b6168", line="#d3e1e5",
                feat="#0d2f36", feat2="#143b43", feat_text="#eef6f7", feat_acc="#7fd1d9", feat_muted="#a9c6cb",
                fonts="family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,500;1,6..72,400&family=Inter:wght@400;500;600",
                head='"Newsreader",Georgia,serif', body='"Inter",-apple-system,"Segoe UI",Roboto,Arial,sans-serif',
                hw=400, upper=False, radius="200px 200px 20px 20px", pill="999px"),
 "makeup": dict(bg="#f8f2f3", paper="#fffafb", sand="#efe2e5", ink="#2a1d24", muted="#685660", line="#e6d5da",
                feat="#2a1a26", feat2="#382331", feat_text="#f7eaf0", feat_acc="#e3a9c6", feat_muted="#c9aebb",
                fonts="family=Cormorant+Garamond:ital,wght@0,500;0,600;1,500&family=Manrope:wght@400;500;600",
                head='"Cormorant Garamond",Georgia,serif', body='"Manrope",-apple-system,"Segoe UI",Roboto,Arial,sans-serif',
                hw=500, upper=False, radius="240px 240px 18px 18px", pill="999px"),
}

# ---------------------------------------------------------------- ilustraciones
def ill_barber(seed=5):
    rng = random.Random(seed); cx, cy, rx, ry = 260, 150, 112, 118
    guide = (f'<path class="guide" pathLength="1" d="M{cx-rx+6} 258 C{cx-rx-4} 170 {cx-rx+10} 40 {cx} 32 C{cx+rx-10} 40 {cx+rx+4} 170 {cx+rx-6} 258"/>'
             f'<path class="guide" pathLength="1" d="M{cx-58} 262 C{cx-52} 280 {cx-50} 292 {cx-52} 300"/><path class="guide" pathLength="1" d="M{cx+58} 262 C{cx+52} 280 {cx+50} 292 {cx+52} 300"/>')
    strokes = []
    for _ in range(420):
        y = rng.uniform(46, 250); x = rng.uniform(cx - rx, cx + rx)
        if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 > .86: continue
        f = (y - 46) / 204            # 0 arriba, 1 nuca
        if rng.random() < f ** 1.6: continue   # menos densidad abajo: degradado
        L = 3 + 24 * (1 - f) ** 1.4 * rng.uniform(.75, 1.15)
        tilt = (x - cx) / rx * 6 + rng.uniform(-3, 3)
        strokes.append((y, f'<path class="st{" b" if rng.random() < .3 else ""}" pathLength="1" d="M{x:.1f} {y:.1f} l{tilt:.1f} {-L:.1f}"/>'))
    strokes.sort(key=lambda s: -s[0])     # de la nuca hacia arriba
    labels = "".join(f'<g class="pop"><line x1="400" y1="{y}" x2="430" y2="{y}"/><text x="440" y="{y+5}">#{n}</text></g>' for n, y in ((0, 245), (1, 205), (2, 160), (3, 110)))
    return (f'<svg class="ill ill-barber" viewBox="0 0 520 300" fill="none" aria-hidden="true">{guide}<g>{"".join(s for _, s in strokes)}</g>{labels}</svg>',
            "trazos")

def ill_taller():
    cx, cy, r = 260, 255, 200
    def pt(a, rr): return cx + math.cos(math.radians(a)) * rr, cy + math.sin(math.radians(a)) * rr
    x0, y0 = pt(180, r); x1, y1 = pt(360, r)
    guide = f'<path class="guide keep" pathLength="1" d="M{x0:.1f} {y0:.1f} A{r} {r} 0 0 1 {x1:.1f} {y1:.1f}"/>'
    ticks, labels = [], []
    for i in range(41):
        a = 180 + i * 4.5; major = i % 5 == 0
        ax, ay = pt(a, r - 8); bx, by = pt(a, r - (34 if major else 20))
        red = " red" if i >= 34 else ""
        ticks.append(f'<path class="st{" b" if not major else ""}{red}" pathLength="1" d="M{ax:.1f} {ay:.1f} L{bx:.1f} {by:.1f}"/>')
        if major:
            tx, ty = pt(a, r - 56); labels.append(f'<text class="pop" x="{tx:.1f}" y="{ty+6:.1f}" text-anchor="middle">{i // 5}</text>')
    nx, ny = pt(180, r - 40)
    needle = (f'<g class="needle" transform="rotate(140 {cx} {cy})"><path d="M{cx} {cy} L{nx:.1f} {ny:.1f}" stroke-width="5" stroke-linecap="round"/></g>'
              f'<circle class="hub" cx="{cx}" cy="{cy}" r="12"/><text class="pop cap" x="{cx}" y="{cy-60}" text-anchor="middle">DIAGNÓSTICO</text>')
    return (f'<svg class="ill ill-taller" viewBox="0 0 520 290" fill="none" aria-hidden="true">{guide}<g>{"".join(ticks)}</g>{"".join(labels)}{needle}</svg>', "%")

def ill_dental():
    d = ("M196 70 C214 46 246 48 260 62 C274 48 306 46 324 70 C344 98 336 140 326 166 C318 188 316 214 308 244 "
         "C302 264 286 266 282 244 C276 214 272 196 260 196 C248 196 244 214 238 244 C234 266 218 264 212 244 "
         "C204 214 202 188 194 166 C184 140 176 98 196 70 Z")
    guide = f'<path class="guide keep" pathLength="1" d="{d}"/>'
    st = ['<path class="st" pathLength="1" d="M214 88 C222 76 236 74 246 80"/>',
          '<path class="st" pathLength="1" d="M206 110 C204 124 206 138 210 150"/>',
          '<path class="st b" pathLength="1" d="M300 92 C310 104 312 120 308 136"/>']
    for k, (sx, sy, s) in enumerate(((356, 64, 18), (150, 120, 12), (372, 168, 10), (168, 220, 14), (346, 236, 9))):
        st.append(f'<path class="st spark" pathLength="1" d="M{sx} {sy-s} L{sx} {sy+s}"/><path class="st spark" pathLength="1" d="M{sx-s} {sy} L{sx+s} {sy}"/>')
    for a in range(-60, 61, 30):
        ax, ay = 260 + math.sin(math.radians(a)) * 150, 140 - math.cos(math.radians(a)) * 150
        bx, by = 260 + math.sin(math.radians(a)) * 172, 140 - math.cos(math.radians(a)) * 172
        st.append(f'<path class="st b" pathLength="1" d="M{ax:.1f} {ay:.1f} L{bx:.1f} {by:.1f}"/>')
    return (f'<svg class="ill ill-dental" viewBox="0 0 520 290" fill="none" aria-hidden="true">{guide}<g>{"".join(st)}</g></svg>', None)

def ill_makeup(colors, seed=9):
    rng = random.Random(seed)
    guide = '<rect class="guide keep" pathLength="1" x="70" y="30" width="380" height="90" rx="22"/>'
    pans = "".join(f'<circle class="pop pan" cx="{110 + i*60}" cy="75" r="22" fill="{c}"/><circle class="guide keep" pathLength="1" cx="{110 + i*60}" cy="75" r="24"/>' for i, c in enumerate(colors))
    st = []
    for row, c in enumerate(colors[:4]):
        y = 158 + row * 34
        for k in range(9):
            off = (k - 4) * 2.2; amp = rng.uniform(5, 9)
            x0 = 84 + rng.uniform(0, 14); x1 = 436 - rng.uniform(0, 30) - row * 14
            st.append(f'<path class="st sw" style="stroke:{c}" pathLength="1" d="M{x0:.1f} {y+off:.1f} C{x0+110:.1f} {y+off-amp:.1f} {x1-140:.1f} {y+off+amp:.1f} {x1:.1f} {y+off-2:.1f}"/>')
    return (f'<svg class="ill ill-makeup" viewBox="0 0 520 300" fill="none" aria-hidden="true">{guide}{pans}<g>{"".join(st)}</g></svg>', "pinceladas")

# ---------------------------------------------------------------- CSS
def css(t, acc, acc_text, on_acc, acc_hover):
    up = "text-transform:uppercase;letter-spacing:.005em;" if t["upper"] else ""
    r, g, b = [int(t["bg"][i:i+2], 16) for i in (1, 3, 5)]
    return f"""
:root{{--bg:{t['bg']};--paper:{t['paper']};--sand:{t['sand']};--ink:{t['ink']};--muted:{t['muted']};--line:{t['line']};--acc:{acc};--acc-text:{acc_text};--on-acc:{on_acc};--acc-hover:{acc_hover};--feat:{t['feat']};--feat2:{t['feat2']};--feat-text:{t['feat_text']};--feat-acc:{t['feat_acc']};--feat-muted:{t['feat_muted']};--head:{t['head']};--body:{t['body']};--pill:{t['pill']};--ease:cubic-bezier(.2,.7,.1,1)}}
*{{box-sizing:border-box;margin:0;padding:0}}html{{-webkit-text-size-adjust:100%}}
body{{background:var(--bg);color:var(--ink);font-family:var(--body);font-size:17px;line-height:1.6;-webkit-font-smoothing:antialiased;overflow-x:clip}}
a{{color:inherit}}img,svg,iframe{{display:block;max-width:100%}}
.wrap{{max-width:1200px;margin:0 auto;padding:0 20px}}
.skip{{position:absolute;left:-999px}}.skip:focus{{left:16px;top:12px;background:var(--acc);color:var(--on-acc);padding:8px 12px;z-index:50}}
a:focus-visible,.btn:focus-visible{{outline:3px solid var(--acc-text);outline-offset:3px}}
.progress{{position:fixed;inset:0 0 auto 0;height:3px;background:var(--acc);transform-origin:0 50%;transform:scaleX(0);z-index:40}}
header.bar{{position:fixed;inset:0 0 auto 0;z-index:30;transition:background-color .3s var(--ease),box-shadow .3s var(--ease)}}
header.bar.solid{{background:rgba({r},{g},{b},.98);box-shadow:0 1px 0 var(--line)}}
header.bar .wrap{{display:flex;align-items:center;justify-content:space-between;gap:16px;min-height:68px}}
.brand{{text-decoration:none;display:flex;flex-direction:column;line-height:1;min-width:0}}
.brand b{{font-family:var(--head);font-weight:{t['hw']};font-size:26px;letter-spacing:-.01em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;{up}}}
.brand small{{font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:var(--muted);margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
.nav{{display:none;gap:30px;font-size:15px}}.nav a{{text-decoration:none;color:var(--muted)}}.nav a:hover{{color:var(--ink)}}
.btn{{display:inline-flex;align-items:center;justify-content:center;gap:10px;min-height:50px;padding:12px 24px;border-radius:var(--pill);font-weight:600;font-size:16px;text-decoration:none;background:var(--acc);color:var(--on-acc);border:1px solid var(--acc);transition:background-color .2s var(--ease),color .2s var(--ease)}}
.btn:hover{{background:var(--acc-hover);border-color:var(--acc-hover)}}
.btn.ghost{{background:transparent;color:var(--ink);border-color:var(--ink)}}.btn.ghost:hover{{background:var(--ink);color:var(--bg)}}
.btn.sm{{min-height:44px;padding:8px 18px;font-size:15px;flex-shrink:0}}
.kicker{{display:inline-flex;align-items:center;gap:10px;font-size:13px;font-weight:600;letter-spacing:.16em;text-transform:uppercase;color:var(--acc-text)}}
.kicker::before{{content:"";width:28px;height:1px;background:currentColor}}
.hero{{padding:120px 0 64px}}.hero .grid{{display:grid;gap:44px;align-items:center}}
h1{{font-family:var(--head);font-weight:{t['hw']};font-size:{'clamp(40px,5.2vw,74px)' if t['upper'] else 'clamp(48px,10vw,118px)'};overflow-wrap:break-word;line-height:.96;letter-spacing:-.02em;margin:22px 0 0;{up}}}
h1 em,h2 em{{font-style:{'normal' if t['upper'] else 'italic'};color:var(--acc-text)}}
.lede{{color:var(--muted);font-size:clamp(18px,2vw,20px);max-width:40ch;margin:24px 0 30px}}
.actions{{display:flex;flex-wrap:wrap;gap:12px}}
.collage{{position:relative;min-height:440px}}
.collage .main{{position:relative;width:78%;margin-left:auto;aspect-ratio:4/5;border-radius:{t['radius']};overflow:hidden;background:var(--sand)}}
.collage .main img{{width:100%;height:115%;object-fit:cover}}
.collage .small{{position:absolute;left:0;bottom:-24px;width:46%;aspect-ratio:1;border-radius:16px;overflow:hidden;border:8px solid var(--bg);background:var(--sand)}}
.collage .small img{{width:100%;height:100%;object-fit:cover}}
.collage .badge{{position:absolute;right:-6px;top:22px;width:118px;height:118px}}
.badge circle.o{{fill:var(--paper);stroke:var(--line)}}.badge circle.d{{fill:var(--acc)}}
.badge text{{font-family:var(--body);font-size:9.4px;letter-spacing:.22em;text-transform:uppercase;fill:var(--ink)}}
.marquee{{border-block:1px solid var(--line);overflow:hidden;padding:18px 0;background:var(--paper)}}
.marquee .track{{display:flex;width:max-content}}
.marquee span{{font-family:var(--head);font-weight:{t['hw']};font-size:clamp(26px,4vw,44px);font-style:{'normal' if t['upper'] else 'italic'};white-space:nowrap;padding-right:40px;{up}}}
.marquee span i{{font-style:normal;color:var(--acc-text);padding-left:40px}}
.feat{{background:var(--feat);color:var(--feat-text)}}
.feat .wrap{{display:grid;gap:40px;padding-top:96px;padding-bottom:96px}}
h2{{font-family:var(--head);font-weight:{t['hw']};font-size:clamp(40px,6vw,76px);line-height:1;letter-spacing:-.015em;{up}}}
.feat h2 em{{color:var(--feat-acc)}}.feat .kicker{{color:var(--feat-acc)}}
.feat .intro{{color:var(--feat-muted);max-width:44ch;margin-top:18px;font-size:18px}}
.steps-f{{list-style:none;display:grid;gap:4px;margin-top:34px}}
.steps-f li{{padding:18px 0 18px 64px;border-top:1px solid rgba(255,255,255,.14);position:relative;transition:opacity .4s var(--ease)}}
.steps-f li:last-child{{border-bottom:1px solid rgba(255,255,255,.14)}}
.steps-f .n{{position:absolute;left:0;top:16px;font-family:var(--head);font-size:30px;color:var(--feat-acc);line-height:1}}
.steps-f h3{{font-family:var(--head);font-weight:{t['hw']};font-size:25px;{up}}}
.steps-f p{{color:var(--feat-muted);font-size:16px;margin-top:4px;max-width:42ch}}
.motion .steps-f li{{opacity:.38}}.motion .steps-f li.on{{opacity:1}}
.feat .cta-f{{margin-top:30px}}
.feat .btn{{background:var(--feat-text);color:var(--feat);border-color:var(--feat-text)}}.feat .btn:hover{{background:#fff;border-color:#fff}}
.stage{{position:relative;border-radius:20px;background:var(--feat2);padding:32px 24px 44px;display:grid;place-items:center;min-height:300px;overflow:hidden}}
.stage .ill{{width:100%;max-width:560px}}
.stage .caption{{position:absolute;left:24px;bottom:16px;font-size:13px;color:var(--feat-muted)}}
.stage .count{{position:absolute;right:24px;top:16px;font-family:var(--head);font-size:16px;color:var(--feat-acc);font-variant-numeric:tabular-nums}}
.ill .guide{{stroke:var(--feat-acc);stroke-width:1.6;opacity:.75}}
.ill .st{{stroke:var(--feat-text);stroke-width:1.6;stroke-linecap:round}}.ill .st.b{{stroke:var(--feat-acc);stroke-width:1.3}}
.ill-barber .pop line{{stroke:var(--feat-muted);stroke-dasharray:3 3}}.ill-barber .pop text{{fill:var(--feat-muted);font:600 15px var(--body)}}
.ill-taller .guide{{stroke-width:3;opacity:1;stroke:var(--feat-muted)}}.ill-taller .st{{stroke-width:4}}.ill-taller .st.b{{stroke:var(--feat-muted);stroke-width:2.2}}.ill-taller .st.red{{stroke:#ff6a4d}}
.ill-taller text{{fill:var(--feat-text);font:700 22px var(--head)}}.ill-taller text.cap{{font:600 13px var(--body);letter-spacing:.24em;fill:var(--feat-muted)}}
.ill-taller .needle path{{stroke:var(--feat-acc)}}.ill-taller .hub{{fill:var(--feat-acc)}}
.ill-dental .guide{{stroke:var(--feat-text);stroke-width:4;opacity:1}}.ill-dental .st{{stroke:var(--feat-acc);stroke-width:4}}.ill-dental .st.b{{stroke-width:2.5;opacity:.8}}.ill-dental .spark{{stroke:var(--feat-text);stroke-width:2.5}}
.ill-makeup .guide{{stroke:var(--feat-muted);stroke-width:2;opacity:1}}.ill-makeup .st{{stroke-width:2.6}}
section.block{{padding:96px 0}}
.head{{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:end;gap:20px;margin-bottom:40px}}.head p{{color:var(--muted);max-width:40ch}}
.cards{{display:grid;gap:22px}}
.card{{background:var(--paper);border:1px solid var(--line);border-radius:18px;overflow:hidden;display:flex;flex-direction:column}}
.card .ph{{aspect-ratio:4/3;overflow:hidden;background:var(--sand)}}.card .ph img{{width:100%;height:100%;object-fit:cover}}
.card .tx{{padding:22px 22px 26px}}.card h3{{font-family:var(--head);font-weight:{t['hw']};font-size:28px;line-height:1.1;{up}}}
.card p{{color:var(--muted);margin-top:8px}}.card .note{{display:inline-block;margin-top:14px;font-size:14px;font-weight:600;color:var(--acc-text)}}
.galeria{{background:var(--paper);border-block:1px solid var(--line);overflow:hidden}}.galeria .wrap.top{{padding-top:90px}}
.gal-viewport{{overflow-x:auto;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;padding:34px 0 90px}}
.gal-track{{display:flex;gap:18px;padding:0 20px;width:max-content}}
.gal-track figure{{scroll-snap-align:start;width:min(78vw,520px);flex:none}}
.gal-track figure .f{{aspect-ratio:4/5;border-radius:16px;overflow:hidden;background:var(--sand)}}
.gal-track figure:nth-child(even) .f{{aspect-ratio:1;margin-top:60px}}
.gal-track img{{width:100%;height:100%;object-fit:cover}}.gal-track figcaption{{font-size:14px;color:var(--muted);margin-top:10px}}
.gal-note{{font-size:14px;color:var(--muted);margin-top:12px}}
.agenda .list{{list-style:none;display:grid;gap:18px;counter-reset:a}}
.agenda li{{counter-increment:a;padding:28px;background:var(--paper);border:1px solid var(--line);border-radius:18px}}
.agenda li::before{{content:"0" counter(a);display:block;font-family:var(--head);font-weight:{t['hw']};font-size:56px;line-height:1;color:var(--acc-text);margin-bottom:12px}}
.agenda h3{{font-size:20px}}.agenda p{{color:var(--muted);margin-top:6px}}
.notice{{border:1px dashed var(--muted);border-radius:10px;padding:10px 14px;color:var(--muted);font-size:14px;margin-bottom:24px}}
.revs{{display:grid;gap:18px}}.rev{{background:var(--paper);border:1px solid var(--line);border-radius:18px;padding:26px;display:flex;flex-direction:column;gap:14px}}
.stars{{color:var(--acc-text);letter-spacing:3px}}.rev blockquote{{font-family:var(--head);font-size:23px;line-height:1.3}}.who{{color:var(--muted);font-size:14px;margin-top:auto}}
.loc{{display:grid;gap:28px}}.map{{border-radius:18px;overflow:hidden;aspect-ratio:4/3;background:var(--sand);border:1px solid var(--line)}}.map iframe{{width:100%;height:100%;border:0}}
dl{{display:grid;gap:22px}}dt{{color:var(--muted);font-size:14px}}dd{{font-size:19px;overflow-wrap:anywhere}}
.link{{color:var(--acc-text);font-weight:600;text-underline-offset:3px}}
.final{{background:var(--acc);color:var(--on-acc);border-radius:28px;padding:64px 24px;text-align:center;overflow:hidden}}
.final h2{{font-size:clamp(52px,11vw,140px);line-height:.92;letter-spacing:-.03em}}.final h2 em{{color:inherit}}
.final p{{margin:18px auto 30px;max-width:36ch;font-size:18px}}
.final .btn{{background:var(--on-acc);color:var(--acc);border-color:var(--on-acc)}}.final .btn:hover{{background:var(--paper);color:var(--ink);border-color:var(--paper)}}
footer{{padding:48px 0 64px;color:var(--muted);font-size:14px;border-top:1px solid var(--line);margin-top:96px}}footer nav{{display:flex;flex-wrap:wrap;gap:20px;margin-bottom:14px}}footer p+p{{margin-top:6px}}
.motion [data-reveal]{{opacity:0}}
.motion .ill .st,.motion .ill .guide{{stroke-dasharray:1;stroke-dashoffset:1}}
@media (min-width:900px){{.nav{{display:flex}}.hero{{padding:150px 0 90px}}.hero .grid{{grid-template-columns:minmax(0,1.1fr) minmax(0,.9fr)}}.collage{{min-height:600px}}
.feat .wrap{{grid-template-columns:.9fr 1.1fr;align-items:center;min-height:100vh}}.cards,.agenda .list,.revs{{grid-template-columns:repeat(3,1fr)}}
.loc{{grid-template-columns:1.2fr .8fr;align-items:start}}.final{{padding:110px 40px}}.gal-viewport{{overflow:visible;padding-bottom:110px}}
.gal-track{{padding-left:max(20px,calc((100vw - 1160px)/2))}}.gal-track figure{{width:440px}}}}
@media (prefers-reduced-motion:reduce){{*{{transition:none!important}}}}
"""

JS = r"""
<script src="https://cdn.jsdelivr.net/npm/lenis@1.3.4/dist/lenis.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.13.0/dist/gsap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.13.0/dist/ScrollTrigger.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.13.0/dist/SplitText.min.js"></script>
<script>
(function(){
  var root = document.documentElement, bar = document.querySelector('header.bar');
  function solid(){ bar.classList.toggle('solid', window.scrollY > 20); }
  window.addEventListener('scroll', solid, {passive:true}); solid();
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || !window.gsap || !window.ScrollTrigger) return;
  gsap.registerPlugin(ScrollTrigger, window.SplitText ? SplitText : null);
  root.classList.add('motion');
  var lenis = null;
  if (window.Lenis) { lenis = new Lenis({ duration: 1.15 }); lenis.on('scroll', ScrollTrigger.update); gsap.ticker.add(function(t){ lenis.raf(t * 1000); }); gsap.ticker.lagSmoothing(0); }
  document.querySelectorAll('a[href^="#"]').forEach(function(a){
    a.addEventListener('click', function(ev){ var id = a.getAttribute('href'); if (id.length < 2) return; var el = document.querySelector(id); if (!el) return;
      ev.preventDefault(); lenis ? lenis.scrollTo(el, { offset: -70 }) : el.scrollIntoView({behavior:'smooth'}); });
  });
  gsap.to('.progress', { scaleX: 1, ease: 'none', scrollTrigger: { trigger: document.body, start: 'top top', end: 'bottom bottom', scrub: .3 } });
  gsap.utils.toArray('[data-reveal]').forEach(function(el){
    gsap.fromTo(el, { autoAlpha: 0, y: 28 }, { autoAlpha: 1, y: 0, duration: .9, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 88%', once: true } });
  });
  function lines(sel, opts){ if (!window.SplitText) return;
    gsap.utils.toArray(sel).forEach(function(el){ SplitText.create(el, { type: 'lines', mask: 'lines', autoSplit: true, onSplit: function(self){
      return gsap.from(self.lines, Object.assign({ yPercent: 110, duration: 1, ease: 'expo.out', stagger: .09 }, opts ? opts(el) : {})); }}); }); }
  lines('.hero h1');
  lines('[data-lines]', function(el){ return { scrollTrigger: { trigger: el, start: 'top 85%', once: true } }; });
  var hero = gsap.timeline({ delay: .15 });
  hero.from('.hero .kicker, .hero .lede, .hero .actions', { autoAlpha: 0, y: 20, duration: .8, ease: 'power3.out', stagger: .1 }, .25)
      .from('.collage .main', { clipPath: 'inset(100% 0% 0% 0%)', duration: 1.3, ease: 'expo.inOut' }, 0)
      .from('.collage .main img', { scale: 1.25, duration: 1.6, ease: 'expo.out' }, .2)
      .from('.collage .small', { autoAlpha: 0, y: 40, duration: 1, ease: 'power3.out' }, .7)
      .from('.collage .badge', { autoAlpha: 0, scale: .6, duration: .8, ease: 'back.out(1.6)' }, 1);
  var hs = { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: true };
  gsap.to('.collage .badge', { rotate: 360, ease: 'none', scrollTrigger: hs });
  gsap.to('.collage .main img', { yPercent: -10, ease: 'none', scrollTrigger: Object.assign({}, hs) });
  gsap.to('.collage .small', { yPercent: -28, ease: 'none', scrollTrigger: Object.assign({}, hs) });
  var track = document.querySelector('.marquee .track');
  if (track) { track.innerHTML += track.innerHTML;
    var loop = gsap.to(track, { xPercent: -50, duration: 28, ease: 'none', repeat: -1 });
    ScrollTrigger.create({ onUpdate: function(self){ var v = gsap.utils.clamp(-6, 6, self.getVelocity() / 300);
      gsap.to(loop, { timeScale: (self.direction === -1 ? -1 : 1) * (1 + Math.abs(v)), duration: .3, overwrite: true }); } }); }
  // Ilustración que se dibuja con el scroll
  var sts = gsap.utils.toArray('.ill .st'), steps = gsap.utils.toArray('.steps-f li'), count = document.querySelector('.stage .count');
  var unit = count ? count.getAttribute('data-unit') : null, needle = document.querySelector('.ill .needle');
  function featTL(st){
    st.onUpdate = function(self){ var p = self.progress, i = p < .3 ? 0 : (p < .88 ? 1 : 2);
      steps.forEach(function(li, k){ li.classList.toggle('on', k === i); });
      if (count && unit){ var q = gsap.utils.clamp(0, 1, (p - .3) / .58);
        count.textContent = unit === '%' ? Math.round(q * 100) + '% revisado' : Math.round(q * sts.length) + ' / ' + sts.length + ' ' + unit; } };
    var tl = gsap.timeline({ scrollTrigger: st });
    tl.to('.ill .guide', { strokeDashoffset: 0, duration: .28, ease: 'none' })
      .to(sts, { strokeDashoffset: 0, duration: .02, ease: 'none', stagger: { each: .55 / Math.max(sts.length, 1) } }, .3);
    if (needle) tl.fromTo(needle, { rotation: -10, svgOrigin: '260 255' }, { rotation: 140, svgOrigin: '260 255', duration: .58, ease: 'power1.inOut' }, .3);
    if (document.querySelector('.ill .pop')) tl.from('.ill .pop', { autoAlpha: 0, scale: .4, transformOrigin: '50% 50%', duration: .06, stagger: .01 }, .3);
    tl.to('.ill .guide:not(.keep)', { opacity: 0, duration: .12 }, .9).to({}, { duration: .1 });
    return tl; }
  steps[0] && steps[0].classList.add('on');
  var mm = gsap.matchMedia();
  mm.add('(min-width: 900px)', function(){ featTL({ trigger: '.feat', start: 'top top', end: '+=180%', pin: true, scrub: .6 }); });
  mm.add('(max-width: 899px)', function(){ featTL({ trigger: '.stage', start: 'top 75%', end: 'bottom 25%', scrub: .6 }); });
  gsap.utils.toArray('.card').forEach(function(c, i){
    var tl = gsap.timeline({ scrollTrigger: { trigger: c, start: 'top 85%', once: true } });
    tl.from(c, { y: 50, autoAlpha: 0, duration: .9, ease: 'power3.out', delay: (i % 3) * .08 })
      .from(c.querySelector('.ph'), { clipPath: 'inset(0 0 100% 0)', duration: 1, ease: 'expo.inOut' }, '<.1')
      .from(c.querySelector('img'), { scale: 1.3, duration: 1.4, ease: 'expo.out' }, '<'); });
  mm.add('(min-width: 900px)', function(){ var t = document.querySelector('.gal-track'); var dist = function(){ return t.scrollWidth - window.innerWidth + 40; };
    gsap.to(t, { x: function(){ return -dist(); }, ease: 'none', scrollTrigger: { trigger: '.galeria', start: 'top top', end: function(){ return '+=' + dist(); }, pin: true, scrub: .6, invalidateOnRefresh: true } });
    gsap.utils.toArray('.gal-track img').forEach(function(im){ gsap.fromTo(im, { scale: 1.18 }, { scale: 1, ease: 'none', scrollTrigger: { trigger: '.galeria', start: 'top top', end: function(){ return '+=' + dist(); }, scrub: true } }); }); });
  ['.agenda li', '.rev'].forEach(function(sel){ gsap.from(sel, { y: 40, autoAlpha: 0, duration: .8, ease: 'power3.out', stagger: .12, scrollTrigger: { trigger: sel, start: 'top 85%', once: true } }); });
  if (window.SplitText) SplitText.create('.final h2', { type: 'chars', autoSplit: true, onSplit: function(self){
    return gsap.from(self.chars, { yPercent: 100, autoAlpha: 0, rotate: 6, duration: .9, ease: 'back.out(1.7)', stagger: .03, scrollTrigger: { trigger: '.final', start: 'top 75%', once: true } }); } });
  if (window.matchMedia('(pointer: fine)').matches) document.querySelectorAll('[data-magnet]').forEach(function(b){
    var xTo = gsap.quickTo(b, 'x', { duration: .4, ease: 'power3' }), yTo = gsap.quickTo(b, 'y', { duration: .4, ease: 'power3' });
    b.addEventListener('pointermove', function(ev){ var r = b.getBoundingClientRect(); xTo((ev.clientX - r.left - r.width / 2) * .3); yTo((ev.clientY - r.top - r.height / 2) * .4); });
    b.addEventListener('pointerleave', function(){ xTo(0); yTo(0); }); });
  window.addEventListener('load', function(){ ScrollTrigger.refresh(); });
})();
</script>"""

WA_ICON = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5a8.4 8.4 0 0 1-12.4 7.4L3 21l2.1-5.4A8.4 8.4 0 1 1 21 11.5z"/></svg>'
TEL_ICON = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></svg>'
ARROW = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>'

def ftel(t): return f"{t[:2]} {t[2:6]} {t[6:]}"
def img(i, alt, eager=False):
    w, h = dims(i); pri = 'fetchpriority="high"' if eager else 'loading="lazy" decoding="async"'
    return f'<img src="img/{i}-1280.webp" srcset="img/{i}-720.webp 720w, img/{i}-1280.webp 1280w" sizes="(min-width: 900px) 50vw, 100vw" width="{w}" height="{h}" alt="{e(alt)}" {pri}>'

def build(b):
    t = THEMES[b["theme"]]
    wa = "https://wa.me/52" + b["tel"] + "?text=" + urllib.parse.quote(b["wa_msg"], safe="")
    tel = "tel:+52" + b["tel"]
    if b["wa"]:
        cta = f'<a class="btn" href="{e(wa)}" data-magnet>{WA_ICON}{e(b["cta"])}</a>'; top = f'<a class="btn sm" href="{e(wa)}">WhatsApp</a>'
        cta_f = f'<a class="btn" href="{e(wa)}">{WA_ICON}{e(b["cta"])}</a>'; cta_end = f'<a class="btn" href="{e(wa)}" data-magnet>{WA_ICON}Escribir por WhatsApp</a>'
        nota = "Precio por WhatsApp"
    else:
        cta = f'<a class="btn" href="{tel}" data-magnet>{TEL_ICON}Llamar {ftel(b["tel"])}</a>'; top = f'<a class="btn sm" href="{tel}">Llamar</a>'
        cta_f = f'<a class="btn" href="{tel}">{TEL_ICON}Llamar al taller</a>'; cta_end = f'<a class="btn" href="{tel}" data-magnet>{TEL_ICON}Llamar ahora</a>'
        nota = "Precio por teléfono"
    q = urllib.parse.quote(f'{b["nombre"]}, {b["dir"]}', safe="")
    svg, unit = b["ill"]
    rel_nav = lambda rel: "".join(f'<a href="{rel or "./"}#{h}">{l}</a>' for h, l in b["nav"])
    def head(title, desc, rel=""):
        return f"""<!doctype html>
<html lang="es-MX">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>{e(title)}</title>
<meta name="description" content="{e(desc)}">
<meta name="theme-color" content="{t['bg']}">
<link rel="icon" type="image/svg+xml" href="{rel}favicon.svg">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?{t['fonts']}&display=swap" rel="stylesheet">
<style>{css(dict(t, feat_acc=b.get('feat_acc', t['feat_acc'])), b['acc'], b['acc_text'], b['on_acc'], b['acc_hover'])}</style>
</head>
<body>
<div class="progress" aria-hidden="true"></div>
<a class="skip" href="#main">Saltar al contenido</a>
<header class="bar"><div class="wrap"><a class="brand" href="{rel or './'}"><b>{e(b['brand'])}</b><small>{e(b['sub'])}</small></a>
<nav class="nav" aria-label="Secciones">{rel_nav(rel)}</nav>{top}</div></header>
"""
    otros = ""
    if b.get("tel2"): otros += f'<div><dt>Otro teléfono</dt><dd><a class="link" href="tel:+52{b["tel2"]}">{ftel(b["tel2"])}</a></dd></div>'
    if b.get("mail"): otros += f'<div><dt>Correo</dt><dd><a class="link" href="mailto:{b["mail"]}">{b["mail"]}</a></dd></div>'
    foot = lambda rel: f"""<footer><div class="wrap">
<nav><a href="{rel or './'}">Inicio</a><a href="{rel}terminos/">Términos y condiciones</a><a href="{rel}privacidad/">Aviso de privacidad</a></nav>
<p>{e(b['nombre'])}, {e(b['dir'])} Tel. {ftel(b['tel'])}.</p>
<p>Página de muestra preparada para {e(b['nombre'])}. Los datos vienen de su información pública y se pueden ajustar. Fotos ilustrativas de Pixabay.</p>
</div></footer>
"""
    stars = {5: "★★★★★", 4: "★★★★☆"}
    revs = "".join(f'<figure class="rev"><div class="stars" aria-label="{s} de 5 estrellas">{stars[s]}</div><blockquote>{e(x)}</blockquote><figcaption class="who">{b["quien"]} de ejemplo</figcaption></figure>' for x, s in b["reviews"])
    cards = "".join(f'<article class="card"><div class="ph">{img(i, a)}</div><div class="tx"><h3>{e(h)}</h3><p>{e(p)}</p><span class="note">{nota}</span></div></article>' for h, p, i, a in b["cards"])
    gal = "".join(f'<figure><div class="f">{img(i, a)}</div><figcaption>{e(a)}</figcaption></figure>' for i, a in b["gal"])
    steps = "".join(f'<li><span class="n">0{k+1}</span><h3>{e(h)}</h3><p>{e(p)}</p></li>' for k, (h, p) in enumerate(b["feat_steps"]))
    agenda = "".join(f"<li><h3>{e(h)}</h3><p>{e(p)}</p></li>" for h, p in b["agenda"])
    ribbon = "".join(f"<span>{e(x)} <i>✦</i></span>" for x in b["ribbon"])
    badge = f'<svg class="badge" viewBox="0 0 120 120" aria-hidden="true"><defs><path id="c" d="M60 60m-46 0a46 46 0 1 1 92 0a46 46 0 1 1-92 0"/></defs><circle class="o" cx="60" cy="60" r="58"/><text><textPath href="#c">{e(b["badge"])}</textPath></text><circle class="d" cx="60" cy="60" r="5"/></svg>'
    count = f'<span class="count" data-unit="{unit}" aria-hidden="true"></span>' if unit else ""
    index = head(b["title"], b["desc"]) + f"""<main id="main">
<section class="hero"><div class="wrap grid">
<div>
<p class="kicker">{e(b['kicker'])}</p>
<h1>{b['h1']}</h1>
<p class="lede">{e(b['lede'])}</p>
<div class="actions">{cta}<a class="btn ghost" href="#{b['feat_id']}">{e(b['ghost'])} {ARROW}</a></div>
</div>
<div class="collage">
<div class="main">{img(b['hero'][0], b['hero'][1], eager=True)}</div>
<div class="small">{img(b['small'][0], b['small'][1])}</div>
{badge}
</div>
</div></section>
<div class="marquee" aria-hidden="true"><div class="track">{ribbon}</div></div>
<section class="feat" id="{b['feat_id']}"><div class="wrap">
<div>
<p class="kicker">{e(b['feat_kicker'])}</p>
<h2 data-lines>{b['feat_h2']}</h2>
<p class="intro">{e(b['feat_intro'])}</p>
<ol class="steps-f">{steps}</ol>
<div class="cta-f">{cta_f}</div>
</div>
<div class="stage">{svg}{count}<span class="caption">{e(b['feat_caption'])}</span></div>
</div></section>
<section class="block" id="servicios"><div class="wrap">
<div class="head"><div><p class="kicker">Servicios</p><h2 data-lines>{b['svc_h2']}</h2></div><p>{e(b['svc_p'])}</p></div>
<div class="cards">{cards}</div>
</div></section>
<section class="galeria" aria-labelledby="g-t">
<div class="wrap top"><p class="kicker">{e(b['gal_kicker'])}</p><h2 id="g-t" data-lines>{b['gal_h2']}</h2><p class="gal-note">Fotos ilustrativas. En la página final van fotos del negocio.</p></div>
<div class="gal-viewport"><div class="gal-track">{gal}</div></div>
</section>
<section class="block agenda" id="agenda"><div class="wrap">
<div class="head"><div><p class="kicker">{e(b['agenda_kicker'])}</p><h2 data-lines>{b['agenda_h2']}</h2></div></div>
<ol class="list">{agenda}</ol>
</div></section>
<section class="block" style="padding-top:0"><div class="wrap">
<div class="head"><div><p class="kicker">Reseñas</p><h2 data-lines>Lo que dicen en Google</h2></div></div>
<p class="notice">Reseñas de ejemplo para esta demostración. En la página final se muestran sus reseñas reales de Google.</p>
<div class="revs">{revs}</div>
</div></section>
<section class="block" id="visita" style="padding-top:0"><div class="wrap">
<div class="head"><div><p class="kicker">Ubicación</p><h2 data-lines>Visítanos</h2></div></div>
<div class="loc">
<div class="map" data-reveal><iframe src="https://www.google.com/maps?q={q}&output=embed" title="Mapa de {e(b['nombre'])}" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
<dl data-reveal>
<div><dt>Dirección</dt><dd>{e(b['dir'])}</dd></div>
<div><dt>Horario</dt><dd>{e(b['horario'])}</dd></div>
<div><dt>{'Teléfono y WhatsApp' if b['wa'] else 'Teléfono'}</dt><dd><a class="link" href="{tel}">{ftel(b['tel'])}</a></dd></div>
{otros}
<div><a class="link" href="https://www.google.com/maps/search/?api=1&amp;query={q}">Abrir en Google Maps</a></div>
</dl>
</div>
</div></section>
<section class="wrap"><div class="final">
<h2>{b['final_h2']}</h2>
<p>{e(b['final_p'])}</p>
{cta_end}
</div></section>
</main>
""" + foot("") + JS + "\n</body>\n</html>\n"
    contacto = (f'escríbenos por <a class="link" href="{e(wa)}">WhatsApp</a> o llama al {ftel(b["tel"])}' if b["wa"] else f'llámanos al <a class="link" href="{tel}">{ftel(b["tel"])}</a>')
    if b.get("mail"): contacto += f' o escribe a <a class="link" href="mailto:{b["mail"]}">{b["mail"]}</a>'
    legal_style = "<style>.legal{max-width:760px;padding:130px 20px 0}.legal h1{font-size:clamp(40px,7vw,64px);margin:12px 0 10px}.legal h2{font-size:28px;margin:32px 0 8px}.legal p,.legal li{margin-bottom:10px}.legal ul{padding-left:22px}.draft{background:var(--paper);border-left:4px solid var(--acc);padding:12px 16px;margin:20px 0 8px;font-size:15px}</style>"
    LJ = "<script>(function(){var b=document.querySelector('header.bar');function s(){b.classList.toggle('solid',scrollY>20)}addEventListener('scroll',s,{passive:true});s()})();</script>"
    N, D = e(b["nombre"]), e(b["dir"])
    bodies = {
     "terminos": ("Términos y condiciones", f"""<h2>1. Quiénes somos</h2><p>Este sitio pertenece a {N}, con domicilio en {D} Al usarlo aceptas estos términos.</p>
<h2>2. Información de servicios</h2><p>Los servicios descritos son informativos. Precios, disponibilidad y tiempos se confirman directamente antes de cada servicio.</p>
<h2>3. Citas y cancelaciones</h2><p>Las citas se agendan por {'WhatsApp o por ' if b['wa'] else ''}teléfono. Si no puedes asistir, avísanos con anticipación para liberar el horario.</p>
<h2>4. Uso del sitio</h2><p>Puedes consultar y compartir este sitio para fines personales. No está permitido copiar sus textos o diseño para uso comercial sin autorización.</p>
<h2>5. Responsabilidad</h2><p>Procuramos que la información esté actualizada, pero puede cambiar sin aviso. Las fotos del sitio son ilustrativas.</p>
<h2>6. Enlaces externos</h2><p>El sitio enlaza a servicios de terceros como WhatsApp y Google Maps, que tienen sus propios términos.</p>
<h2>7. Ley aplicable</h2><p>Estos términos se rigen por las leyes de México. Cualquier controversia se atenderá ante los tribunales competentes de Zapopan, Jalisco.</p>
<h2>8. Contacto</h2><p>Para cualquier duda {contacto}.</p>"""),
     "privacidad": ("Aviso de privacidad", f"""<h2>Responsable</h2><p>{N}, con domicilio en {D} es responsable del uso y protección de tus datos personales, conforme a la Ley Federal de Protección de Datos Personales en Posesión de los Particulares.</p>
<h2>Datos que recabamos</h2><ul><li>Nombre.</li><li>Número de teléfono, WhatsApp o correo.</li><li>La información que nos compartas al pedir una cita o cotización.</li></ul><p>No solicitamos datos sensibles ni financieros a través de este sitio.</p>
<h2>Para qué los usamos</h2><ul><li>Agendar, confirmar o cambiar tus citas.</li><li>Responder tus preguntas y enviarte cotizaciones.</li></ul><p>No usamos tus datos para publicidad ni los vendemos.</p>
<h2>Transferencias</h2><p>No compartimos tus datos con terceros, salvo que la ley lo exija.</p>
<h2>Derechos ARCO</h2><p>Puedes pedir acceder, rectificar, cancelar u oponerte al uso de tus datos, o revocar tu consentimiento: {contacto}. Te responderemos en un plazo máximo de 20 días hábiles.</p>
<h2>Cookies</h2><p>Este sitio no usa cookies de seguimiento ni herramientas de publicidad.</p>
<h2>Cambios</h2><p>Cualquier cambio a este aviso se publicará en esta misma página.</p>"""),
    }
    d = os.path.join(OUT, b["slug"])
    if os.path.exists(d): shutil.rmtree(d)
    os.makedirs(os.path.join(d, "img"))
    used = {b["hero"][0], b["small"][0]} | {c[2] for c in b["cards"]} | {g[0] for g in b["gal"]}
    for i in used:
        for w in (1280, 720): shutil.copy(os.path.join(LIB, f"{i}-{w}.webp"), os.path.join(d, "img"))
    open(os.path.join(d, "index.html"), "w").write(index)
    for k, (title, body) in bodies.items():
        os.makedirs(os.path.join(d, k))
        page = head(f"{title} | {b['nombre']}", f"{title} | {b['nombre']}", "../").replace("</head>", legal_style + "</head>")
        page += f"""<main class="wrap legal" id="main"><p class="kicker">{e(b['brand'])}</p><h1>{title}</h1>
<p class="draft">Borrador para revisión de {N}. Antes de publicar la página final, el negocio debe confirmar o ajustar este texto.</p>
<p>Última actualización: 5 de noviembre de 2026.</p>
{body}</main>
""" + foot("../") + LJ + "\n</body>\n</html>\n"
        open(os.path.join(d, k, "index.html"), "w").write(page)
    letter = e(b["brand"].strip('"')[0])
    open(os.path.join(d, "favicon.svg"), "w").write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="{b["acc"]}"/><text x="32" y="44" text-anchor="middle" font-family="Georgia,serif" font-size="36" font-weight="700" fill="{b["on_acc"]}">{letter}</text></svg>')
    return used

if __name__ == "__main__":
    sys.path.insert(0, BASE)
    from negocios import NEG
    only = sys.argv[1:]
    for b in NEG:
        if only and b["slug"] not in only: continue
        build(b); print("ok", b["slug"])
