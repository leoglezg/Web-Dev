"""Versión completa (3D + scroll) para las demos mejor puntuadas, con motor 3D compartido en demos/lib3d/."""
import os, re, sys, ast, json, html, urllib.parse
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import build2
from negocios import NEG
e = html.escape

# Estilos de la escena (los mismos de Dentista Lomas)
src = open(os.path.join(BASE, "build3.py")).read()
CSS = next(n.value.value for n in ast.parse(src).body if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", "") == "CSS")
CSS = CSS.replace(".s3d .word .big{display:inline-block;font-size:clamp(84px,19vw,250px);",
                  ".s3d .word .big{display:inline-block;font-size:clamp(56px,calc(104vw / var(--len)),calc(1250px / var(--len)));")
CSS += ".s3d .word .big{white-space:nowrap}.fly{color:var(--feat-acc)}.fly.f2{color:var(--acc)}.swap .spark-l{color:var(--acc)}\n"

CFG = json.load(open(os.path.join(os.path.dirname(BASE), "opt", "cfgs.json")))
SPARK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 0c.6 6.2 5.8 11.4 12 12-6.2.6-11.4 5.8-12 12-.6-6.2-5.8-11.4-12-12C6.2 11.4 11.4 6.2 12 0z"/></svg>'

CAP = {
 "barber": [("Platicamos el corte", "Nos dices cómo lo traes y cómo lo quieres antes de empezar."),
            ("Máquina y tijera", "Trabajamos por capas para que el cambio de largo no se note."),
            ("Detalle con navaja", "Marcamos contorno y nuca para dejar líneas limpias.")],
 "taller": [("Nos cuentas", "Qué ruido hace, desde cuándo y cuándo aparece."),
            ("Lo revisamos", "Revisamos el auto para encontrar la causa."),
            ("Te explicamos y cotizamos", "Te decimos qué necesita y cuánto cuesta antes de hacer el trabajo.")],
 "dental": [("Valoración", "Revisamos tu boca y te decimos qué encontramos, con calma y sin prisa."),
            ("Plan y costo", "Te explicamos las opciones y cuánto cuesta cada una antes de empezar."),
            ("Tratamiento", "Empezamos solo cuando estés de acuerdo con el plan.")],
 "makeup": [("Platicamos el look", "Nos cuentas del evento, el vestido y el estilo que buscas."),
            ("Preparamos la piel", "Elegimos tonos y base según tu piel."),
            ("Maquillaje por capas", "Lo construimos poco a poco para que se vea natural de cerca y en fotos.")],
}
MODEL = {"barber": "maquina", "taller": "auto", "dental": "diente", "makeup": "labial"}
TOP = {  # slug: (texto pequeño, palabra grande, datos laterales)
 "chakon-barberia": ("corte, barba y", "navaja", [("Ubicación", "Prados Vallarta"), ("Citas", "WhatsApp"), ("Servicios", "Corte, barba y afeitado")]),
 "barberia-locotes": ("cabeza y barba al", "filo", [("Ubicación", "La Granja"), ("Citas", "WhatsApp"), ("Servicios", "Rasurado y barba")]),
 "barberia-ma-la-magdalena": ("corte y barba con", "detalle", [("Ubicación", "La Magdalena"), ("Citas", "WhatsApp"), ("Servicios", "Corte, barba y navaja")]),
 "aguirre-automotriz": ("primero el", "diagnóstico", [("Ubicación", "Agua Fría"), ("Horario", "L–V, 8:00 a 18:00"), ("Servicios", "Afinación, frenos y suspensión")]),
 "jmv-mecanica-automotriz": ("mecánica e", "inyectores", [("Ubicación", "Las Bóvedas"), ("Citas", "WhatsApp"), ("Servicios", "Verificación e inyectores")]),
 "diesel-mecanica-paseos-del-sol": ("motores", "diésel", [("Ubicación", "Paseos del Sol"), ("Abre", "9:00 h"), ("Servicios", "Diésel y mecánica general")]),
 "centro-odontologico-puerta-de-hierro": ("cuidamos tu", "sonrisa", [("Ubicación", "Puerta de Hierro, piso 7"), ("Citas", "WhatsApp"), ("Correo", "cophgdl@gmail.com")]),
 "maty-guillen-estetica": ("maquillaje de", "novia", [("Ubicación", "Arcos de Guadalupe"), ("Citas", "WhatsApp"), ("Servicios", "Novia, eventos y peinado")]),
 "violette-salon": ("novias y", "eventos", [("Ubicación", "Arcos de Guadalupe"), ("Citas", "WhatsApp"), ("Servicios", "Maquillaje y depilación")]),
}

JS = r"""
<script type="module">
const gsap = window.gsap, ST = window.ScrollTrigger, CFG = __CFG__;
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
let hasGL = false; try { const c = document.createElement('canvas'); hasGL = !!(c.getContext('webgl2') || c.getContext('webgl')); } catch (e) {}
if (gsap && ST && hasGL && !reduce) setup();
function setup() {
  const root = document.documentElement; root.classList.add('m3d');
  const canvas = document.querySelector('.s3d-canvas canvas'), poster = document.querySelector('.s3d-canvas .poster'), shadow = document.querySelector('.s3d-canvas .shadow');
  const st = { y: -3.2, ry: -.6, rx: .18, s: .7, x: 0 }; let api = null;
  function draw() {
    if (api) api.draw(st);
    else poster.style.transform = 'translate(' + (st.x * 32) + '%,' + (-(st.y - .05) * 32) + '%) scale(' + (st.s / 1.05) + ')';
    const lift = Math.max(0, Math.min(1, 1 - Math.abs(st.y + .1) / 2.6));
    shadow.style.opacity = lift.toFixed(3); shadow.style.transform = 'translateX(' + (st.x * 18) + '%) scaleX(' + (.6 + .4 * st.s) + ')';
  }
  const chs = gsap.utils.toArray('.ch'), bars = gsap.utils.toArray('.s3d-progress span');
  const tl = gsap.timeline({ defaults: { ease: 'none' }, onUpdate: draw,
    scrollTrigger: { trigger: '.s3d', start: 'top top', end: '+=420%', pin: '.s3d-pin', scrub: .8, anticipatePin: 1, refreshPriority: 1,
      onUpdate(self) { const p = self.progress; bars.forEach((b, i) => b.style.setProperty('--p', Math.max(0, Math.min(1, (p - .3 - i * .233) / .233)))); } } });
  tl.to(st, { y: -.12, ry: .25, duration: .14, ease: 'power2.out' }, 0)
    .to('.s3d-intro', { yPercent: -60, opacity: 0, filter: 'blur(10px)', duration: .1 }, .2)
    .to('.s3d-cta', { opacity: 0, y: 30, duration: .06 }, .2)
    .to(st, { y: .05, s: 1.05, rx: .32, duration: .12, ease: 'power1.inOut' }, .2)
    .to('.s3d-specs', { autoAlpha: 1, duration: .05 }, .3);
  const SP = !!document.querySelector('.swap');
  if (SP) tl.to('.swap .spark-l', { opacity: 0, scale: .2, rotate: 90, duration: .03 }, .1)
    .fromTo('.swap .real', { opacity: 0, yPercent: 40 }, { opacity: 1, yPercent: 0, duration: .04, ease: 'back.out(3)' }, .11)
    .to('.fly', { opacity: 0, scale: 2.2, duration: .04 }, .11);
  chs.forEach((c, i) => { const t0 = .3 + i * .233;
    tl.fromTo(c, { autoAlpha: 0, x: -40, filter: 'blur(12px)' }, { autoAlpha: 1, x: 0, filter: 'blur(0px)', duration: .06 }, t0);
    if (i < chs.length - 1) tl.to(c, { autoAlpha: 0, x: 30, filter: 'blur(8px)', duration: .05 }, t0 + .19); });
  tl.to(st, { ry: .25 + Math.PI * 2, duration: .7 }, .3)
    .to(st, { x: innerWidth < 760 ? 0 : .5, duration: .2, ease: 'power1.inOut' }, .3)
    .to(st, { rx: .05, duration: .35, ease: 'sine.inOut' }, .3).to(st, { rx: .3, duration: .35, ease: 'sine.inOut' }, .65);
  if (SP) {
  gsap.set('.swap .real', { opacity: 0 }); gsap.set('.swap .spark-l', { opacity: 1 });
  gsap.to('.swap .spark-l', { rotate: 45, scale: 1.12, duration: 1.2, yoyo: true, repeat: -1, ease: 'sine.inOut' });
  gsap.utils.toArray('.fly').forEach((f, i) => gsap.fromTo(f, { opacity: 0, y: 10 }, { opacity: 1, y: -10, rotate: 90, duration: 1.6 + i * .3, yoyo: true, repeat: -1, ease: 'sine.inOut', delay: i * .25 }));
  }
  gsap.from('.s3d .word .big', { yPercent: 30, opacity: 0, duration: 1, ease: 'expo.out', delay: .1 });
  gsap.to(st, { y: -1.85, duration: 1.4, ease: 'expo.out', delay: .25, onUpdate: draw, onComplete: () => tl.invalidate() });
  draw(); ST.sort(); ST.refresh();
  // El 3D (motor compartido) se carga cuando la página ya se ve y responde
  const go = () => import('../lib3d/scene.js').then(m => m.mount(canvas, CFG)).then(a => {
    api = a; addEventListener('resize', () => { a.size(); draw(); }); draw(); requestAnimationFrame(() => root.classList.add('ready3d')); }).catch(() => {});
  const idle = () => ('requestIdleCallback' in window ? requestIdleCallback(go, { timeout: 1500 }) : setTimeout(go, 300));
  document.readyState === 'complete' ? idle() : addEventListener('load', idle, { once: true });
}
</script>"""

def cfg_for(b):
    c = json.loads(json.dumps(CFG[MODEL[b["theme"]]]))
    if b["theme"] == "taller": c["parts"][0]["color"] = b["acc"]                # carrocería del color del taller
    if b["theme"] in ("barber", "makeup"): c["parts"][1]["color"] = b["acc"]     # anillo de la máquina / barra del labial
    if b["theme"] == "taller": c["rim"] = b["acc"]
    return c

def build(b):
    pre, word, specs = TOP[b["slug"]]
    build2.build(b)
    p = os.path.join(BASE, "out", b["slug"], "index.html"); h = open(p).read()
    wa = "https://wa.me/52" + b["tel"] + "?text=" + urllib.parse.quote(b["wa_msg"], safe="")
    cta = f'<a class="btn" href="{e(wa)}" data-magnet>{e(b["cta"])}</a>' if b["wa"] else f'<a class="btn" href="tel:+52{b["tel"]}" data-magnet>Llamar {build2.ftel(b["tel"])}</a>'
    chs = "".join(f'<article class="ch" data-i="{i}"><p class="num">.0{i+1}</p><h2>{e(t)}</h2><p>{e(d)}</p></article>' for i, (t, d) in enumerate(CAP[b["theme"]]))
    sp = "".join(f"<div><dt>{e(k)}</dt><dd>{e(v)}</dd></div>" for k, v in specs)
    model = MODEL[b["theme"]]
    if b["theme"] in ("taller", "barber"):
        big = f'<span class="big" style="--len:{len(word)}">{e(word)}</span></h1>'
    else:
        big = (f'<span class="big" style="--len:{len(word)}">{e(word[:-1])}<span class="swap"><span class="spark-l" aria-hidden="true">{SPARK}</span><span class="real">{e(word[-1])}</span></span></span></h1>\n'
               f'    <span class="fly f1" aria-hidden="true">{SPARK}</span><span class="fly f2" aria-hidden="true">{SPARK}</span><span class="fly f3" aria-hidden="true">{SPARK}</span>')
    scene = f"""<section class="s3d" id="{b['feat_id']}" aria-label="{e(b['nombre'])}">
<div class="s3d-pin">
  <div class="s3d-intro">
    <p class="kicker">{e(b['kicker'])}</p>
    <h1 class="word" aria-label="{e(pre + ' ' + word)}"><span class="pre">{e(pre)}</span>{big}
  </div>
  <div class="s3d-canvas"><div class="shadow" aria-hidden="true"></div><canvas aria-hidden="true"></canvas>
    <img class="poster" src="img/{model}-3d.webp" width="900" height="900" alt="Ilustración 3D: {e({'maquina':'máquina para cortar pelo','auto':'auto','diente':'diente','labial':'labial','pluma':'pluma de microblading'}[model])}" fetchpriority="high"></div>
  <div class="s3d-chapters">{chs}</div>
  <dl class="s3d-specs">{sp}</dl>
  <div class="s3d-cta">{cta}<span class="hint">Desliza para ver cómo trabajamos</span></div>
  <div class="s3d-progress" aria-hidden="true"><span></span><span></span><span></span></div>
</div>
</section>
"""
    hero = re.search(r'<section class="hero">.*?</section>\n', h, re.S).group(0)
    marq = re.search(r'<div class="marquee".*?</div></div>\n', h, re.S).group(0)
    feat = re.search(r'<section class="feat".*?</section>\n', h, re.S).group(0)
    h = h.replace(hero, scene).replace(marq, "").replace(feat, marq)
    h = h.replace("</style>", CSS + "</style>", 1)
    h = h.replace("family=Inter:wght@400;500;600&", "family=Inter:wght@400;500;600;800&") if "family=Inter:" in h else h.replace("&display=swap", "&family=Inter:wght@800&display=swap", 1)
    J = build2.JS
    a = J.index("  var hero = gsap.timeline"); z = J.index("  var track = document.querySelector"); J = J[:a] + J[z:]
    a = J.index("  // Ilustración que se dibuja"); z = J.index("  gsap.utils.toArray('.card')"); J = J[:a] + "  var mm = gsap.matchMedia();\n" + J[z:]
    h = h.replace(build2.JS, J)
    h = h.replace("\n</body>", JS.replace("__CFG__", json.dumps(cfg_for(b))) + "\n</body>")
    h = h.replace(f'<a class="btn ghost" href="#{b["feat_id"]}">', '<a class="btn ghost" href="#servicios">')
    open(p, "w").write(h)
    return model, cfg_for(b)

if __name__ == "__main__":
    out = {}
    for b in NEG:
        if b["slug"] in TOP: out[b["slug"]] = build(b)
    json.dump(out, open(os.path.join(BASE, "top3d.json"), "w"))
    print("ok", len(out))
