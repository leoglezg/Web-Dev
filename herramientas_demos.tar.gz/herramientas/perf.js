const {chromium}=require('playwright');
const N='/tmp/claude-0/-home-user-Web-Dev/35bc8042-8169-5a4e-946f-8c0f65a30f15/scratchpad/erika/npm';
function local(u){ for (const [k,d] of [['three@0.170.0/','three-0.170.0'],['gsap@3.13.0/','gsap-3.13.0'],['lenis@1.3.4/','lenis-1.3.4']]) if(u.includes(k)) return N+'/'+d+'/package/'+u.split(k)[1]; }
(async()=>{const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 for (const slug of ['dentista-lomas-de-zapopan']){
 const p=await b.newPage({viewport:{width:390,height:844}});
 const c=await p.context().newCDPSession(p); await c.send('Emulation.setCPUThrottlingRate',{rate:4});
 const bytes={}; p.on('response',async r=>{try{const u=r.url();const l=(await r.body()).length;const k=u.includes('three')?'three':u.includes('gsap')||u.includes('lenis')?'gsap/lenis':u.match(/\.webp/)?'imágenes':u.match(/\.html|\/$/)?'html':'otros';bytes[k]=(bytes[k]||0)+l;}catch(e){}});
 await p.route('https://cdn.jsdelivr.net/**',r=>{const f=local(r.request().url()); f?r.fulfill({path:f,contentType:'application/javascript'}):r.abort();});
 await p.route(/fonts\.g|google\.com\/maps/,r=>r.abort());
 await p.addInitScript(()=>{window.__lt=[];new PerformanceObserver(l=>l.getEntries().forEach(e=>window.__lt.push([Math.round(e.startTime),Math.round(e.duration)]))).observe({type:'longtask',buffered:true});});
 const t0=Date.now(); await p.goto('http://localhost:8768/demos/'+slug+'/',{waitUntil:'load'}); const tl=Date.now()-t0;
 let t3=null; for(let i=0;i<60;i++){ if(await p.evaluate(()=>document.documentElement.classList.contains('m3d')||document.documentElement.classList.contains('motion'))){t3=Date.now()-t0;break;} await p.waitForTimeout(100);} 
 await p.waitForTimeout(4000);
 const lt=await p.evaluate(()=>window.__lt);
 console.log(slug,'load',tl,'ms; animaciones listas',t3,'ms; tareas largas (inicio,duración ms):',JSON.stringify(lt.filter(x=>x[1]>150)),'bytes:',JSON.stringify(Object.fromEntries(Object.entries(bytes).map(([k,v])=>[k,Math.round(v/1024)+' KB']))));
 await p.close();}
 await b.close();})();
