"""Erika Salón y Microblading: portada 3D (pluma de microblading) sobre su página propia, que conserva la ceja pelo a pelo."""
import os, re, sys, json, subprocess, shutil, urllib.parse, html
BASE = os.path.dirname(os.path.abspath(__file__)); SP = os.path.dirname(BASE)
sys.path.insert(0, BASE)
import build4
e = html.escape
subprocess.run([sys.executable, "-I", os.path.join(SP, "erika", "build.py")], check=True, stdout=subprocess.DEVNULL)
src = os.path.join(SP, "erika", "out"); dst = os.path.join(BASE, "out", "erika-salon-microblading")
if os.path.exists(dst): shutil.rmtree(dst)
shutil.copytree(src, dst)
p = os.path.join(dst, "index.html"); h = open(p).read()

WA = "https://wa.me/523314170577?text=" + urllib.parse.quote("Hola, quiero información de microblading.", safe="")
CH = [("Microblading", "Diseño de cejas pelo a pelo. Te explicamos el proceso y los cuidados antes de empezar."),
      ("Corte y color", "Corte, tinte y mechas. Te decimos qué tono te conviene según tu cabello."),
      ("Peinado", "Para eventos o para el día a día. Agenda con anticipación si es fecha especial.")]
SPECS = [("Ubicación", "Parques de Tesistán"), ("Citas", "WhatsApp"), ("Servicios", "Microblading y salón")]
pre, word = "diseño de", "cejas"
chs = "".join(f'<article class="ch" data-i="{i}"><p class="num">.0{i+1}</p><h2>{e(t)}</h2><p>{e(d)}</p></article>' for i, (t, d) in enumerate(CH))
sp = "".join(f"<div><dt>{e(k)}</dt><dd>{e(v)}</dd></div>" for k, v in SPECS)
S = build4.SPARK
scene = f"""<section class="s3d" id="inicio" aria-label="Erika Salón y Microblading">
<div class="s3d-pin">
  <div class="s3d-intro">
    <p class="kicker">Parques de Tesistán · Zapopan</p>
    <h1 class="word" aria-label="{e(pre + ' ' + word)}"><span class="pre">{e(pre)}</span><span class="big" style="--len:{len(word)}">{e(word[:-1])}<span class="swap"><span class="spark-l" aria-hidden="true">{S}</span><span class="real">{e(word[-1])}</span></span></span></h1>
    <span class="fly f1" aria-hidden="true">{S}</span><span class="fly f2" aria-hidden="true">{S}</span><span class="fly f3" aria-hidden="true">{S}</span>
  </div>
  <div class="s3d-canvas"><div class="shadow" aria-hidden="true"></div><canvas aria-hidden="true"></canvas>
    <img class="poster" src="img/pluma-3d.webp" width="900" height="900" alt="Ilustración 3D: pluma de microblading" fetchpriority="high"></div>
  <div class="s3d-chapters">{chs}</div>
  <dl class="s3d-specs">{sp}</dl>
  <div class="s3d-cta"><a class="btn" href="{e(WA)}" data-magnet>Pregunta por microblading</a><span class="hint">Desliza para ver nuestros servicios</span></div>
  <div class="s3d-progress" aria-hidden="true"><span></span><span></span><span></span></div>
</div>
</section>
"""
hero = re.search(r'<section class="hero">.*?</section>\n', h, re.S).group(0)
h = h.replace(hero, scene)
a = h.index("  // Hero: ceja que se dibuja"); z = h.index("  // Cinta que acelera")
h = h[:a] + h[z:]
h = h.replace("</style>", ":root{--acc:#9a3b52;--feat-acc:#c9a58c}" + build4.CSS + "</style>", 1)
h = h.replace("family=DM+Sans:wght@400;500;600", "family=DM+Sans:wght@400;500;600&family=Inter:wght@800")
cfg = json.loads(json.dumps(build4.CFG["pluma"]))
h = h.replace("\n</body>", build4.JS.replace("__CFG__", json.dumps(cfg)) + "\n</body>")
open(p, "w").write(h)
json.dump({"erika-salon-microblading": ["pluma", cfg]}, open(os.path.join(BASE, "erika3d.json"), "w"))
print("ok erika", len(h))
