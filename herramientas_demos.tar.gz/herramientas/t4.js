const {chromium}=require('playwright'); const slugs=Object.keys(require('/tmp/claude-0/-home-user-Web-Dev/35bc8042-8169-5a4e-946f-8c0f65a30f15/scratchpad/top/all3d.json'));
const N='/tmp/claude-0/-home-user-Web-Dev/35bc8042-8169-5a4e-946f-8c0f65a30f15/scratchpad/erika/npm';
function local(u){ for (const [k,d] of [['gsap@3.13.0/','gsap-3.13.0'],['lenis@1.3.4/','lenis-1.3.4']]) if(u.includes(k)) return N+'/'+d+'/package/'+u.split(k)[1]; }
(async()=>{const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
for (const [w,h,tag,fs] of [[1440,900,'d',[0.06,0.55]],[390,844,'m',[0.55]]]) for (const s of slugs){
 const p=await b.newPage({viewport:{width:w,height:h}}); const errs=[];
 p.on('pageerror',x=>errs.push(x.message)); p.on('requestfailed',r=>{if(!/fonts|maps/.test(r.url()))errs.push('fail '+r.url())});
 const c=await p.context().newCDPSession(p); if(tag==='m') await c.send('Emulation.setCPUThrottlingRate',{rate:4});
 await p.route('https://cdn.jsdelivr.net/**',r=>{const f=local(r.request().url()); f?r.fulfill({path:f,contentType:'application/javascript'}):r.abort();});
 await p.route(/fonts\.g|google\.com\/maps/,r=>r.abort());
 const t0=Date.now(); await p.goto('http://localhost:8768/demos/'+s+'/',{waitUntil:'load'});
 let ta=null; for(let i=0;i<50;i++){ if(await p.evaluate(()=>document.documentElement.classList.contains('m3d'))){ta=Date.now()-t0;break;} await p.waitForTimeout(50);} 
 let tr=null; for(let i=0;i<120;i++){ if(await p.evaluate(()=>document.documentElement.classList.contains('ready3d'))){tr=Date.now()-t0;break;} await p.waitForTimeout(100);} 
 const st=await p.evaluate(()=>{const t=ScrollTrigger.getAll().find(x=>x.trigger===document.querySelector('.s3d'));return [t.start,t.end]});
 for (const f of fs){ await p.evaluate(y=>window.scrollTo(0,y),Math.round(st[0]+(st[1]-st[0])*f)); await p.waitForTimeout(1200); await p.screenshot({path:'/tmp/claude-0/-home-user-Web-Dev/35bc8042-8169-5a4e-946f-8c0f65a30f15/scratchpad/top/shots/t4_'+tag+'_'+s+'_'+f+'.png'}); }
 const over=await p.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth);
 console.log(tag,s,'animaciones',ta,'ms; 3D listo',tr,'ms; desborde',over,errs.length?errs:'');
 await p.close();}
await b.close();})();
