"""Dentista Lomas de Zapopan: portada estilo producto (palabra + objeto que sube) y diente 3D que gira con el scroll."""
import os, re, sys
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import build2
from negocios import NEG

b = next(x for x in NEG if x["slug"] == "dentista-lomas-de-zapopan")
build2.build(b)
p = os.path.join(BASE, "out", b["slug"], "index.html")
h = open(p).read()

WA = "https://wa.me/523316995436?text=Hola%2C%20quiero%20agendar%20una%20cita%20en%20Dentista%20Lomas%20de%20Zapopan."
SPARK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 0c.6 6.2 5.8 11.4 12 12-6.2.6-11.4 5.8-12 12-.6-6.2-5.8-11.4-12-12C6.2 11.4 11.4 6.2 12 0z"/></svg>'

scene = f"""<section class="s3d" id="atencion" aria-label="Dentista Lomas de Zapopan">
<div class="s3d-pin">
  <div class="s3d-intro">
    <p class="kicker">Lomas de Zapopan · Zapopan</p>
    <h1 class="word" aria-label="Tu sonrisa con calma"><span class="pre">tu sonrisa con</span><span class="big">calm<span class="swap"><span class="spark-l" aria-hidden="true">{SPARK}</span><span class="real">a</span></span></span></h1>
    <span class="fly f1" aria-hidden="true">{SPARK}</span><span class="fly f2" aria-hidden="true">{SPARK}</span><span class="fly f3" aria-hidden="true">{SPARK}</span>
  </div>
  <div class="s3d-canvas"><div class="shadow" aria-hidden="true"></div><canvas aria-hidden="true"></canvas>
    <img class="poster" src="img/diente-3d.webp" width="900" height="900" alt="Ilustración 3D de un diente" fetchpriority="high"></div>
  <div class="s3d-chapters">
    <article class="ch" data-i="0"><p class="num">.01</p><h2>Valoración</h2><p>Revisamos tu boca y te decimos qué encontramos, con calma y sin prisa.</p></article>
    <article class="ch" data-i="1"><p class="num">.02</p><h2>Plan y costo</h2><p>Te explicamos las opciones y cuánto cuesta cada una antes de empezar.</p></article>
    <article class="ch" data-i="2"><p class="num">.03</p><h2>Tratamiento</h2><p>Empezamos solo cuando estés de acuerdo con el plan.</p></article>
  </div>
  <dl class="s3d-specs">
    <div><dt>Ubicación</dt><dd>Lomas de Zapopan</dd></div>
    <div><dt>Citas</dt><dd>WhatsApp</dd></div>
    <div><dt>Atención</dt><dd>Grupo de dentistas</dd></div>
  </dl>
  <div class="s3d-cta"><a class="btn" href="{WA}" data-magnet>Agendar cita</a><span class="hint">Desliza para ver cómo te atendemos</span></div>
  <div class="s3d-progress" aria-hidden="true"><span></span><span></span><span></span></div>
</div>
</section>
"""
# Reemplaza portada + sección destacada; conserva la cinta de servicios entre las dos
hero = re.search(r'<section class="hero">.*?</section>\n', h, re.S).group(0)
marq = re.search(r'<div class="marquee".*?</div></div>\n', h, re.S).group(0)
feat = re.search(r'<section class="feat".*?</section>\n', h, re.S).group(0)
h = h.replace(hero, scene).replace(marq, "").replace(feat, marq)

CSS = """
.s3d{position:relative;background:radial-gradient(120% 80% at 50% 30%,#ffffff 0%,var(--bg) 60%,#e6eef0 100%);overflow:hidden}
.s3d-pin{position:relative;min-height:100vh;display:grid;grid-template-rows:auto 1fr auto;padding:96px 20px 28px;max-width:1240px;margin:0 auto}
.s3d-intro{text-align:center;position:relative;z-index:3}
.s3d .word{font-family:"Inter",-apple-system,"Segoe UI",Roboto,Arial,sans-serif;font-weight:800;letter-spacing:-.06em;line-height:.86;margin:14px 0 0;text-transform:none}
.s3d .word .pre{display:block;font-family:var(--head);font-weight:400;font-style:italic;letter-spacing:-.01em;font-size:clamp(22px,3.2vw,40px);color:var(--muted);margin-bottom:6px}
.s3d .word .big{display:inline-block;font-size:clamp(84px,19vw,250px);color:var(--ink)}
.swap{position:relative;display:inline-block}
.swap .spark-l{position:absolute;left:50%;bottom:.08em;width:.62em;height:.62em;transform:translateX(-50%);color:var(--acc);opacity:0}
.swap .spark-l svg{width:100%;height:100%;fill:currentColor}
.fly{position:absolute;width:26px;height:26px;color:#7fd1d9;opacity:0}.fly svg{width:100%;height:100%;fill:currentColor}
.fly.f1{left:62%;top:18%}.fly.f2{left:70%;top:6%;width:18px;height:18px;color:#a99be8}.fly.f3{left:30%;top:24%;width:16px;height:16px}
.s3d-canvas{position:relative;width:min(520px,86vw);aspect-ratio:1;margin:-10px auto 0;z-index:2}
.s3d-canvas canvas{position:absolute;inset:0;width:100%;height:100%;display:none}
.s3d-canvas .poster{position:absolute;inset:0;width:100%;height:100%;object-fit:contain}
.s3d-canvas .shadow{display:none;position:absolute;left:18%;right:18%;bottom:4%;height:9%;border-radius:50%;background:radial-gradient(closest-side,rgba(15,35,41,.28),rgba(15,35,41,0));filter:blur(4px)}
.s3d-chapters{display:grid;gap:22px;max-width:520px;margin:24px auto 0;position:relative;z-index:3}
.ch .num{font:600 15px var(--body);color:var(--acc);letter-spacing:.06em}
.ch h2{font-family:"Inter",-apple-system,"Segoe UI",Roboto,Arial,sans-serif;font-weight:800;text-transform:uppercase;letter-spacing:-.02em;font-size:clamp(30px,4.4vw,52px);line-height:.95;margin:4px 0 10px;color:var(--ink)}
.ch p{color:var(--muted);max-width:34ch}
.s3d-specs{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;max-width:520px;margin:26px auto 0;border-top:1px solid var(--line);padding-top:16px;position:relative;z-index:3}
.s3d-specs dt{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted)}
.s3d-specs dd{font:600 16px var(--body);color:var(--ink);margin-top:2px}
.s3d-cta{display:flex;flex-direction:column;align-items:center;gap:10px;margin-top:28px;position:relative;z-index:3}
.s3d-cta .hint{font-size:13px;color:var(--muted)}
.s3d-progress{display:none}
/* con animación: todo se superpone en una sola escena fija */
.m3d .s3d-pin{height:100vh;min-height:560px;display:block;padding:0}
.m3d .s3d-intro{position:absolute;left:0;right:0;top:12vh}
.m3d .s3d-canvas{position:absolute;left:50%;top:50%;width:min(620px,92vw,78vh);margin:0;transform:translate(-50%,-38%)}
.m3d .s3d-canvas canvas{display:block;opacity:0;transition:opacity .5s ease}.m3d .s3d-canvas .shadow{display:block}.m3d .s3d-canvas .poster{transform-origin:50% 50%;transition:opacity .5s ease;will-change:transform}.ready3d .s3d-canvas canvas{opacity:1}.ready3d .s3d-canvas .poster{opacity:0}
.m3d .s3d-chapters{position:absolute;left:max(20px,calc((100vw - 1200px)/2));top:18vh;margin:0;width:min(380px,44vw);display:block}
.m3d .ch{position:absolute;left:0;top:0;opacity:0;visibility:hidden}
.m3d .s3d-specs{position:absolute;right:max(20px,calc((100vw - 1200px)/2));top:20vh;margin:0;width:200px;grid-template-columns:1fr;border-top:0;padding:0;opacity:0;visibility:hidden}
.m3d .s3d-specs div{border-top:1px solid var(--line);padding-top:10px}
.m3d .s3d-cta{position:absolute;left:0;right:0;bottom:58px;margin:0}
.m3d .s3d-progress{display:flex;gap:6px;position:absolute;left:50%;bottom:28px;transform:translateX(-50%);width:min(320px,70vw)}
.m3d .s3d-progress span{flex:1;height:3px;border-radius:3px;background:var(--line);overflow:hidden;position:relative}
.m3d .s3d-progress span::after{content:"";position:absolute;inset:0;background:var(--ink);transform:scaleX(var(--p,0));transform-origin:0 50%}
@media (max-width:760px){.m3d .s3d-chapters{left:20px;right:20px;width:auto;top:auto;bottom:calc(64px + 8.5em)}.m3d .s3d-specs{display:none}.m3d .s3d-canvas{transform:translate(-50%,-62%);width:min(440px,96vw)}.m3d .s3d-intro{top:11vh}}
"""
h = h.replace("</style>", CSS + "</style>", 1)
h = h.replace("family=Inter:wght@400;500;600", "family=Inter:wght@400;500;600;800")

# JS: quita las partes de la portada y de la ilustración anteriores
JS = build2.JS
a = JS.index("  var hero = gsap.timeline"); z = JS.index("  var track = document.querySelector")
JS = JS[:a] + JS[z:]
a = JS.index("  // Ilustración que se dibuja"); z = JS.index("  gsap.utils.toArray('.card')")
JS = JS[:a] + "  var mm = gsap.matchMedia();\n" + JS[z:]
h = h.replace(build2.JS, JS)

THREE = r"""
<script type="module">
const gsap = window.gsap, ST = window.ScrollTrigger;
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
let hasGL = false; try { const c = document.createElement('canvas'); hasGL = !!(c.getContext('webgl2') || c.getContext('webgl')); } catch (e) {}
if (gsap && ST && hasGL && !reduce) setup();

function setup() {
  const root = document.documentElement; root.classList.add('m3d');
  const canvas = document.querySelector('.s3d-canvas canvas');
  const poster = document.querySelector('.s3d-canvas .poster');
  const shadow = document.querySelector('.s3d-canvas .shadow');
  const st = { y: -3.2, ry: -.6, rx: .18, s: .7, x: 0 };
  let three = null;   // se llena cuando el 3D está listo
  // 1 unidad de la escena ≈ 32% del alto del lienzo (cámara de 28° a 6.2 de distancia)
  function draw() {
    if (three) {
      const { renderer, scene, camera, tooth } = three;
      tooth.position.set(st.x, st.y, 0); tooth.rotation.set(st.rx, st.ry, 0); tooth.scale.setScalar(st.s);
      renderer.render(scene, camera);
    } else {
      poster.style.transform = 'translate(' + (st.x * 32) + '%,' + (-(st.y - .05) * 32) + '%) scale(' + (st.s / 1.05) + ')';
    }
    const lift = Math.max(0, Math.min(1, 1 - Math.abs(st.y + .1) / 2.6));
    shadow.style.opacity = lift.toFixed(3); shadow.style.transform = 'translateX(' + (st.x * 18) + '%) scaleX(' + (.6 + .4 * st.s) + ')';
  }

  const chs = gsap.utils.toArray('.ch'), bars = gsap.utils.toArray('.s3d-progress span');
  const tl = gsap.timeline({ defaults: { ease: 'none' }, onUpdate: draw,
    scrollTrigger: { trigger: '.s3d', start: 'top top', end: '+=420%', pin: '.s3d-pin', scrub: .8, anticipatePin: 1, refreshPriority: 1,
      onUpdate(self) { const p = self.progress; bars.forEach((b, i) => b.style.setProperty('--p', Math.max(0, Math.min(1, (p - .3 - i * .233) / .233)))); } } });
  tl.to(st, { y: -.12, ry: .25, duration: .14, ease: 'power2.out' }, 0)
    .to('.swap .spark-l', { opacity: 0, scale: .2, rotate: 90, duration: .03 }, .1)
    .fromTo('.swap .real', { opacity: 0, yPercent: 40 }, { opacity: 1, yPercent: 0, duration: .04, ease: 'back.out(3)' }, .11)
    .to('.fly', { opacity: 0, scale: 2.2, duration: .04 }, .11)
    .to('.s3d-intro', { yPercent: -60, opacity: 0, filter: 'blur(10px)', duration: .1 }, .2)
    .to('.s3d-cta', { opacity: 0, y: 30, duration: .06 }, .2)
    .to(st, { y: .05, s: 1.05, rx: .32, duration: .12, ease: 'power1.inOut' }, .2)
    .to('.s3d-specs', { autoAlpha: 1, duration: .05 }, .3);
  chs.forEach((c, i) => {
    const t0 = .3 + i * .233;
    tl.fromTo(c, { autoAlpha: 0, x: -40, filter: 'blur(12px)' }, { autoAlpha: 1, x: 0, filter: 'blur(0px)', duration: .06 }, t0);
    if (i < chs.length - 1) tl.to(c, { autoAlpha: 0, x: 30, filter: 'blur(8px)', duration: .05 }, t0 + .19);
  });
  tl.to(st, { ry: .25 + Math.PI * 2, duration: .7 }, .3)
    .to(st, { x: innerWidth < 760 ? 0 : .5, duration: .2, ease: 'power1.inOut' }, .3)
    .to(st, { rx: .05, duration: .35, ease: 'sine.inOut' }, .3).to(st, { rx: .3, duration: .35, ease: 'sine.inOut' }, .65);

  gsap.set('.swap .real', { opacity: 0 }); gsap.set('.swap .spark-l', { opacity: 1 });
  gsap.to('.swap .spark-l', { rotate: 45, scale: 1.12, duration: 1.2, yoyo: true, repeat: -1, ease: 'sine.inOut' });
  gsap.utils.toArray('.fly').forEach((f, i) => gsap.fromTo(f, { opacity: 0, y: 10 }, { opacity: 1, y: -10, rotate: 90, duration: 1.6 + i * .3, yoyo: true, repeat: -1, ease: 'sine.inOut', delay: i * .25 }));
  gsap.from('.s3d .word .big', { yPercent: 30, opacity: 0, duration: 1, ease: 'expo.out', delay: .1 });
  gsap.to(st, { y: -1.85, duration: 1.4, ease: 'expo.out', delay: .25, onUpdate: draw, onComplete: () => tl.invalidate() });
  draw(); ST.sort(); ST.refresh();

  // El 3D se carga después de que la página ya se ve y responde
  const go = () => load3d().catch(() => {});
  const idle = () => ('requestIdleCallback' in window ? requestIdleCallback(go, { timeout: 1500 }) : setTimeout(go, 300));
  document.readyState === 'complete' ? idle() : addEventListener('load', idle, { once: true });

  async function load3d() {
    const [T, bin] = await Promise.all([import('./three-lite.js'), fetch('./diente.bin').then(r => r.arrayBuffer())]);
    const head = new Float32Array(bin, 0, 4), m = head[0], nv = head[1], ni = head[2];
    const q = new Int16Array(bin, 16, nv * 3), pos = new Float32Array(nv * 3);
    for (let i = 0; i < pos.length; i++) pos[i] = q[i] / 32767 * m;
    const idx = new Uint16Array(bin, 16 + nv * 6, ni);
    const geo = new T.BufferGeometry(); geo.setAttribute('position', new T.BufferAttribute(pos, 3)); geo.setIndex(new T.BufferAttribute(idx, 1)); geo.computeVertexNormals();
    const renderer = new T.WebGLRenderer({ canvas, antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(devicePixelRatio, innerWidth < 760 ? 1.5 : 2));
    renderer.toneMapping = T.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
    const scene = new T.Scene();
    const pmrem = new T.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new T.RoomEnvironment(), .04).texture; scene.environmentIntensity = .55; pmrem.dispose();
    const camera = new T.PerspectiveCamera(28, 1, .1, 50); camera.position.set(0, .15, 6.2);
    const key = new T.DirectionalLight(0xfff8ee, 2.6); key.position.set(3.5, 5, 4); scene.add(key);
    const rim = new T.DirectionalLight(0x7fd1d9, 2.2); rim.position.set(-4, 2, -3); scene.add(rim);
    const fill = new T.DirectionalLight(0xffffff, .35); fill.position.set(-3, -1, 4); scene.add(fill);
    const mat = new T.MeshPhysicalMaterial({ color: 0xf2ece0, roughness: .28, clearcoat: .9, clearcoatRoughness: .18, sheen: .5, sheenColor: new T.Color(0xfff6e8), sheenRoughness: .6 });
    const mesh = new T.Mesh(geo, mat); mesh.scale.setScalar(1.2);
    const tooth = new T.Group(); tooth.add(mesh); scene.add(tooth);
    const size = () => { const r = canvas.getBoundingClientRect(); renderer.setSize(r.width, r.height, false); camera.aspect = r.width / r.height; camera.updateProjectionMatrix(); if (three) draw(); };
    three = { renderer, scene, camera, tooth };
    size(); addEventListener('resize', size);
    renderer.compile(scene, camera); draw();
    requestAnimationFrame(() => root.classList.add('ready3d'));
  }
}
</script>"""
h = h.replace("\n</body>", THREE + "\n</body>")
# navegación: la sección destacada ahora es la escena 3D
h = h.replace('<a class="btn ghost" href="#atencion">', '<a class="btn ghost" href="#servicios">')
open(p, "w").write(h)
import shutil
W = os.path.join(os.path.dirname(BASE), "opt")
for f in ("three-lite.js", "diente.bin"): shutil.copy(os.path.join(W, f), os.path.join(BASE, "out", b["slug"], f))
shutil.copy(os.path.join(os.path.dirname(BASE), "diente-3d.webp"), os.path.join(BASE, "out", b["slug"], "img", "diente-3d.webp"))
print("ok", len(h))
